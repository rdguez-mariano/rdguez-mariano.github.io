opts_maxtilt.draw_on = true;
anglevec = 0:10:180;
tvec = 1.4:0.1:2.4;

figure;
[Mbool, Mval, RADIUS ] =   tolerance_tests(tvec,anglevec,opts_maxtilt);

title(['Transition Tilt Tolerance t_{max} = ' num2str(RADIUS) ' )']);