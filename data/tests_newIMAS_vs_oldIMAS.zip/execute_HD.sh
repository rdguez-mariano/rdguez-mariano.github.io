echo "IMAS+HyperDescriptors vs old IMAS"

tensor=8
tensor2=8
matchratio=0.6
matchratio_new=0.85
orsaprecision=18

mkdir -p data

# Unique filter only
echo "data/old_1.txt <- Old IMAS with Unique filter"
./old_IMAS_cpp/build/main -im1 $1 -im2 $2 -orsa_type 2 -desc 11 -tensor_eigen_threshold ${tensor} -match_ratio ${matchratio} -orsa_precision ${orsaprecision} -applyfilter 1 -eigen_threshold ${tensor2} > ./data/old_1.txt

cp output_hori.png data/output_hori_old1.png

# Unique + one2mult filters
echo "data/old_3.txt <- Old IMAS with Unique + one2mult filters"
./old_IMAS_cpp/build/main -im1 $1 -im2 $2 -orsa_type 2 -desc 11 -tensor_eigen_threshold ${tensor} -match_ratio ${matchratio} -orsa_precision ${orsaprecision} -applyfilter 3 -eigen_threshold ${tensor2} > ./data/old_3.txt

cp output_hori.png data/output_hori_old3.png

# Unique + Homography filters
echo "data/old_5.txt <- Old IMAS with Unique + Homography filters"
./old_IMAS_cpp/build/main -im1 $1 -im2 $2 -orsa_type 2 -desc 11 -tensor_eigen_threshold ${tensor} -match_ratio ${matchratio} -orsa_precision ${orsaprecision} -applyfilter 5 -eigen_threshold ${tensor2} > ./data/old_5.txt

cp output_hori.png data/output_hori_old5.png

# Unique + one2mult + Homography filters
echo "data/old_7.txt <- Old IMAS with Unique + one2mult + Homography filters"
./old_IMAS_cpp/build/main -im1 $1 -im2 $2 -orsa_type 2 -desc 11 -tensor_eigen_threshold ${tensor} -match_ratio ${matchratio} -orsa_precision ${orsaprecision} -applyfilter 7 -eigen_threshold ${tensor2} > ./data/old_7.txt

cp output_hori.png data/output_hori_old7.png

#new imags
echo "data/new.txt <- New IMAS"
./new_IMAS_cpp/build/main -im1 $1 -im2 $2 -orsa_type 2 -desc 11 -tensor_eigen_threshold ${tensor} -match_ratio ${matchratio_new} -orsa_precision ${orsaprecision} -applyfilter 4 -eigen_threshold ${tensor2} > ./data/new.txt

cp output_hori.png data/output_hori_new.png


rm data_matches.csv
rm output_hori.png
rm output_hori_rich.png
rm output_vert.png
rm output_vert_rich.png
rm panorama.png

echo "Done."
