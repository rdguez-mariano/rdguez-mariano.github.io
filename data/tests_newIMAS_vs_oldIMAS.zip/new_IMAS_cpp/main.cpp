/*! \mainpage Documentation
 *
 * \section intro_sec Introduction
 *
 *  Here there is to be the IMAS documentation.
 *  Compute the IMAS keypoints on the input image.
 *  Please report bugs and/or send comments to Mariano Rodríguez <rdguez.mariano@gmail.com>
 *
 *
 * \section install_sec Installation
 * asdf
 *
 * \subsection tools_subsec Requirements
 * - <a href="http://docs.opencv.org/3.2.0/index.html">Opencv 3.2.0</a>
 *
 * \section run_sec Run Section
 *
 *
 *
 * \section ref_sec References:
 *  - J.M. Morel and G.Yu, ASIFT: A New Framework for Fully Affine Invariant Image Comparison, SIAM Journal on Imaging Sciences, vol. 2, issue 2, pp. 438-469, 2009.
 *  - <a href="http://www.ipol.im/pub/algo/my_affine_sift/">ASIFT online demo</a>
 *  - <a href="http://www.cmap.polytechnique.fr/~yu/research/ASIFT/demo.html">ASIFT Web Page</a>
 *
 *
 * <BR><BR>
 *
 */


#include <string>
#include <vector>

#include "local_descriptor.h"
#include "mex_and_omp.h"
#include "perform_IMAS.h"

using namespace std;


void MatrixNumerics2cvMat(std::vector<TypeMap>& input, std::vector<cv::Mat>& output)
{
    for (int i=0; i<input.size();i++)
    {
        TypeMap thismap = (input[i]);
        cv::Mat thismat;
        thismat.create(thismap.nrow(),thismap.ncol(),CV_32F);
        for (int i=0;i<thismap.ncol();i++)
        {
            for (int j=0;j<thismap.nrow();j++)
            {
                thismat.col(i).row(j) = (float) thismap(j,i);
            }
        }
        output.push_back(thismat);
    }
}

#include <map>
#include <string>
#include <iostream>
enum StringValue { _wrongvalue,_im1, _im2,_im3,_max_keys_im3,_im3_only, _orsa_type, _applyfilter, _IMAS_INDEX, _radius,_match_ratio, _orsa_precision, _eigen_threshold, _tensor_eigen_threshold };
static std::map<std::string, int> strmap;
void buildmap()
{
    strmap["wrongvalue"] = _wrongvalue;
    strmap["-im1"] = _im1;
    strmap["-im2"] = _im2;
    strmap["-im3"] = _im3;
    strmap["-max_keys_im3"] = _max_keys_im3;
    strmap["-im3_only"] = _im3_only;
    strmap["-orsa_type"] = _orsa_type;
    strmap["-applyfilter"] = _applyfilter;
    strmap["-desc"] = _IMAS_INDEX;
    strmap["-radius"] = _radius;
    strmap["-match_ratio"] = _match_ratio;
    strmap["-orsa_precision"] = _orsa_precision;
}


void get_arguments(int argc, char **argv, string& im1, string& im2, string& im3, int& applyfilter, int& IMAS_INDEX, float& radius,float& matchratio)
{
    int count = 1;
    buildmap();
    while (count<argc)
    {
        string s(argv[count++]);
        //cout<<s<<" = "<<argv[count]<< endl;
        switch (strmap[s])
        {
        case _wrongvalue:
        {
            cout<<"unidentified: "<<s<<" = "<<argv[count]<<endl;
            break;
        }
        case _im3:
        {
            string temp(argv[count]);
            im3=temp;
            break;
        }
        case _im1:
        {
            string temp(argv[count]);
            im1=temp;
            break;
        }
        case _im2:
        {
            string temp(argv[count]);
            im2=temp;
            break;
        }
        case _orsa_type:
        {
            if (atoi(argv[count])==1)
            {
                Tmin = 8;
                ORSA_Fundamental = true;
                ORSA_precision=3;
            }
            else
            {
                Tmin = 5;
                ORSA_Fundamental = false;
                ORSA_precision=24;
            }
            break;

        }
        case _orsa_precision:
        {
            ORSA_precision = atof(argv[count]);
            break;
        }
        case _applyfilter:
        {
            applyfilter = atoi(argv[count]);
            break;
        }
        case _IMAS_INDEX:
        {
            IMAS_INDEX = atoi(argv[count]);
            break;
        }
        case _radius:
        {
             radius = atof(argv[count]);
             break;
        }
        case _match_ratio:
        {
             matchratio = atof(argv[count]);
             break;
        }
        }
        count++;
    }
}



/**
 * @brief main
 * @param image1 Path to image1 (png)
 * @param image2 Path to image1 (png)
 * @param applyfilter Tells which filters should be applied in the function compute_IMAS_matches(). This parameter is in fact pass on to the function perform_IMAS().
 * @param ORSA_type Tells which version of ORSA should be applied (if it is to be applied in applyfilter):
 * - Homography - <a href="http://www.ipol.im/pub/art/2012/mmm-oh/">Lionel Moisan, Pierre Moulon, and Pascal Monasse, Automatic Homographic Registration of a Pair of Images, with A Contrario Elimination of Outliers, Image Processing On Line, 2 (2012), pp. 56–73</a>.
 * - Fundamental - <a href="http://www.ipol.im/pub/art/2016/147/">Lionel Moisan, Pierre Moulon, and Pascal Monasse, Fundamental Matrix of a Stereo Pair, with A Contrario Elimination of Outliers, Image Processing On Line, 6 (2016), pp. 89–113</a>.
 * @param IMAS_INDEX Tells which descriptor+extractor to use from local_descriptor.h
 * @param visualize (Optional) Tells if results should also be displayed on the screen.
 * @param radius (Optional) Forces to use a predefined log(radius)-covering instead of the default one.
 *
 *
 * @code
 * // Execute Affine-RootSIFT and apply ORSA Homography & Misc
 * ./main -im1 "image1.png" -im2 "image2.png" -applyfilter 7 -orsa_type 0 -IMAS_INDEX 11 -radius 2
 *
 * @endcode
 */
int main(int argc, char **argv)
{

    int IMAS_INDEX = 11, applyfilter = 7;
    float radius = -1.0f, matchratio = -1.0f;
    std::vector<float> ipixels1,ipixels2,ipixels3;
    int w1,h1,w2,h2,w3,h3;
    string sipixels1,sipixels2,sipixels3;
    get_arguments(argc,argv,sipixels1,sipixels2,sipixels3,applyfilter,IMAS_INDEX,radius,matchratio);

    string algo_name = SetDetectorDescriptor(IMAS_INDEX);
    if (radius!=1.0f)
        algo_name ="Optimal-Affine-"+algo_name;


    if (radius>0.0f)
        default_radius = radius;
    loadsimulations2do(default_radius);

//    if ((AUX_KEYPOINTS)&&(IMAS_INDEX!=IMAS_SURF))
//        prepare_acontrario_matching(ipixels3,(int) w3,(int) h3);

    if (matchratio>0.0f)
        update_matchratio(matchratio);


// Read images
    cv::Mat queryImg,targetImg;

    queryImg = cv::imread(sipixels1, CV_LOAD_IMAGE_GRAYSCALE );
    opencvimage2vectorimage(queryImg,ipixels1,w1,h1);

    targetImg = cv::imread(sipixels2, CV_LOAD_IMAGE_GRAYSCALE );
    opencvimage2vectorimage(targetImg,ipixels2,w2,h2);

    bool visualize = true;

if (visualize)
{
// Show Images
    cv::imshow( algo_name, queryImg );
    cv::waitKey(0);
    cv::imshow( algo_name, targetImg );
    cv::waitKey(0);
}


// Number of threads to use
    int nthreads, maxthreads;
       /* Display info on OpenMP*/
               #pragma omp parallel
           {
               #pragma omp master
               {
                   nthreads = my_omp_get_num_threads();
                   maxthreads = my_omp_get_max_threads();
               }
           }
 my_mexPrintf("--> Using %d threads out of %d for executing %s <--\n\n",nthreads,maxthreads,algo_name.c_str());




 // Performing IMAS
    vector< vector <float> > Minfoall;
    matchingslist matchings;
    vector< float > data;

    perform_IMAS(ipixels1, w1, h1, ipixels2, w2, h2, data, matchings, Minfoall, 0, applyfilter);

    if (matchings.size()==0)
        return 0;



    //Output file "data_matches.csv"

    int wo = 14;
    ofstream myfile;
    myfile.open ("data_matches.csv", std::ofstream::out | std::ofstream::trunc);
    myfile<<"x1, y1, sigma1, angle1, t1_x, t1_y, theta1, x2, y2, sigma2, angle2, t2_x, t2_y, theta2"<<endl;

    if (matchings.size()>0)
    {
        int cont =1;
        myfile << ((double) data[0]) << ",";

        for ( int i = 1; i < (int) (wo*matchings.size()); i++ )
        {
            if (cont ==(wo-1))
            {
                myfile << ((double) data[i]) << endl;
                cont = 0;
            }
            else
            {
                myfile << ((double) data[i]) << ",";
                cont = cont +1;
            }

        }
    }
    myfile.close();



     //Showing Results
     cv::Mat all_matches;
     std::vector<cv::DMatch> goodmatches;
     opencv_keypointslist queryKeypoints, targetKeypoints;
     matching* thismatching;

     for (int i=0;i<(int)matchings.size();i++)
     {
         thismatching=&(matchings[i]);
         queryKeypoints.push_back( cv::KeyPoint(thismatching->first.x, thismatching->first.y, thismatching->first.scale));
         targetKeypoints.push_back( cv::KeyPoint(thismatching->second.x, thismatching->second.y, thismatching->second.scale));
         goodmatches.push_back(cv::DMatch(i, i, 0));
     }

     cv::drawMatches( queryImg, queryKeypoints, targetImg, targetKeypoints,
                          goodmatches, all_matches,
                      cv::Scalar::all(-1), cv::Scalar::all(-1),
                      vector<char>(), cv::DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS );

    cv::imwrite("result.png",all_matches);


    cv::Mat QueryOnTarget;
    std::vector<cv::Mat> MMap;
    MatrixNumerics2cvMat(IdentifiedMaps,MMap);
    if ((!ORSA_Fundamental)&&(!MMap.empty()))
    {

        cv::warpPerspective(queryImg,QueryOnTarget,MMap[0],cv::Size(targetImg.cols,targetImg.rows));
        QueryOnTarget = 2*QueryOnTarget/4+ 2*targetImg/4;
        cv::imwrite("QueryOnTarget.png",QueryOnTarget);
    }

     if (visualize)
     {
         cv::imshow(algo_name, all_matches );

         if ((!QueryOnTarget.empty()))
         {
             cv::imshow( "Query image Transformed on Target Image", QueryOnTarget );
             cv::moveWindow("Query image Transformed on Target Image", 20,all_matches.rows);
         }

         cv::waitKey(0);
     }

// Clear memory
     data.clear();
     matchings.clear();
     Minfoall.clear();
     simu_details1.clear();
     simu_details2.clear();

    return 0;
}
