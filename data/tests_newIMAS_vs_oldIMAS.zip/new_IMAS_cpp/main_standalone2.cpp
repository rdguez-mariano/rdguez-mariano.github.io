#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include "mex_and_omp.h"
#include "perform_IMAS.h"
#include "io_png/io_png.h"

using namespace std;

# define IM_X 800
# define IM_Y 600


#include "frot.h"
#include "fproj.h"
static float InitSigma_aa = 1.6;
#define round(x) ((x)>=0?(long)((x)+0.5):(long)((x)-0.5))
const float GaussTruncate1 = 4.0;
void perform_tilt_and_rotation( vector<float>& image, int width, int height, vector<float>& image_to_return, int& width_t, int& height_t, float theta, float t)
{

    int flag_dir = 1;
    int fproj_o;
    float fproj_p, fproj_bg;
    char fproj_i;
    float *fproj_x4, *fproj_y4;
    //  float frot_b=0;
    float frot_b=128;
    char *frot_k;

    frot_k = 0; // order of interpolation


    fproj_o = 3;
    fproj_p = 0;
    fproj_i = 0;
    fproj_bg = 0;
    fproj_x4 = 0;
    fproj_y4 = 0;




    //theta = theta * 180 / PI;
    float t1 = 1;
    float t2 = 1/t;

    vector<float> image_t;
    int width_r, height_r;

    // simulate a rotation: rotate the image with an angle theta. (the outside of the rotated image are padded with the value frot_b)
    frot(image, image_t, width, height, &width_r, &height_r, &theta, &frot_b , frot_k);

    /* Tilt */
    width_t = (int) (width_r * t1);
    height_t = (int) (height_r * t2);

    int fproj_sx = width_t;
    int fproj_sy = height_t;

    float fproj_x1 = 0;
    float fproj_y1 = 0;
    float fproj_x2 = width_t;
    float fproj_y2 = 0;
    float fproj_x3 = 0;
    float fproj_y3 = height_t;

    if (t==1.0f)
    {
        image_to_return = image_t;
    }
    else
    {
        /* Anti-aliasing filtering along vertical direction */
        float sigma_aa = (InitSigma_aa/2) * sqrt(std::pow(t,2) -1);
        GaussianBlur1D(image_t,width_r,height_r,sigma_aa,flag_dir);


        // simulate a tilt: subsample the image along the vertical axis by a factor of t.
        vector<float> image_tmp(width_t*height_t);
        fproj (image_t, image_tmp, width_r, height_r, &fproj_sx, &fproj_sy, &fproj_bg, &fproj_o, &fproj_p, &fproj_i , fproj_x1 , fproj_y1 , fproj_x2 , fproj_y2 , fproj_x3 , fproj_y3, fproj_x4, fproj_y4);
        image_to_return = image_tmp;
    }


}

void invert_contrast(std::vector<float>& image,int w, int h)
{    for (int i=0;i<h;i++)
        for (int j=0;j<w;j++)
        {
            image[j*h+i] = (float)(255 - image[j*h+i]);
        }
}

void write_images_matches(std::vector<float>& ipixels1,int w1, int h1,std::vector<float>& ipixels2, int w2, int h2,matchingslist& matchings, float zoom1, float zoom2)
{

    int sq = 2;
    ///////////////// Output image containing line matches (the two images are concatenated one above the other)
    int band_w = 20; // insert a black band of width band_w between the two images for better visibility

    int wo =  MAX(w1,w2);
    int ho = h1+h2+band_w;

    std::vector<float *> opixelsASIFT;
    for(int c=0;c<3;c++)
        opixelsASIFT.push_back(new float[wo*ho]);

    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) ho; j++)
            for(int i = 0; i < (int) wo; i++)
                opixelsASIFT[c][j*wo+i] = 255;

    /////////////////////////////////////////////////////////////////// Copy both images to output
    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) h1; j++)
            for(int i = 0; i < (int) w1; i++)
                opixelsASIFT[c][j*wo+i] = ipixels1[j*w1+i];

    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) h2; j++)
            for(int i = 0; i < (int) (int)w2; i++)
                opixelsASIFT[c][(h1 + band_w + j)*wo + i] = ipixels2[j*w2 + i];

    //////////////////////////////////////////////////////////////////// Draw matches

    float value;
    for(int i=0; i < (int) matchings.size(); i++)
        for(int c=0;c<3;c++)
        {
            value =  (float)(rand() % 150 + 50);

            draw_line(opixelsASIFT[c],  round(zoom1*matchings[i].first.x), round(zoom1*matchings[i].first.y),
                      round(zoom2*matchings[i].second.x), round(zoom2*matchings[i].second.y) + h1 + band_w, value, wo, ho);
            draw_square(opixelsASIFT[c],  round(zoom1*matchings[i].first.x)-sq, round(zoom1*matchings[i].first.y)-sq, 2*sq, 2*sq, value, wo, ho);
            draw_square(opixelsASIFT[c],  round(zoom2*matchings[i].second.x)-sq, round(zoom2*matchings[i].second.y) + h1 + band_w-sq, 2*sq, 2*sq, value, wo, ho);
        }

    float * rgb = new float[wo*ho*3];
    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) ho; j++)
            for(int i = 0; i < (int) wo; i++)
                rgb[j*wo+i+c*(wo*ho)] = opixelsASIFT[c][j*wo+i];


    ///////////////////////////////////////////////////////////////// Save imgOut
    write_png_f32("output_vert.png", rgb, wo, ho, 3);

    for(int c=0;c<3;c++)
    delete[] opixelsASIFT[c]; /*memcheck*/



    /////////// Output image containing line matches (the two images are concatenated one aside the other)
    int woH =  w1+w2+band_w;
    int hoH = MAX(h1,h2);

     std::vector<float *> opixelsASIFT_H;
     for(int c=0;c<3;c++)
         opixelsASIFT_H.push_back(new float[woH*hoH]);

     for(int c=0;c<3;c++)
    for(int j = 0; j < (int) hoH; j++)
        for(int i = 0; i < (int) woH; i++)  opixelsASIFT_H[c][j*woH+i] = 255;

    /////////////////////////////////////////////////////////////////// Copy both images to output
    for(int c=0;c<3;c++)
     for(int j = 0; j < (int) h1; j++)
        for(int i = 0; i < (int) w1; i++)  opixelsASIFT_H[c][j*woH+i] = ipixels1[j*w1+i];

    for(int c=0;c<3;c++)
    for(int j = 0; j < (int) h2; j++)
        for(int i = 0; i < (int) w2; i++)  opixelsASIFT_H[c][j*woH + w1 + band_w + i] = ipixels2[j*w2 + i];

    //////////////////////////////////////////////////////////////////// Draw matches

    for(int i=0; i < (int) matchings.size(); i++)
        for(int c=0;c<3;c++)
        {
            value =  (float)(rand() % 150 + 50);

            draw_line(opixelsASIFT_H[c],  round(zoom1*matchings[i].first.x), round(zoom1*matchings[i].first.y),
                      round(zoom2*matchings[i].second.x) + w1 + band_w, round(zoom2*matchings[i].second.y), value, woH, hoH);

            draw_square(opixelsASIFT_H[c],  round(zoom1*matchings[i].first.x)-sq, round(zoom1*matchings[i].first.y)-sq, 2*sq, 2*sq, value, woH, hoH);
            draw_square(opixelsASIFT_H[c],  round(zoom2*matchings[i].second.x) + w1 + band_w-sq, round(zoom2*matchings[i].second.y)-sq, 2*sq, 2*sq, value, woH, hoH);
        }

delete[] rgb;
    rgb = new float[woH*hoH*3];
    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) hoH; j++)
            for(int i = 0; i < (int) woH; i++)
                rgb[j*woH+i+c*(woH*hoH)] = opixelsASIFT_H[c][j*woH+i];



    ///////////////////////////////////////////////////////////////// Save imgOut
    write_png_f32("output_hori.png", rgb, woH, hoH, 3);
    delete[] rgb;
for(int c=0;c<3;c++)
    delete[] opixelsASIFT_H[c]; /*memcheck*/
}


int main(int argc, char **argv)
{

       // std::cout << "Main was call with "<< argc-1 <<"  parameters!"<< endl;

    //////////////////////////////////////////////// Input
    // Read image1
    float * iarr1;
    size_t w1, h1;
    if (NULL == (iarr1 = read_png_f32_gray(argv[1], &w1, &h1))) {
        std::cerr << "Unable to load image file " << argv[1] << std::endl;
        return 1;
    }
    std::vector<float> ipixels1(iarr1, iarr1 + w1 * h1);
    free(iarr1); /*memcheck*/

    // Read image2
    float * iarr2;
    size_t w2, h2;
    if (NULL == (iarr2 = read_png_f32_gray(argv[2], &w2, &h2))) {
        std::cerr << "Unable to load image file " << argv[2] << std::endl;
        return 1;
    }
    std::vector<float> ipixels2(iarr2, iarr2 + w2 * h2);
    free(iarr2); /*memcheck*/

    // Setting variables
        int flag_resize = 0;
        int applyfilter = atoi(argv[3]);
        int orsa_type = atoi(argv[4]);
        int IMAS_INDEX = atoi(argv[5]);
        bool visualize = false;

        if (argc>=7)
            if (atoi(argv[6])==0)
                visualize = false;

       string algo_name = "Affine-"+SetDetectorDescriptor(IMAS_INDEX);//not working NOW: LUCID, AGAST
       if ((IMAS_INDEX==IMAS_SIFT)||(IMAS_INDEX==IMAS_SURF))
           algo_name ="Optimal-"+algo_name;



    // Number of threads to use
        int nthreads, maxthreads;
           /* Display info on OpenMP*/
                   #pragma omp parallel
               {
                   #pragma omp master
                   {
                       nthreads = my_omp_get_num_threads();
                       maxthreads = my_omp_get_max_threads();
                   }
               }
     my_mexPrintf("--> Using %d threads out of %d for executing %s <--\n\n",nthreads,maxthreads,algo_name.c_str());




     // Performing IMAS
        vector< vector <float> > Minfoall;
        matchingslist matchings;
        vector< float > data;

        if (argc>=8)
            default_radius = atof(argv[7]);

        loadsimulations2do(default_radius);
        if (orsa_type==1)
        {
            Tmin = 8;
            ORSA_Fundamental = true;
        }
        else
        {
            Tmin = 5;
            ORSA_Fundamental = false;
        }

//        invert_contrast(ipixels2, w2, h2);
//        int wt1,ht1;
//        perform_tilt_and_rotation(ipixels1,w1,h1,ipixels1,wt1,ht1,180.0f,1.0f); w1 = wt1;h1=ht1;

        perform_IMAS(ipixels1, (int)w1, (int)h1, ipixels2, (int)w2, (int)h2, data, matchings, Minfoall, flag_resize, applyfilter);
       // perform_IMAS(ipixels2, (int)w2, (int)h2, ipixels1, (int)w1, (int)h1, data, matchings, Minfoall, flag_resize, applyfilter);

        write_images_matches(ipixels1,(int) w1, (int) h1, ipixels2, (int) w2, (int) h2, matchings, 1.0f, 1.0f);

        if (matchings.size()==0)
            return 0;

    //Output file "data_matches.csv"

        int wo = 14;
        ofstream myfile;
        myfile.open ("data_matches.csv", std::ofstream::out | std::ofstream::trunc);
        int cont =1;
        myfile << ((double) data[0]) << ",";

        for ( int i = 1; i < (int) (wo*matchings.size()); i++ )
        {
            if (cont ==(wo-1))
            {
                myfile << ((double) data[i]) << endl;
                cont = 0;
            }
            else
            {
                myfile << ((double) data[i]) << ",";
                cont = cont +1;
            }

        }
         myfile.close();



         //Showing Results


    // Clear memory
         data.clear();
         matchings.clear();
         Minfoall.clear();
         simu_details1.clear();
         simu_details2.clear();

    return 0;
}
