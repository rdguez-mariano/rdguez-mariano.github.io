/**
  * @file local_descriptor.h
  * @author Mariano Rodríguez
  * @date 2017
  * @brief Handles local descriptors matching methods to be used under IMAS (provided by Opencv 3.2.0)
  * @warning This file is made available for the exclusive aim of serving as scientific tool to verify of the soundness and completeness of the algorithm description. Compilation, execution and redistribution of this file may violate exclusive patents rights in certain countries. The situation being different for every country and changing over time, it is your responsibility to determine which patent rights restrictions apply to you before you compile, use, modify, or redistribute this file. A patent lawyer is qualified to make this determination.
  */

#ifndef _CLIB_IMAS_H_
#define _CLIB_IMAS_H_

//opencv
#include <opencv2/core.hpp>
#include "opencv2/opencv.hpp"
#include "opencv2/opencv_modules.hpp"
#include "opencv2/core/core.hpp"
#include "opencv2/features2d.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/calib3d/calib3d.hpp"
#include <opencv2/xfeatures2d.hpp>
#include "opencv2/flann/miniflann.hpp"


#include <string>


#define IMAS_SIFT 1
#define IMAS_SURF 2
#define IMAS_BRISK 3
#define IMAS_BRIEF 4
#define IMAS_ORB 5
#define IMAS_DAISY 6
#define IMAS_AKAZE 7
#define IMAS_LATCH 8
#define IMAS_FREAK 9
#define IMAS_LUCID 10
#define IMAS_ROOTSIFT 11
#define IMAS_AGAST 13
#define IMAS_SIFT2 12
#define IMAS_HALFSIFT 21


typedef int64 IMAS_time;

/**
 * @brief For the brute-force matcher to find the k closest neighbor and then select matches as it was proposed by Lowe, D. G. (2004). Distinctive image features from scale-invariant keypoints. International journal of computer vision, 60(2), 91-110.
 * @default 2
 */
const int k=2;

/**
 * @brief States if the matcher should be the classic brute-force matcher.
 * @default true
 */
const bool useBFMatcher = true;

/**
 * @brief The local descriptor name as in the literature
 */
extern std::string desc_name;

/**
 * @brief Determines which log(radius)-covering to use. Normally set to the maximum tilt tolerance of the matching method.
 */
extern float default_radius;



namespace IMAS
{
typedef cv::Mat IMAS_Matrix;
IMAS_time IMAS_getTickCount();
double IMAS_getTickFrequency();

}


void update_matchratio(float matchratio);


/**
 * @brief keypointslist is only to be used inside local_descriptor.cpp or handled when filtering in compute_IMAS_matches.cpp
 * @code
 keypointslist kl;
 ... (compute somehow a keypointslist)
 for (int ii=0;ii<kl.size();ii++)
    cout<< "(x,y) = (" << kl[i].pt.x << ", " << kl[i].pt.x << endl;
 * @endcode
 */
typedef std::vector<cv::KeyPoint> opencv_keypointslist;

/**
 * @brief descriptorslist is only to be used inside local_descriptor.cpp or handled when filtering in compute_IMAS_matches.cpp
 * @code
          // Extract the i keypoint and descriptor
          descriptorslist DL;
          ...(compute somehow a descriptorslist)

          // Create a new keypointslist that containing only the i element
          descriptorslist descriptor_i;
          descriptors_filtered.create(1, DL.cols, DL.type());
          DL.row(i).copyTo(descriptors_filtered.row(1));
 * @endcode
 */
typedef cv::Mat opencv_descriptorslist;

/**
 * @brief Provides the class in which the IMAS algorithm will handle keypoints and descriptors.
 */
class IMAS_keypointlist
{
public:
    opencv_keypointslist KeyList;
    opencv_descriptorslist DescList;
};

void detector_and_descriptor(cv::Ptr<cv::FeatureDetector> &detector, cv::Ptr<cv::DescriptorExtractor> &extractor);
extern IMAS_keypointlist keys3;

/**
 * @brief This is a simpler version of keypoints that will be handle inside IMAS.
 */
struct keypoint_simple {
    float	x,y,
        scale,
        angle;
};

/**
 * @brief The very definition of a match for IMAS.
 */
typedef std::pair<keypoint_simple,keypoint_simple> matching;

/**
 * @brief A list of matches following the structure of IMAS.
 */
typedef std::vector<matching> matchingslist;




/**
 * @brief It loads the detector and descriptor index in IMAS.
 * @param DDIndex The IMAS Index of the matching method.
 * @return The name of the matching method that has been selected.
 * @code
 cout<< "The " << SetDetectorDescriptor(IMAS_SIFT) << " has been selected" << endl;
 * @endcode
 */
std::string SetDetectorDescriptor(int DDIndex);

/**
 * @brief Computes keypoints and descriptors from the matching method that has been selected.
 * @param queryImg Input image from which to compute keypoints.
 * @param KPs Returns the computation of keypoints and descriptors.
 */
void compute_local_descriptor_keypoints(cv::Mat& queryImg,  IMAS_keypointlist& KPs);

/**
 * @brief Runs the matcher.
 * @param keys1 keypoints and descriptors from image1
 * @param keys2 keypoints and descriptors from image2
 * @param matchings Returns the matches in a matchinglist.
 */
void compute_local_descriptor_matches( IMAS_keypointlist& keys1, IMAS_keypointlist& keys2, matchingslist& matchings);

/**
 * @brief Converts an array image into an opencv image.
 * @param input_image The image to be copied
 * @param output_image Returns the image in the opencv structure.
 * @param width The width of the input_image.
 * @param height The height of the input_image.
 */
void floatarray2opencvimage(float *input_image,cv::Mat& output_image,int width, int height);

/**
 * @brief Converts a vector image into an opencv image.
 * @param input_image Input image
 * @param output_image Output image
 * @param width Width of the input image
 * @param height Height of the input image
 */
void vectorimage2opencvimage(std::vector<float>& input_image,cv::Mat& output_image,int width, int height);

/**
 * @brief Converts an opencv image into a vector image.
 * @param input_image Input image
 * @param output_image Output image
 * @param width Returns the width for the output image
 * @param height Returns the height for the output image
 */
void opencvimage2vectorimage(cv::Mat& input_image,std::vector<float>& output_image,int& width, int& height);


/**
 * @brief Copies to descriptors_filtered all descriptors from input_list whose index are in index_filtered. This function is to be used in compute_IMAS_keypoints.
 * @param input_list Input list of descriptors.
 * @param index_filtered Indexes of descriptors to be copied.
 * @param descriptors_filtered Returns descriptors from input_list whose index are in index_filtered.
 */
void filter_DescList(opencv_descriptorslist& input_list, std::vector<int>& index_filtered, opencv_descriptorslist& descriptors_filtered);
#endif // _CLIB_IMAS_H_



