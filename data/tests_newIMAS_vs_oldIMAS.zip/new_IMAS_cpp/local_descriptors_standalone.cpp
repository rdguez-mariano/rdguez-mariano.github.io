#include "local_descriptors_standalone.h"
#include "mex_and_omp.h"


#define BIG_NUMBER 1000000000000.0f


//these are global variables
std::string desc_name="SIFT"; // descriptor being used
float default_radius = 1.8f; // the default radius for the covering


int desc_type=1;   // index for the descriptor being used
float nndrRatio = 0.8f; // Find correspondences by NNDR (Nearest Neighbor Distance Ratio)
int normType = -1; // Use default norm proposed by our program
bool binary_desc = false; // kind of descriptor is being used : binary or float
bool rooted = true; // use root versions of descriptors ex. ROOTSIFT
bool sift_desc = true;


siftPar siftparameters;

IMAS_time IMAS::IMAS_getTickCount()
{
    return(time(0));
}
double IMAS::IMAS_getTickFrequency()
{
    return(1.0f);
}

bool IMAS::IMAS_Matrix::empty()
{
    return((this->cols+this->rows)==0);
}

IMAS::IMAS_Matrix::IMAS_Matrix()
{
    cols = 0;
    rows = 0;
}

IMAS::IMAS_Matrix::IMAS_Matrix(std::vector<float> input_data, int width, int height)
{
    cols = width;
    rows = height;
    data = new float[cols*rows];
            for (int cc = 0; cc < cols*rows; cc++)
              data[cc] =input_data[cc];
}
#include "compute_IMAS_matches.h"
void updateparams()
{
    default_sift_parameters(siftparameters);
    siftparameters.MatchRatio = nndrRatio;
    mratio = nndrRatio;
    siftparameters.L2norm = (normType==IMAS::NORM_L2);
    siftparameters.MODE_ROOT = rooted;
    if (desc_type==IMAS_HALFSIFT)
    {
        siftparameters.half_sift_trick = true;
    }
}

void update_matchratio(float matchratio)
{
    siftparameters.MatchRatio = matchratio;
    surf_ratio = matchratio;
    mratio = matchratio;
}


void update_tensor_threshold(float tensor_thres)
{
    siftparameters.TensorThresh = tensor_thres;
}

void update_edge_threshold(float edge_thres)
{
    siftparameters.EdgeThresh = edge_thres;
    siftparameters.EdgeThresh1 = edge_thres;
}

void prepare_acontrario_matching(std::vector<float> im3,int w3,int h3)
{
    float* im3float = new float[w3*h3];
    for (int i=0;i<w3*h3;i++)
        im3float[i] = im3[i];

    compute_sift_keypoints(im3float,keys3,w3,h3,siftparameters);
    free(im3float);
    cout <<"    " <<keys3.size()<<" keypoints have been found in the a-contrario image"<<endl<<endl;
}

std::string SetDetectorDescriptor(int DDIndex)
{
    switch (DDIndex)
    {
    case IMAS_SIFT:
    {
        desc_name="SIFT";
        normType = IMAS::NORM_L1;
        nndrRatio = 0.73f*0.73f;
        desc_type = IMAS_SIFT;
        binary_desc = false;
        rooted = false;
        default_radius = 1.7f;
        sift_desc = true;
        break;
    }
    case IMAS_SIFT2: // ASIFT
    {
        desc_name="SIFT";
        normType = IMAS::NORM_L1;
        nndrRatio = 0.73f*0.73f;
        desc_type = IMAS_SIFT;
        binary_desc = false;
        rooted = false;
        default_radius = -1.8f;
        sift_desc = true;
        break;
    }
    case IMAS_HALFROOTSIFT:
    {
        desc_name="HalfRootSIFT";
        normType = IMAS::NORM_L2;
        nndrRatio = 0.73f*0.73f;
        desc_type = IMAS_HALFSIFT;
        binary_desc = false;
        rooted = true;
        default_radius = 1.7f;
        sift_desc = true;
        break;
    }
    case IMAS_HALFSIFT:
    {
        desc_name="HalfSIFT";
        normType = IMAS::NORM_L1;
        nndrRatio = 0.73f*0.73f;
        desc_type = IMAS_HALFSIFT;
        binary_desc = false;
        rooted = false;
        default_radius = 1.7f;
        sift_desc = true;
        break;
    }
    case IMAS_ROOTSIFT:
    {
        desc_name="RootSIFT";
        normType = IMAS::NORM_L2;
        nndrRatio = 0.73f*0.73f;
        desc_type = IMAS_ROOTSIFT;
        binary_desc = false;
        rooted = true;
        default_radius = 1.7f; //1.6 pour les petites images
        sift_desc = true;
        break;
    }
    case IMAS_SURF:
    {
        desc_name="SURF";
        normType = IMAS::NORM_L1;
        nndrRatio = 0.73f*0.73f;
        desc_type = IMAS_SURF;
        binary_desc = false;
        default_radius = 1.4f;
        sift_desc = false;
        break;
    }
    }
    updateparams();
    return(desc_name);
}



void vectorimage2opencvimage(std::vector<float>& input_image, IMAS::IMAS_Matrix &output_image, int width, int height)
{
    output_image = *(new IMAS::IMAS_Matrix(input_image,width,height));
}

void opencvimage2vectorimage(IMAS::IMAS_Matrix input_image,std::vector<float>& output_image,int& width, int& height)
{
    width = input_image.cols;
    height = input_image.rows;
    output_image.resize(width*height);
     for (int i = 0;  i < width*height; i++)
           output_image[i] = input_image.data[i];
}


void floatarray2opencvimage(float *input_image, IMAS::IMAS_Matrix &output_image, int width, int height)
{
    output_image = *(new IMAS::IMAS_Matrix);
    output_image.data = input_image;
    output_image.cols = width;
    output_image.rows = height;
}


void compute_local_descriptor_keypoints(IMAS::IMAS_Matrix &queryImg,  IMAS_keypointlist& KPs, float t, float theta)
{

    if(!queryImg.empty())
    {
        if (sift_desc)
        {
            keypointslist* keys = new keypointslist;
            compute_sift_keypoints(queryImg.data,*keys,queryImg.cols,queryImg.rows,siftparameters);
            //KPs.DescList.resize(keys->size());
            KPs.KeyList.resize(keys->size());
            for(int i=0; i<keys->size();i++)
            {
                KPs.KeyList[i].pt.x = (*keys)[i].x;
                KPs.KeyList[i].pt.y = (*keys)[i].y;
                KPs.KeyList[i].pt.kp_ptr = &((*keys)[i]);
                KPs.KeyList[i].size = (*keys)[i].radius;
                KPs.KeyList[i].scale = (*keys)[i].scale;
                KPs.KeyList[i].angle = (*keys)[i].angle;
                KPs.KeyList[i].t = t;
                KPs.KeyList[i].theta = theta;
            }
        }
        else
        {
            listDescriptor* keys = extract_surf(queryImg.data, queryImg.cols,queryImg.rows);
            KPs.KeyList.resize(keys->size());
            for(int i=0; i<keys->size();i++)
            {
                KPs.KeyList[i].pt.x = (*keys)[i]->kP->x;
                KPs.KeyList[i].pt.y = (*keys)[i]->kP->y;
                //KPs.KeyList[i].pt.kp_ptr = new descriptor(*(*keys)[i]);
                KPs.KeyList[i].pt.kp_ptr = (*keys)[i];
                KPs.KeyList[i].size = (*keys)[i]->kP->scale;
                KPs.KeyList[i].angle = (*keys)[i]->kP->orientation;
            }
        }
    }
}


void compute_local_descriptor_matches( IMAS_keypointlist& keys1, IMAS_keypointlist& keys2, matchingslist& matchings)
{
    if (keys1.KeyList.size()*keys2.KeyList.size()!=0)
    {
        if (sift_desc)
        {
            SIFT_matchingslist matchings1;
            std::vector<keypoint* > keypoints1, keypoints2;

            for(int i=0; i<(int)keys1.KeyList.size();i++)
                keypoints1.push_back(static_cast<keypoint*>(keys1.KeyList[i].pt.kp_ptr));

            for(int i=0; i<(int)keys2.KeyList.size();i++)
                keypoints2.push_back(static_cast<keypoint*>(keys2.KeyList[i].pt.kp_ptr));


            compute_sift_matches(keypoints1,keypoints2,matchings1,siftparameters);
            matchings.clear();
            for(int i=0; i<(int)matchings1.size();i++)
            {
                keypoint_simple key1, key2;

                key1.x = matchings1[i].first.x;
                key1.y = matchings1[i].first.y;
                key1.scale = matchings1[i].first.scale;
                key1.angle = matchings1[i].first.angle;
                key1.size = matchings1[i].first.radius;

                key2.x = matchings1[i].second.x;
                key2.y = matchings1[i].second.y;
                key2.scale = matchings1[i].second.scale;
                key2.angle = matchings1[i].second.angle;
                key2.size = matchings1[i].second.radius;
                matchings.push_back(matching(key1,key2));
            }
        }
        else
        {
            std::vector<MatchSurf> match_coor;
            std::vector<descriptor* > keypoints1, keypoints2;


            for(int i=0; i<(int)keys1.KeyList.size();i++)
                keypoints1.push_back(static_cast<descriptor*>(keys1.KeyList[i].pt.kp_ptr));

            for(int i=0; i<(int)keys2.KeyList.size();i++)
                keypoints2.push_back(static_cast<descriptor*>(keys2.KeyList[i].pt.kp_ptr));


            //match_surf(&keypoints1,&keypoints2, match_coor);
            match_coor=matchDescriptor(&keypoints1,&keypoints2);
            matchings.clear();

            for(int i=0; i<(int)match_coor.size();i++)
            {
                keypoint_simple key1, key2;

                key1.x = match_coor[i].x1;
                key1.y = match_coor[i].y1;
                key1.scale = match_coor[i].scale1;
                key1.angle = match_coor[i].angle1;

                key2.x = match_coor[i].x2;
                key2.y = match_coor[i].y2;
                key2.scale = match_coor[i].scale2;
                key2.angle = match_coor[i].angle2;
                matchings.push_back(matching(key1,key2));
            }

        }
    }
}
