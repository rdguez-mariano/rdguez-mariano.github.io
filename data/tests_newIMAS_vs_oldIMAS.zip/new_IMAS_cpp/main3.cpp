/*! \mainpage Documentation
 *
 * \section intro_sec Introduction
 *
 *  Here there is to be the IMAS documentation.
 *  Compute the IMAS keypoints on the input image.
 *  Please report bugs and/or send comments to Mariano Rodríguez <rdguez.mariano@gmail.com>
 *
 *
 * \section install_sec Installation
 * asdf
 *
 * \subsection tools_subsec Requirements
 * - <a href="http://docs.opencv.org/3.2.0/index.html">Opencv 3.2.0</a>
 *
 * \section run_sec Run Section
 *
 *
 *
 * \section ref_sec References:
 *  - J.M. Morel and G.Yu, ASIFT: A New Framework for Fully Affine Invariant Image Comparison, SIAM Journal on Imaging Sciences, vol. 2, issue 2, pp. 438-469, 2009.
 *  - <a href="http://www.ipol.im/pub/algo/my_affine_sift/">ASIFT online demo</a>
 *  - <a href="http://www.cmap.polytechnique.fr/~yu/research/ASIFT/demo.html">ASIFT Web Page</a>
 *
 *
 * <BR><BR>
 *
 */


#include <string>
#include <vector>

#include "local_descriptor.h"
#include "mex_and_omp.h"
#include "perform_IMAS.h"

using namespace std;

void MatrixNumerics2cvMat(std::vector<TypeMap>& input, std::vector<cv::Mat>& output)
{
    for (int i=0; i<input.size();i++)
    {
        TypeMap thismap = (input[i]);
        cv::Mat thismat;
        thismat.create(thismap.nrow(),thismap.ncol(),CV_32F);
        for (int i=0;i<thismap.ncol();i++)
        {
            for (int j=0;j<thismap.nrow();j++)
            {
                thismat.col(i).row(j) = (float) thismap(j,i);
            }
        }
        output.push_back(thismat);
    }
}


bool getCameraPhoto(cv::Mat& Img)
{
    printf("Press s to stop then c to capture \n");
    cv::Mat frame,grayframe;
        // Show the image captured from the camera in the window and repeat

    cv::VideoCapture capture( CV_CAP_ANY );
    if ( !capture.isOpened() ) {
        fprintf( stderr, "ERROR: capture is NULL \n" );
        getchar();
        return(false);
    }
    int whichkey =0;
        while ( 1 ) {
            // Get one frame
            if ( capture.grab() ) {
                capture.retrieve(frame);
            }
            cv::cvtColor(frame, grayframe, cv::COLOR_BGR2GRAY);
            cv::imshow( "CAM",  grayframe);
            cv::moveWindow("CAM", 1700,50);
            whichkey = cv::waitKey(5);
                    //printf("%i \n",whichkey);
            if (whichkey == 's')//key "s"
                if (cv::waitKey(0)=='c')
                    break;
    }
        grayframe.copyTo(Img);
        cv::Mat colorversion;
        colorversion.create(grayframe.rows, grayframe.cols, CV_8UC3);
        cv::cvtColor(grayframe, colorversion, cv::COLOR_GRAY2BGR);
        cv::putText(colorversion, "Captured", cv::Point(round(grayframe.cols/2)-100,round(grayframe.rows/2)), cv::FONT_HERSHEY_PLAIN, 3, cv::Scalar(0,255,0), 2, CV_AA);
        cv::imshow( "CAM",  colorversion);
        cv::waitKey(1000);
        cv::destroyWindow("CAM");
        cv::waitKey(100);
        return(true);
}

/**
 * @brief main
 * @param image1 Path to image1 (png)
 * @param image2 Path to image1 (png)
 * @param applyfilter Tells which filters should be applied in the function compute_IMAS_matches(). This parameter is in fact pass on to the function perform_IMAS().
 * @param ORSA_type Tells which version of ORSA should be applied (if it is to be applied in applyfilter):
 * - Homography - <a href="http://www.ipol.im/pub/art/2012/mmm-oh/">Lionel Moisan, Pierre Moulon, and Pascal Monasse, Automatic Homographic Registration of a Pair of Images, with A Contrario Elimination of Outliers, Image Processing On Line, 2 (2012), pp. 56–73</a>.
 * - Fundamental - <a href="http://www.ipol.im/pub/art/2016/147/">Lionel Moisan, Pierre Moulon, and Pascal Monasse, Fundamental Matrix of a Stereo Pair, with A Contrario Elimination of Outliers, Image Processing On Line, 6 (2016), pp. 89–113</a>.
 * @param IMAS_INDEX Tells which descriptor+extractor to use from local_descriptor.h
 * @param visualize (Optional) Tells if results should also be displayed on the screen.
 * @param radius (Optional) Forces to use a predefined log(radius)-covering instead of the default one.
 *
 *
 * @code
 * // Execute Affine-RootSIFT and apply ORSA Homography & Misc
 * ./main "image1.png" "image2.png" 7 0 11
 *
 * // Execute Affine-SURF and apply ORSA Homography & Misc
 * ./main "image1.png" "image2.png" 7 0 2
 *
 * // Execute Affine-SIFT silently (no screen, but results are written on disc)
 * ./main "image1.png" "image2.png" 7 0 1 0
 *
 * // Execute Affine-SIFT on the screen and use the optimal log(1.7)-covering
 * ./main "image1.png" "image2.png" 7 0 1 1 1.7
 * @endcode
 */

int main(int argc, char **argv)
{

// Read images
    cv::Mat queryImg,targetImg;
    int w1, h1, w2, h2;
    std::vector<float> ipixels1, ipixels2;

    // Show the image captured from the camera in the window and repeat
    getCameraPhoto(queryImg);
    opencvimage2vectorimage(queryImg,ipixels1,w1,h1);

    getCameraPhoto(targetImg);
    opencvimage2vectorimage(targetImg,ipixels2,w2,h2);

// Setting variables
    int flag_resize = 0;
    int applyfilter = atoi(argv[3]);
    int orsa_type = atoi(argv[4]);
    int IMAS_INDEX = atoi(argv[5]);
    bool visualize = true;

    if (argc>=7)
        if (atoi(argv[6])==0)
            visualize = false;

orsa_type = 0;
applyfilter = 7;
    IMAS_INDEX=1;
    int affine=0;
while (IMAS_INDEX>=0)
{
    printf("Enter IMAS_INDEX: \n");
    cin >> IMAS_INDEX;
    printf("Affine Simulations?: \n");
    cin >> affine;
   string algo_name;
   if (affine==0)
   {
       algo_name= SetDetectorDescriptor(IMAS_INDEX);//not working NOW: LUCID, AGAST
       default_radius = 1;
   }
   else
   {
       algo_name= "Affine-"+SetDetectorDescriptor(IMAS_INDEX);//not working NOW: LUCID, AGAST
   if ((IMAS_INDEX==IMAS_SIFT)||(IMAS_INDEX==IMAS_SURF))
       algo_name ="Optimal-"+algo_name;
}



// Number of threads to use
    int nthreads, maxthreads;
       /* Display info on OpenMP*/
               #pragma omp parallel
           {
               #pragma omp master
               {
                   nthreads = my_omp_get_num_threads();
                   maxthreads = my_omp_get_max_threads();
               }
           }
 my_mexPrintf("--> Using %d threads out of %d for executing %s <--\n\n",nthreads,maxthreads,algo_name.c_str());




 // Performing IMAS
    vector< vector <float> > Minfoall;
    matchingslist matchings;
    vector< float > data;

    if (argc>=8)
        default_radius = atof(argv[7]);

    loadsimulations2do(default_radius);
    if (orsa_type==1)
    {
        Tmin = 8;
        ORSA_Fundamental = true;
    }
    else
    {
        Tmin = 5;
        ORSA_Fundamental = false;
    }

    perform_IMAS(ipixels1, w1, h1, ipixels2, w2, h2, data, matchings, Minfoall, flag_resize, applyfilter);


if (matchings.size()>0)
{
//Output file "data_matches.csv"

    int wo = 14;
    ofstream myfile;
    myfile.open ("data_matches.csv", std::ofstream::out | std::ofstream::trunc);
    int cont =1;
    myfile << ((double) data[0]) << ",";

    for ( int i = 1; i < (int) (wo*matchings.size()); i++ )
    {
        if (cont ==(wo-1))
        {
            myfile << ((double) data[i]) << endl;
            cont = 0;
        }
        else
        {
            myfile << ((double) data[i]) << ",";
            cont = cont +1;
        }

    }
     myfile.close();



     //Showing Results
     cv::Mat all_matches;
     std::vector<cv::DMatch> goodmatches;
     opencv_keypointslist queryKeypoints, targetKeypoints;
     matching* thismatching;

     for (int i=0;i<(int)matchings.size();i++)
     {
         thismatching=&(matchings[i]);
         queryKeypoints.push_back( cv::KeyPoint(thismatching->first.x, thismatching->first.y, thismatching->first.scale));
         targetKeypoints.push_back( cv::KeyPoint(thismatching->second.x, thismatching->second.y, thismatching->second.scale));
         goodmatches.push_back(cv::DMatch(i, i, 0));
     }

     cv::drawMatches( queryImg, queryKeypoints, targetImg, targetKeypoints,
                          goodmatches, all_matches,
                      cv::Scalar::all(-1), cv::Scalar::all(-1),
                      vector<char>(), cv::DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS );

    cv::imwrite("result.png",all_matches);


    cv::Mat QueryOnTarget;
    std::vector<cv::Mat> MMap;
    MatrixNumerics2cvMat(IdentifiedMaps,MMap);
    if ((!ORSA_Fundamental)&&(!MMap.empty()))
    {
        cv::warpPerspective(queryImg,QueryOnTarget,MMap[0],cv::Size(targetImg.cols,targetImg.rows));
        QueryOnTarget = 2*QueryOnTarget/4+ 2*targetImg/4;
        cv::imwrite("QueryOnTarget.png",QueryOnTarget);
    }


     if (visualize)
     {
         cv::waitKey(100);
         cv::imshow(algo_name+" matches", all_matches );
         cv::moveWindow(algo_name+" matches", 1650,50);
         cv::waitKey(100);

         if ((!QueryOnTarget.empty()))
         {
             cv::imshow( algo_name+" (identified homography)", QueryOnTarget );
             cv::moveWindow(algo_name+" (identified homography)", 1650,all_matches.rows+50);
         }

         cv::waitKey(100);
     }
}

// Clear memory
     data.clear();
     matchings.clear();
     Minfoall.clear();
     simu_details1.clear();
     simu_details2.clear();
}

    return 0;
}
