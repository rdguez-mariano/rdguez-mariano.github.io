
#include "fproj.h"
#include "perform_IMAS.h"

using namespace std;

/**
 * @brief Performs the Formal IMAS algorithm.
 * @param ipixels1 image1
 * @param w1 Width of image1
 * @param h1 Height of image1
 * @param ipixels2 image2
 * @param w2 Width of image2
 * @param h2 Height of image2
 * @param data Returns a Nx14 matrix representing data for N matches.
 * <table>
  <tr>
    <th>Columns</th>
    <th>Comments</th>
  </tr>
  <tr>
    <td> x_1 </td>
    <td> First coordinate from keypoints on image1 </td>
  </tr>
  <tr>
    <td> y_1 </td>
    <td> Second coordinate from keypoints on image1 </td>
  </tr>
  <tr>
    <td> scale_1 </td>
    <td> scale from keypoints from image1 </td>
  </tr>
  <tr>
    <td> angle_1 </td>
    <td> angle from keypoints from image1 </td>
  </tr>
  <tr>
    <td> t1_1 </td>
    <td> Tilt on image1 in the x-direction from which the keypoints come </td>
  </tr>
  <tr>
    <td> t2_1 </td>
    <td>Tilt on image1 in the y-direction from which the keypoints come  </td>
  </tr>
  <tr>
    <td> theta_1 </td>
    <td> Rotation that was applied before simulating the optical tilt on image1 </td>
  </tr>
  <tr>
    <td> x_2 </td>
    <td> First coordinate from keypoints on image2 </td>
  </tr>
  <tr>
    <td> y_2 </td>
    <td> Second coordinate from keypoints on image2 </td>
  </tr>
  <tr>
    <td> scale_2 </td>
    <td> scale from keypoints from image2 </td>
  </tr>
  <tr>
    <td> angle_2 </td>
    <td> angle from keypoints from image2 </td>
  </tr>
  <tr>
    <td> t1_2 </td>
    <td> Tilt on image2 in the x-direction from which the keypoints come </td>
  </tr>
  <tr>
    <td> t2_2 </td>
    <td> Tilt on image2 in the y-direction from which the keypoints come  </td>
  </tr>
  <tr>
    <td> theta_2 </td>
    <td> Rotation that was applied before simulating the optical tilt on image2 </td>
  </tr>

</table>
 * @param matchings Returns the matches
 * @param Minfoall Returns more info on the matches
 * @param flag_resize Tells the algo if you want to resize the image
 * @param applyfilter Tells which filters should be applied in the function compute_IMAS_matches()
 */
void perform_IMAS(vector<float>& ipixels1, int w1, int h1, vector<float>& ipixels2, int w2, int h2, vector<float>& data, matchingslist& matchings, int flag_resize, int applyfilter)
{
    ///// Resize the images to area wS*hW in remaining the apsect-ratio
    ///// Resize if the resize flag is not set or if the flag is set unequal to 0
    float wS = IM_X;
    float hS = IM_Y;

    float zoom1=0, zoom2=0;
    int wS1=0, hS1=0, wS2=0, hS2=0;
    vector<float> ipixels1_zoom, ipixels2_zoom;


    if ( (flag_resize != 0))
    {
        //my_mexPrintf("t1=%.2f, theta1=%.2f, num keys1 = %d, t2=%.2f, theta2=%.2f, num keys2 = %d, num matches=%d\n", t, theta, (int) keypoints1.size(),
        my_mexPrintf("WARNING: The input images are resized to %i x %i \n But the results will be normalized to the original image size.\n", (int)wS,(int)hS);

        float InitSigma_aa = 1.6;

        float fproj_p, fproj_bg;
        char fproj_i;
        float *fproj_x4, *fproj_y4;
        int fproj_o;

        fproj_o = 3;
        fproj_p = 0;
        fproj_i = 0;
        fproj_bg = 0;
        fproj_x4 = 0;
        fproj_y4 = 0;

        float areaS = wS * hS;

        // Resize image 1
        float area1 = w1 * h1;
        zoom1 = sqrt(area1/areaS);

        wS1 = (int) (w1 / zoom1);
        hS1 = (int) (h1 / zoom1);

        int fproj_sx = wS1;
        int fproj_sy = hS1;

        float fproj_x1 = 0;
        float fproj_y1 = 0;
        float fproj_x2 = wS1;
        float fproj_y2 = 0;
        float fproj_x3 = 0;
        float fproj_y3 = hS1;

        /* Anti-aliasing filtering along vertical direction */
        if ( zoom1 > 1 )
        {
            float sigma_aa = InitSigma_aa * zoom1 / 2;
            GaussianBlur1D(ipixels1,w1,h1,sigma_aa,1);
            GaussianBlur1D(ipixels1,w1,h1,sigma_aa,0);
        }

        // simulate a tilt: subsample the image along the vertical axis by a factor of t.
        ipixels1_zoom.resize(wS1*hS1);
        fproj (ipixels1, ipixels1_zoom, w1, h1, &fproj_sx, &fproj_sy, &fproj_bg, &fproj_o, &fproj_p,
               &fproj_i , fproj_x1 , fproj_y1 , fproj_x2 , fproj_y2 , fproj_x3 , fproj_y3, fproj_x4, fproj_y4);


        // Resize image 2
        float area2 = w2 * h2;
        zoom2 = sqrt(area2/areaS);

        wS2 = (int) (w2 / zoom2);
        hS2 = (int) (h2 / zoom2);

        fproj_sx = wS2;
        fproj_sy = hS2;

        fproj_x2 = wS2;
        fproj_y3 = hS2;

        /* Anti-aliasing filtering along vertical direction */
        if ( zoom1 > 1 )
        {
            float sigma_aa = InitSigma_aa * zoom2 / 2;
            GaussianBlur1D(ipixels2,w2,h2,sigma_aa,1);
            GaussianBlur1D(ipixels2,w2,h2,sigma_aa,0);
        }

        // simulate a tilt: subsample the image along the vertical axis by a factor of t.
        ipixels2_zoom.resize(wS2*hS2);
        fproj (ipixels2, ipixels2_zoom, w2, h2, &fproj_sx, &fproj_sy, &fproj_bg, &fproj_o, &fproj_p,
               &fproj_i , fproj_x1 , fproj_y1 , fproj_x2 , fproj_y2 , fproj_x3 , fproj_y3, fproj_x4, fproj_y4);
    }
    else
    {
        ipixels1_zoom.resize(w1*h1);
        ipixels1_zoom = ipixels1;
        wS1 = w1;
        hS1 = h1;
        zoom1 = 1;

        ipixels2_zoom.resize(w2*h2);
        ipixels2_zoom = ipixels2;
        wS2 = w2;
        hS2 = h2;
        zoom2 = 1;
    }


    ///// Compute IMAS keypoints
    std::vector<IMAS::IMAS_KeyPoint*> keys1;
    std::vector<IMAS::IMAS_KeyPoint*> keys2;
    keys1.clear();
    keys2.clear();

    int num_keys1=0, num_keys2=0;


    my_mexPrintf("Keypoints computation with %s...\n",desc_name.c_str());

    IMAS_time tstart = IMAS::IMAS_getTickCount();


    std::vector<float> stats1,stats2;
    num_keys1 = compute_IMAS_keypoints(ipixels1_zoom, wS1, hS1, keys1, simu_details1,stats1);
    num_keys2 = compute_IMAS_keypoints(ipixels2_zoom, wS2, hS2, keys2, simu_details2,stats2);

    my_mexPrintf("   %d IMAS-keypoints from %d tilted keypoints have been found in %d simulated versions of image 1\n", num_keys1,(int)stats1[0],totsimu1);
    my_mexPrintf("      stats: group_min = %d , group_mean = %.3f, group_max = %d\n",(int)stats1[1],stats1[2],(int)stats1[3]);

    my_mexPrintf("   %d IMAS-keypoints from %d tilted keypoints have been found in %d simulated versions of image 2\n", num_keys2,(int)stats2[0],totsimu2);
    my_mexPrintf("      stats: group_min = %d , group_mean = %.3f, group_max = %d\n",(int)stats2[1],stats2[2],(int)stats2[3]);

    my_mexPrintf("Keypoints computation accomplished in %.2f seconds.\n \n", (IMAS::IMAS_getTickCount() - tstart)/ IMAS::IMAS_getTickFrequency());


    //// Match IMAS keypoints
    compute_IMAS_matches(wS1, hS1, wS2, hS2, keys1, keys2, matchings, applyfilter);



    //my_mexPrintf("matchinglist.size=%d y Minfoall.size=%d\n",matchings.size(),Minfoall.size());

    /* Generate data matrix: matchinglist and Minfoall */
    for ( int i = 0; i < (int) matchings.size(); i++ )
    {
        matching *ptr_in = &(matchings[i]);
        // there are 14 rows of info
        data.push_back(ptr_in->first.x); //x1_in
        data.push_back(ptr_in->first.y); //y1_in
        data.push_back(ptr_in->first.scale); //s1_in
        data.push_back(ptr_in->first.angle); //a1_in
        data.push_back(1); //t1
        data.push_back(ptr_in->first.t); //t2
        data.push_back(ptr_in->first.theta); //theta

        data.push_back(ptr_in->second.x); //x2_in
        data.push_back(ptr_in->second.y); //y2_in
        data.push_back(ptr_in->second.scale); //s2_in
        data.push_back(ptr_in->second.angle); //a2_in
        data.push_back(1); //t_im2_1
        data.push_back(ptr_in->second.t); //t_im2_2
        data.push_back(ptr_in->second.theta); //theta2
    }


    my_mexPrintf("Done.\n\n");
    keys1.clear();
    keys2.clear();
    ipixels1_zoom.clear();
    ipixels2_zoom.clear();

}
