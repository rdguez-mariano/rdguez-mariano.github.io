/**
  * @file local_descriptor_standalone.h
  * @author Mariano Rodríguez
  * @date 2017
  * @brief Handles local descriptors matching methods to be used under IMAS
  * @warning This file is made available for the exclusive aim of serving as scientific tool to verify of the soundness and completeness of the algorithm description. Compilation, execution and redistribution of this file may violate exclusive patents rights in certain countries. The situation being different for every country and changing over time, it is your responsibility to determine which patent rights restrictions apply to you before you compile, use, modify, or redistribute this file. A patent lawyer is qualified to make this determination.
  */

#ifndef _CLIB_IMAS_H_
#define _CLIB_IMAS_H_


#include <string>
#include <vector>
#include <time.h>
#include "libLocalDesc/sift/demo_lib_sift.h"
#include "libLocalDesc/surf/extract_surf.h"
#include "libLocalDesc/surf/lib_match_surf.h"


#define IMAS_SIFT 1
#define IMAS_SURF 2
#define IMAS_ROOTSIFT 11
#define IMAS_SIFT2 12
#define IMAS_HALFSIFT 21
#define IMAS_HALFROOTSIFT 22


typedef time_t IMAS_time;

extern bool sift_desc;


/**
 * @brief The local descriptor name as in the literature
 */
extern std::string desc_name;

/**
 * @brief Determines which log(radius)-covering to use. Normally set to the maximum tilt tolerance of the matching method.
 */
extern float default_radius;

namespace IMAS
{
class IMAS_Matrix
{
public:
   IMAS_Matrix();
   IMAS_Matrix(std::vector<float> input_data, int width, int height);
   float* data;
   int cols; //= width
   int rows; //= height
   bool empty();
};
IMAS_time IMAS_getTickCount();
double IMAS_getTickFrequency();

struct point_data // Use keypoint from libsift.h
{
    float x;
    float y;
    void* kp_ptr;
    //struct keypoint* kp_ptr;
};

struct tilted_KeyPoint
{
    float size;
    float angle;
    float t;
    float theta;
    float scale;
    point_data pt;
};

struct IMAS_KeyPoint
{
  float x, y, sum_x, sum_y;
  std::vector< tilted_KeyPoint> KPvec;
};

const int NORM_L1 = 1;
const int NORM_L2 = 2;

}



/**
 * @brief opencv_keypointslist is only to be used inside local_descriptor.cpp or handled when filtering in compute_IMAS_matches.cpp
 */
typedef std::vector<IMAS::tilted_KeyPoint> opencv_keypointslist;

/**
 * @brief opencv_descriptorslist is only to be used inside local_descriptor.cpp or handled when filtering in compute_IMAS_matches.cpp
 */
typedef std::vector< IMAS::IMAS_Matrix > opencv_descriptorslist;

/**
 * @brief Provides the class in which the IMAS algorithm will handle keypoints and descriptors.
 */
class IMAS_keypointlist
{
public:
    opencv_keypointslist KeyList;
    opencv_descriptorslist DescList;
};

/**
 * @brief This is a simpler version of keypoints that will be handle inside IMAS.
 */
struct keypoint_simple {
    float	x,y,
        scale, size,theta,t,
        angle;
};

//struct keypoint_simple {
//    float	x,y,
//        scale, size,
//        angle;
//};

/**
 * @brief The very definition of a match for IMAS.
 */
typedef std::pair<keypoint_simple,keypoint_simple> matching;

/**
 * @brief A list of matches following the structure of IMAS.
 */
typedef std::vector<matching> matchingslist;




/**
 * @brief It loads the detector and descriptor index in IMAS.
 * @param DDIndex The IMAS Index of the matching method.
 * @return The name of the matching method that has been selected.
 * @code
 cout<< "The " << SetDetectorDescriptor(IMAS_SIFT) << " has been selected" << endl;
 * @endcode
 */
std::string SetDetectorDescriptor(int DDIndex);

/**
 * @brief Computes keypoints and descriptors from the matching method that has been selected.
 * @param queryImg Input image from which to compute keypoints.
 * @param KPs Returns the computation of keypoints and descriptors.
 */
void compute_local_descriptor_keypoints(IMAS::IMAS_Matrix& queryImg,  IMAS_keypointlist& KPs, float t, float theta);

/**
 * @brief Runs the matcher.
 * @param keys1 keypoints and descriptors from image1
 * @param keys2 keypoints and descriptors from image2
 * @param matchings Returns the matches in a matchinglist.
 */
void compute_local_descriptor_matches( IMAS_keypointlist& keys1, IMAS_keypointlist& keys2, matchingslist& matchings);

/**
 * @brief Converts an array image into an opencv image.
 * @param input_image The image to be copied
 * @param output_image Returns the image in the opencv structure.
 * @param width The width of the input_image.
 * @param height The height of the input_image.
 */
void floatarray2opencvimage(float *input_image,IMAS::IMAS_Matrix& output_image,int width, int height);

/**
 * @brief Converts a vector image into an opencv image.
 * @param input_image Input image
 * @param output_image Output image
 * @param width Width of the input image
 * @param height Height of the input image
 */
void vectorimage2opencvimage(std::vector<float>& input_image,IMAS::IMAS_Matrix& output_image,int width, int height);

/**
 * @brief Converts an opencv image into a vector image.
 * @param input_image Input image
 * @param output_image Output image
 * @param width Returns the width for the output image
 * @param height Returns the height for the output image
 */
void opencvimage2vectorimage(IMAS::IMAS_Matrix input_image,std::vector<float>& output_image,int& width, int& height);



void prepare_acontrario_matching(std::vector<float> im3, int w3, int h3);
void update_matchratio(float matchratio);
void update_edge_threshold(float edge_thres);
void update_tensor_threshold(float tensor_thres);

struct siftPar;
extern siftPar siftparameters;
#endif // _CLIB_IMAS_H_
