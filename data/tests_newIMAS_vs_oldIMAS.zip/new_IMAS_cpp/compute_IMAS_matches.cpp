#include "compute_IMAS_matches.h"
#include "libOrsa/orsa_fundamental.hpp"
#include "libOrsa/orsa_homography.hpp"


int Tmin = 5;
bool ORSA_Fundamental = false;
double ORSA_precision=24;
std::vector<TypeMap> IdentifiedMaps;

using namespace std;





/** @brief Removes the repetitive matches that appear in different simulations and retains only one */
void unique_match1(matchingslist &seg_in, matchingslist &seg_out)
{
    int i_in, i_out;
    float x1_in, x2_in, y1_in, y2_in, x1_out, x2_out, y1_out, y2_out;
    int flag_unique;
    float d1, d2;
    int Th2 = 2;

    seg_out.push_back(seg_in[0]);

    /* For other matches */
    if ( seg_in.size() > 1 )
    {
        /* check if a match is unique. if yes, copy */
        /* Bug fix by Xiaoyu Sun (Sichuan university) (Dec 13, 2015) */
        /* Original version
        matchingslist::iterator ptr_in = seg_in.begin();
        for ( i_in = 1; i_in < (int) seg_in.size(); i_in++, ptr_in++ )
        */
        /* Bug fixed */
        matchingslist::iterator ptr_in = seg_in.begin();
        ptr_in++;
        for ( i_in = 1; i_in < (int) seg_in.size(); i_in++, ptr_in++ )
        {
            x1_in = ptr_in->first.x;
            y1_in = ptr_in->first.y;
            x2_in = ptr_in->second.x;
            y2_in = ptr_in->second.y;

            flag_unique = 1;

            matchingslist::iterator ptr_out = seg_out.begin();
            for ( i_out = 0; i_out < (int) seg_out.size(); i_out++, ptr_out++ )
            {
                x1_out = ptr_out->first.x;
                y1_out = ptr_out->first.y;
                x2_out = ptr_out->second.x;
                y2_out = ptr_out->second.y;

                d1 = (x1_in - x1_out)*(x1_in - x1_out) + (y1_in - y1_out)*(y1_in - y1_out);
                d2 = (x2_in - x2_out)*(x2_in - x2_out) + (y2_in - y2_out)*(y2_in - y2_out);


                if ( ( d1 <= Th2) && ( d2 <= Th2) )
                {
                    flag_unique = 0;
                    //printf("x1_out=%i, y1_out=%i, x2_out=%i, y2_out=%i  \n", (int) matchings.size());
                    continue;
                }
            }

            if ( flag_unique == 1 )
            {
                seg_out.push_back(seg_in[i_in]);
            }
        }
    }
}

///** @brief Removes the ALL one-to-multiple matches. */
//void clean_match1(matchingslist &seg_in, matchingslist &seg_out, vector< vector <float> > &Minfoall_in, vector< vector <float> > &Minfoall_out)
//{
//    int i1, i2;
//    float x1_in, x2_in, y1_in, y2_in, x1_out, x2_out, y1_out, y2_out;

//    // Guoshen Yu, 2010.09.22, Windows version
//    // int flag_unique[seg_in.size()];
//    int tmp_size = seg_in.size();
//    int *flag_unique = new int[tmp_size];

//    int sum_flag=0;
//    float d1, d2;
//    int Th1 = 1;
//    int Th2 = 4;

//    for ( i1 = 0; i1 < (int) seg_in.size(); i1++ )
//    {
//        flag_unique[i1] = 1;
//    }

//    /* Set the flag of redundant matches to 0. */
//    matchingslist::iterator ptr_in = seg_in.begin();
//    for ( i1 = 0; i1 < (int) seg_in.size() - 1; i1++, ptr_in++ )
//    {
//        x1_in = ptr_in->first.x;
//        y1_in = ptr_in->first.y;
//        x2_in = ptr_in->second.x;
//        y2_in = ptr_in->second.y;

//        matchingslist::iterator ptr_out = ptr_in+1;
//        for ( i2 = i1 + 1; i2 < (int) seg_in.size(); i2++, ptr_out++ )
//        {
//            x1_out = ptr_out->first.x;
//            y1_out = ptr_out->first.y;
//            x2_out = ptr_out->second.x;
//            y2_out = ptr_out->second.y;

//            d1 = (x1_in - x1_out)*(x1_in - x1_out) + (y1_in - y1_out)*(y1_in - y1_out);
//            d2 = (x2_in - x2_out)*(x2_in - x2_out) + (y2_in - y2_out)*(y2_in - y2_out);

//            /* If redundant, set flags of both elements to 0.*/
//            if ( ( ( d1 <= Th1) && ( d2 > Th2) ) || ( ( d1 > Th2) && ( d2 <= Th1) ) )
//            {
//                flag_unique[i1] = 0;
//                flag_unique[i2] = 0;
//            }
//        }
//    }

//    for ( i1 = 0; i1 < (int) seg_in.size(); i1++ )
//    {
//        sum_flag += flag_unique[i1];
//    }

//    /* Copy the matches that are not redundant */
//    if ( sum_flag > 0 )
//    {
//        for (  i1 = 0; i1 < (int) seg_in.size(); i1++ )
//        {
//            if ( flag_unique[i1] == 1 )
//            {
//                seg_out.push_back(seg_in[i1]);
//                Minfoall_out.push_back(Minfoall_in[i1]);
//            }
//        }
//    }
//    else
//    {
//        my_mexPrintf("Warning: all matches are redundant and are thus removed! This step of match cleaning is short circuited. (Normally this should not happen...)\n");
//    }

//    // Guoshen Yu, 2010.09.22, Windows version
//    delete [] flag_unique;
//}


///** @brief Removes the ALL multiple-to-one matches */
//void clean_match2(matchingslist &seg_in, matchingslist &seg_out, vector< vector <float> > &Minfoall_in, vector< vector <float> > &Minfoall_out)
//{
//    int i1, i2;
//    float x1_in, x2_in, y1_in, y2_in, x1_out, x2_out, y1_out, y2_out;

//    // Guoshen Yu, 2010.09.22, Windows version
//    // int flag_unique[seg_in.size()];
//    int tmp_size = seg_in.size();
//    int *flag_unique = new int[tmp_size];

//    int sum_flag=0;
//    float d1, d2;
//    int Th1 = 1;
//    int Th2 = 4;

//    for ( i1 = 0; i1 < (int) seg_in.size(); i1++ )
//    {
//        flag_unique[i1] = 1;
//    }

//    /* Set the flag of redundant matches to 0. */
//    matchingslist::iterator ptr_in = seg_in.begin();
//    for ( i1 = 0; i1 < (int) seg_in.size() - 1; i1++, ptr_in++ )
//    {
//        x1_in = ptr_in->first.x;
//        y1_in = ptr_in->first.y;
//        x2_in = ptr_in->second.x;
//        y2_in = ptr_in->second.y;

//        matchingslist::iterator ptr_out = ptr_in+1;
//        for ( i2 = i1 + 1; i2 < (int) seg_in.size(); i2++, ptr_out++ )
//        {

//            x1_out = ptr_out->first.x;
//            y1_out = ptr_out->first.y;
//            x2_out = ptr_out->second.x;
//            y2_out = ptr_out->second.y;

//            d1 = (x1_in - x1_out)*(x1_in - x1_out) + (y1_in - y1_out)*(y1_in - y1_out);
//            d2 = (x2_in - x2_out)*(x2_in - x2_out) + (y2_in - y2_out)*(y2_in - y2_out);


//            /* If redundant, set flags of both elements to 0.*/
//            if ( ( d1 > Th2) && ( d2 <= Th1) )
//            {
//                flag_unique[i1] = 0;
//                flag_unique[i2] = 0;
//            }
//        }
//    }

//    for ( i1 = 0; i1 < (int) seg_in.size(); i1++ )
//    {
//        sum_flag += flag_unique[i1];
//    }

//    /* Copy the matches that are not redundant */
//    if ( sum_flag > 0 )
//    {
//        for (  i1 = 0; i1 < (int) seg_in.size(); i1++ )
//        {
//            if ( flag_unique[i1] == 1 )
//            {
//                seg_out.push_back(seg_in[i1]);
//                Minfoall_out.push_back(Minfoall_in[i1]);
//            }
//        }
//    }
//    else
//    {
//        my_mexPrintf("Warning: all matches are redundant and are thus removed! This step of match cleaning is short circuited. (Normally this should not happen...)\n");
//    }

//    // Guoshen Yu, 2010.09.22, Windows version
//    delete [] flag_unique;
//}


/** @brief Normalizes the coordinates of the matched points by compensating the simulate affine transformations
 */
void compensate_affine_coor(matching &matching1, int w1, int h1, int w2, int h2, float t1, float t2, float Rtheta, float t_im2_1, float t_im2_2, float Rtheta2)
{
    float x_ori, y_ori;
    float x_ori2, y_ori2, x_tmp, y_tmp;
    float x1, y1, x2, y2;

    Rtheta = Rtheta*M_PI/180;

    ///// Cambiar aquí para que acepte angulos entre 0 y 2pi. Usar mi código MATLAB!
    if ( Rtheta <= M_PI/2 )
    {
        x_ori = 0;
        y_ori = w1 * sin(Rtheta) / t1;
    }
    else
    {
        x_ori = -w1 * cos(Rtheta) / t2;
        y_ori = ( w1 * sin(Rtheta) + h1 * sin(Rtheta-M_PI/2) ) / t1;
    }

    Rtheta2 = Rtheta2*M_PI/180;

    if ( Rtheta2 <= M_PI/2 )
    {
        x_ori2 = 0;
        y_ori2 = w2 * sin(Rtheta2) / t_im2_1;
    }
    else
    {
        x_ori2 = -w2 * cos(Rtheta2) / t_im2_2;
        y_ori2 = ( w2 * sin(Rtheta2) + h2 * sin(Rtheta2-M_PI/2) ) / t_im2_1;
    }

    float sin_Rtheta = sin(Rtheta);
    float cos_Rtheta = cos(Rtheta);
    float sin_Rtheta2 = sin(Rtheta2);
    float cos_Rtheta2 = cos(Rtheta2);

    x1 = matching1.first.x;
    y1 = matching1.first.y;
    x2 = matching1.second.x;
    y2 = matching1.second.y;

    /* project the coordinates of im1 to original image before tilt-rotation transform */
    /* Get the coordinates with respect to the 'origin' of the original image before transform */
    x1 = x1 - x_ori;
    y1 = y1 - y_ori;
    /* Invert tilt */
    x1 = x1 * t2;
    y1 = y1 * t1;
    /* Invert rotation (Note that the y direction (vertical) is inverse to the usual concention. Hence Rtheta instead of -Rtheta to inverse the rotation.) */
    x_tmp = cos_Rtheta*x1 - sin_Rtheta*y1;
    y_tmp = sin_Rtheta*x1 + cos_Rtheta*y1;
    x1 = x_tmp;
    y1 = y_tmp;

    /* Coordinate projection on image2  */

    /* Get the coordinates with respect to the 'origin' of the original image before transform */
    x2 = x2 - x_ori2;
    y2 = y2 - y_ori2;
    /* Invert tilt */
    x2 = x2 * t_im2_2;
    y2 = y2 * t_im2_1;
    /* Invert rotation (Note that the y direction (vertical) is inverse to the usual concention. Hence Rtheta instead of -Rtheta to inverse the rotation.) */
    x_tmp = cos_Rtheta2*x2 - sin_Rtheta2*y2;
    y_tmp = sin_Rtheta2*x2 + cos_Rtheta2*y2;
    x2 = x_tmp;
    y2 = y_tmp;

    matching1.first.x = x1;
    matching1.first.y = y1;
    matching1.second.x = x2;
    matching1.second.y = y2;
}


/**
 * @brief Applies an Epipolar filter based on the article: <a href="http://www.ipol.im/pub/art/2016/147/">Lionel Moisan, Pierre Moulon, and Pascal Monasse, Fundamental Matrix of a Stereo Pair, with A Contrario Elimination of Outliers, Image Processing On Line, 6 (2016), pp. 89–113</a>.
 * @param matchings Current matches
 * @param w1 Width of image1
 * @param h1 Height of image1
 * @param w2 Width of image2
 * @param h2 Height of image2
 * @param nfa_max Maximum accepted nfa to consider a map as meaningul.
 * @param ITER_ORSA Maximum number of iterations to be applied in Orsa.
 * @param precision Imposed precision in pixels for ORSA Fundamental. In other words, the distance from a point to the epipolar line should be less than equal to precision. Put precision<=0 if no precision is needed.
 * @param verb Verbose mode
 */
void EpipolarFilter(matchingslist& matchings,int w1,int h1,int w2,int h2, double nfa_max,int ITER_ORSA,double precision,bool verb)
{
    //////// Use ORSA to filter out the incorrect matches.
    // store the coordinates of the matching points
    vector<Match> match_coor;
    for (int cc = 0; cc < (int) matchings.size(); cc++ )
    {
        Match match1_coor;
        match1_coor.x1 = matchings[cc].first.x;
        match1_coor.y1 = matchings[cc].first.y;
        match1_coor.x2 = matchings[cc].second.x;
        match1_coor.y2 = matchings[cc].second.y;

        match_coor.push_back(match1_coor);
    }
    // Estimation of fundamental matrix with ORSA
    matchingslist matchings_unique;
    libNumerics::matrix<double> F(3,3);
    std::vector<int> vec_inliers;
    double nfa;
    orsa::orsa_fundamental(match_coor, w1,h1,w2,h2, precision, ITER_ORSA,F, vec_inliers,nfa,verb);



    // if the matching is significant, register the good matches
    if ( nfa < nfa_max )
    {
        //  std::cout << "F=" << F <<std::endl;
        // extract meaningful matches
        matchings_unique.clear();
        for (int cc = 0; cc < (int) vec_inliers.size(); cc++ )
        {
            matchings_unique.push_back(matchings[vec_inliers[cc]]);
        }
        matchings.clear();

        for (int cc = 0; cc < (int) vec_inliers.size(); cc++ )
        {
            matchings.push_back(matchings_unique[cc]);
        }

        IdentifiedMaps.clear();
        IdentifiedMaps.push_back(F);

        if (verb)
        {
            my_mexPrintf("The two images match! %d matchings are identified. log(nfa)=%.2f.\n", (int) matchings.size(), nfa);
            std::cout << "*************** Fundamental Matrix ***************"<< std::endl;
            std::cout << F <<std::endl;
            std::cout << "**************************************************"<< std::endl;
        }



    }
    else
    {
        matchings.clear();
        if (verb)
            my_mexPrintf("The two images do not match. The matching is not significant:  log(nfa)=%.2f.\n", nfa);
    }
}

/**
 * @brief Applies an Homography filter based on the article: <a href="http://www.ipol.im/pub/art/2012/mmm-oh/">Lionel Moisan, Pierre Moulon, and Pascal Monasse, Automatic Homographic Registration of a Pair of Images, with A Contrario Elimination of Outliers, Image Processing On Line, 2 (2012), pp. 56–73</a>.
 * @param matchings Current matches
 * @param w1 Width of image1
 * @param h1 Height of image1
 * @param w2 Width of image2
 * @param h2 Height of image2
 * @param nfa_max Maximum accepted nfa to consider a map as meaningul.
 * @param ITER_ORSA Maximum number of iterations to be applied in Orsa.
 * @param precision Imposed precision in pixels for ORSA Homography. In other words, the distance from a point to the plane should be less than equal to precision. Put precision<=0 if no precision is needed.
 * @param verb Verbose mode
 */
void HomographyFilter(matchingslist& matchings,int w1,int h1,int w2,int h2, double nfa_max,int ITER_ORSA,double precision,bool verb)
{
    //////// Use ORSA to filter out the incorrect matches.
    // store the coordinates of the matching points
    vector<Match> match_coor;
    for (int cc = 0; cc < (int) matchings.size(); cc++ )
    {
        Match match1_coor;
        match1_coor.x1 = matchings[cc].first.x;
        match1_coor.y1 = matchings[cc].first.y;
        match1_coor.x2 = matchings[cc].second.x;
        match1_coor.y2 = matchings[cc].second.y;

        match_coor.push_back(match1_coor);
    }
    // Estimation of fundamental matrix with ORSA
    matchingslist matchings_unique;
    libNumerics::matrix<double> H(3,3);
    std::vector<int> vec_inliers;
    double nfa;
    orsa::ORSA_homography(match_coor, w1,h1,w2,h2, precision, ITER_ORSA,H, vec_inliers,nfa,verb);



    // if the matching is significant, register the good matches
    if ( nfa < nfa_max )
    {
        //  std::cout << "F=" << F <<std::endl;
        // extract meaningful matches
        matchings_unique.resize(vec_inliers.size());

        for (int cc = 0; cc < (int) vec_inliers.size(); cc++ )
        {
            matchings_unique[cc] = matchings[vec_inliers[cc]];
        }

        matchings.resize(vec_inliers.size());
        for (int cc = 0; cc < (int) vec_inliers.size(); cc++ )
        {
            matchings[cc] = matchings_unique[cc];
        }

        H /= H(2,2);

        IdentifiedMaps.clear();
        IdentifiedMaps.push_back(H);

        if (verb)
        {
            my_mexPrintf("The two images match! %d matchings are identified. log(nfa)=%.2f.\n", (int) matchings.size(), nfa);
            std::cout << "*************** Homography ***************"<< std::endl;
            std::cout << H <<std::endl;
            std::cout << "******************************************"<< std::endl;
        }
    }
    else
    {
        matchings.clear();
        if (verb)
            my_mexPrintf("The two images do not match. The matching is not significant:  log(nfa)=%.2f.\n", nfa);
    }
}


#include "local_descriptors_standalone.h"
#include "libLocalDesc/sift/demo_lib_sift.h"
#define BIG_NUMBER_L1 2800.0f
#define BIG_NUMBER_L2 1000000000000.0f
#define ABS(x)    (((x) > 0) ? (x) : (-(x)))


template <unsigned int OriSize,unsigned int IndexSize>
float distance_sift(keypoint_base<OriSize,IndexSize> *k1,keypoint_base<OriSize,IndexSize> *k2, float tdist, siftPar &par)
{

    float dif;
    float distsq = 0.0;

//    if (ABS(k1.x - k2.x) > par.MatchXradius || ABS(k1.y - k2.y) > par.MatchYradius) return tdist;


    float *ik1 = k1->vec;
    float *ik2 = k2->vec;

    for (int i = 0; (i < (int)k1->veclength)&&(distsq <= tdist); i++)
    {
        dif = ik1[i] - ik2[i];
        if (par.L2norm)
            distsq += dif * dif;
        else
            distsq += ABS(dif);
    }

    return distsq;
}



float distance_imasKP(IMAS::IMAS_KeyPoint *k1,IMAS::IMAS_KeyPoint *k2, float& dist,int &ind1, int &ind2, siftPar &par)
{
    float tdist;
    for(int i1=0;i1<k1->KPvec.size();i1++)
        for(int i2=0;i2<k2->KPvec.size();i2++)
        {

            tdist = distance_sift(static_cast<keypoint*>(k1->KPvec[i1].pt.kp_ptr) , static_cast<keypoint*>(k2->KPvec[i2].pt.kp_ptr), dist, par);

            if ( dist>tdist )
            {
                    dist = tdist;
                    ind1 = i1;
                    ind2 = i2;
            }

        }

return(dist);

}

float CheckForMatchIMAS(IMAS::IMAS_KeyPoint* key, std::vector<IMAS::IMAS_KeyPoint*> klist, int& min, int& ind1, int& ind2, siftPar &par)
{
    float	dsq, distsq1, distsq2;
    if (par.L2norm)
        distsq1 = distsq2 = BIG_NUMBER_L2;
    else
        distsq1 = distsq2 = BIG_NUMBER_L1;

    for (int j=0; j< (int) klist.size(); j++)
    {
        int i1,i2;
        dsq = distance_imasKP(key, klist[j], distsq2,i1,i2, par);

        if (dsq < distsq1) {
            distsq2 = distsq1;
            distsq1 = dsq;
            min = j;
            ind1 = i1;
            ind2 = i2;
        } else if (dsq < distsq2) {
            distsq2 = dsq;
        }
    }
    if (distsq2==0)
        return BIG_NUMBER_L2;
    else
        return distsq1/distsq2 ;
}


float mratio;
/**
 * @brief Computes matches from keypoints and descriptors comming from all possible combinations of simulated optical tilts.
 * @param w1 Width of image1
 * @param h1 Height of image1
 * @param w2 Width of image2
 * @param h2 Height of image2
 * @param keys1 Keypoints and descriptors found in all simulated optical tilts of image1
 * @param keys2 Keypoints and descriptors found in all simulated optical tilts of image2
 * @param matchings Returns a vector of filtered matches
 * @param Minfoall Returns more information on filtered matches
 * @param applyfilter Tells the method which filters should be applied. applyfilter = "the sum of desired filters to be applied". Example, applyfilter = APPLY_MULTI + APPLY_UNIQUE + APPLY_ORSA.
 * @return Total number of matches
 */
int compute_IMAS_matches(int w1, int h1, int w2, int h2, std::vector<IMAS::IMAS_KeyPoint*>& keys1, std::vector<IMAS::IMAS_KeyPoint*>& keys2, matchingslist &matchings, int applyfilter)
{
    IMAS_time tstart = IMAS::IMAS_getTickCount();
    my_mexPrintf("Keypoints matching...\n");

    //float	sqminratio = par.MatchRatio * par.MatchRatio,
        float	minratio = mratio ,
                    sqratio;
#pragma omp parallel for
        for (int i=0; i< (int) keys1.size(); i++)
        {
            int imatch=-1, ind1 = -1, ind2 = -1;

            if (AUX_KEYPOINTS)
            {
                //sqratio = CheckForMatch_withjustice(keys1[i], keys2, imatch,par);
            }
            else
            {
                //sqratio = CheckForMatch_short(keys1_short[i], keys2_short, imatch,par);
                 sqratio = CheckForMatchIMAS(keys1[i], keys2, imatch,ind1,ind2,siftparameters);
            }
                    if (sqratio< minratio)
                    {
                        //my_mexPrintf("par.MatchRatio = %f, sqratio = %f, sqratiomin = %f \n",par.MatchRatio,sqratio,sqminratio);
                        keypoint_simple k1, k2;

                        k1.x = keys1[i]->KPvec[ind1].pt.x;
                        k1.y = keys1[i]->KPvec[ind1].pt.y;
                        k1.scale = keys1[i]->KPvec[ind1].scale;
                        k1.angle = keys1[i]->KPvec[ind1].angle;
                        k1.theta = keys1[i]->KPvec[ind1].theta;
                        k1.t = keys1[i]->KPvec[ind1].t;
                        k1.size = keys1[i]->KPvec[ind1].size;

                        k2.x = keys2[imatch]->KPvec[ind2].pt.x;
                        k2.y = keys2[imatch]->KPvec[ind2].pt.y;
                        k2.scale = keys2[imatch]->KPvec[ind2].scale;
                        k2.angle = keys2[imatch]->KPvec[ind2].angle;
                        k2.theta = keys2[imatch]->KPvec[ind2].theta;
                        k2.t = keys2[imatch]->KPvec[ind2].t;
                        k2.size = keys2[imatch]->KPvec[ind2].size;

#pragma omp critical
                            matchings.push_back( matching(k1,k2) );
                    }
        }
    my_mexPrintf("   %d possible matches have been found. \n", (int) matchings.size());
    my_mexPrintf("Keypoints matching accomplished in %.2f seconds.\n \n", (IMAS::IMAS_getTickCount() - tstart)/ IMAS::IMAS_getTickFrequency());


    my_mexPrintf("Applying Filters... \n");
    tstart = IMAS::IMAS_getTickCount();


    if ( matchings.size() > 0 )
    {
        /* Remove the repetitive matches that appear in different simulations and retain only one. */
        // Since tilts are simuated on both image 1 and image 2, it is normal to have repetitive matches.

        matchingslist matchings_unique;

        if ( (applyfilter==APPLY_UNIQUE)||(applyfilter==APPLY_UNIQUE+APPLY_MULTI)||(applyfilter==APPLY_UNIQUE+APPLY_ORSA)||(applyfilter==APPLY_UNIQUE+APPLY_MULTI+APPLY_ORSA))
        {
            my_mexPrintf("-> Applying unique_match filter \n");
            unique_match1(matchings, matchings_unique);
            matchings = matchings_unique;

            my_mexPrintf("  The number of unique matches is %d \n", (int) matchings.size());
        }

        // There often appear to be some one-to-multiple/multiple-to-one matches (one point in image 1 matches with many points in image 2/vice versa).
        // This is an artifact of SIFT on interpolated images, as the interpolation tends to create some auto-similar structures (steps for example).
        // These matches need to be removed.
        /* Separating the removal of  multiple-to-one and one-to-multiple in two steps:
         - first remove multiple-to-one
         - then remove one-to-multiple
         This allows to avoid removing some good matches: multiple-to-one matches is much more frequent than one-to-multiple. Sometimes some of the feature points in image 1 that take part in "multiple-to-one" bad matches have also correct matches in image 2. The modified scheme avoid removing these good matches. */

        if ( (applyfilter==APPLY_MULTI)||(applyfilter==APPLY_UNIQUE+APPLY_MULTI)||(applyfilter==APPLY_MULTI+APPLY_ORSA)||(applyfilter==APPLY_UNIQUE+APPLY_MULTI+APPLY_ORSA))
        {
            my_mexPrintf("-> Applying multiple2one and one2multiple filters \n");

            // Remove to multiple-to-one matches
            matchings_unique.clear();
            //clean_match2(matchings, matchings_unique);
            matchings = matchings_unique;

            // Remove to one-to-multiple matches
            matchings_unique.clear();
            //clean_match1(matchings, matchings_unique);
            matchings = matchings_unique;
            my_mexPrintf("  The number of matches left is %d \n", (int) matchings.size());
        }



        // If enough matches to do epipolar filtering
        if ( ( (int) matchings.size() >= Tmin ) && ((applyfilter==APPLY_ORSA)||(applyfilter==APPLY_UNIQUE+APPLY_ORSA)||(applyfilter==APPLY_MULTI+APPLY_ORSA)||(applyfilter==APPLY_UNIQUE+APPLY_MULTI+APPLY_ORSA)) )
        {
            float nfa_max = -2;
            const int ITER_ORSA=10000;
            const bool verb=true;
            //std::srand(std::time(0));
            if (ORSA_Fundamental)
            {
                // Lionel Moisan, Pierre Moulon, and Pascal Monasse, Fundamental Matrix of a Stereo Pair, with A Contrario Elimination of Outliers, Image Processing On Line, 6 (2016), pp. 89–113.
                my_mexPrintf("-> Applying ORSA filter (Fundamental Matrix) \n");

                // Fundamental matrix Estimation with ORSA
                EpipolarFilter( matchings, w1, h1, w2, h2, nfa_max, ITER_ORSA, ORSA_precision, verb);
            }
            else
            {
                // Lionel Moisan, Pierre Moulon, and Pascal Monasse, Automatic Homographic Registration of a Pair of Images, with A Contrario Elimination of Outliers, Image Processing On Line, 2 (2012), pp. 56–73.
                my_mexPrintf("-> Applying ORSA filter (Homography) \n");

                // Homography Estimation with ORSA
                HomographyFilter( matchings, w1, h1, w2, h2, nfa_max, ITER_ORSA, ORSA_precision, verb);
            }
        }
        else
        {
            if ((applyfilter==APPLY_ORSA)||(applyfilter==APPLY_UNIQUE+APPLY_ORSA)||(applyfilter==APPLY_MULTI+APPLY_ORSA)||(applyfilter==APPLY_UNIQUE+APPLY_MULTI+APPLY_ORSA))
            {
                matchings.clear();
                my_mexPrintf("The two images do not match. Not enough matches to do epipolar filtering.\n");
            }
        }
    }
    else
    {
        my_mexPrintf("The two images do not match\n");
    }

    my_mexPrintf("   Number of matches =  %d. \n", (int) matchings.size());
    my_mexPrintf("Filters were applied in %.2f seconds.\n \n", (IMAS::IMAS_getTickCount() - tstart)/ IMAS::IMAS_getTickFrequency());


    return matchings.size();

}
