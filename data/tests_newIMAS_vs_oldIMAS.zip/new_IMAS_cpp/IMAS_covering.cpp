/**
  * @file IMAS_covering.cpp
  * @author Mariano Rodríguez
  * @date 2017
  * @brief handles IMAS coverings: either coverings proposed in the literature or optimal coverings as in Mariano Rodríguez, Julie Delon and Jean-Michel Morel.
  */
#include "IMAS_covering.h"
#include<fstream>   //string, ifstream
#include <algorithm>    // std::random_shuffle, atoi
#include "math.h" // M_PI

using namespace std;

const char delimiter = ',';


float *simtilts;
float *simrot;

int totsimu1;
int totsimu2;

std::vector<tilt_simu> simu_details1;
std::vector<tilt_simu> simu_details2;



void insertsimu(float t1,float r1, std::vector<tilt_simu>& simu_details)
{
    tilt_simu temp;
    bool inserted=false;
    for (int i=0;i<(int)simu_details.size();i++)
    {
        if (simu_details[i].t==t1)
        {
            simu_details[i].rots.push_back(r1);
            inserted = true;
        }
    }
    if (inserted == false)
    {
        temp.t=t1;
        temp.rots.push_back(r1);
        simu_details.push_back(temp);
    }

}

std::vector<float> string2vec(string s)
{
    std::vector<float> vec;
    string acc = "";
    for(int i = 0; i < (int)(s.size()); i++)
    {
        if((s)[i] == delimiter)
        {
            vec.push_back( std::atof(acc.c_str()) );
            acc = "";
        }
        else
            acc += s[i];
    }
    if (acc!="")
        vec.push_back( std::atof(acc.c_str()) );
    return vec;
}


void loadsimulations2do()
{
    std::ifstream filein;
    filein.open("2simu.csv");
    if (filein.good())
    {
        std::vector<string> stringvec;
        std::vector<std::string>::iterator it;
        while( !(filein.eof()) )
        {
            string s;
            std::getline(filein, s);
            stringvec.push_back(s);
        }
        filein.close();

        if (stringvec.size()<4)
        {
            my_mexPrintf("Error: Wrong file structure -> 2simu.csv \n");
            my_mexPrintf("       Needs 4 rows where values are separated by comma \n");
            exit(-1);
        }

        std::vector<float> vec_simtilts;
        std::vector<float> vec_simrot;

        vec_simtilts = string2vec( stringvec[0] );
        vec_simrot = string2vec( stringvec[1] );
        if (vec_simrot.size()==vec_simtilts.size())
        {
            for (int i=0;i<(int)vec_simrot.size();i++)
                insertsimu(vec_simtilts[i],vec_simrot[i],simu_details1);
        }
        else
        {
            my_mexPrintf("Error: Wrong file structure for simulations in image 1 -> 2simu.csv \n");
            my_mexPrintf("       Explicitely state t_1,...,t_n and r_1,...,r_n \n");
            exit(-1);
        }

        totsimu1 = vec_simrot.size();

        vec_simtilts = string2vec( stringvec[2] );
        vec_simrot = string2vec( stringvec[3] );
        if (vec_simrot.size()==vec_simtilts.size())
        {
            for (int i=0;i<(int)vec_simrot.size();i++)
                insertsimu(vec_simtilts[i],vec_simrot[i],simu_details2);
        }
        else
        {
            my_mexPrintf("Error: Wrong file structure for simulations in image 2 -> 2simu.csv \n");
            my_mexPrintf("       Explicitely state t_1,...,t_n and r_1,...,r_n \n");
            exit(-1);
        }

        totsimu2 = vec_simrot.size();

    }
    else
    {
        my_mexPrintf("WARNING: No file 2simu.csv has been found. Selecting default covering !  \n");
        loadsimulations2do(1.7f);
    }
}

void loadsimulations2do(std::vector<float>& vec_simtilts1, std::vector<float>& vec_simrot1,std::vector<float>& vec_simtilts2, std::vector<float>& vec_simrot2)
{
    if ( (vec_simrot1.size()==vec_simtilts1.size())&&(vec_simrot2.size()==vec_simtilts2.size()) )
    {
        for (int i=0;i<(int)vec_simrot1.size();i++)
            insertsimu(vec_simtilts1[i],vec_simrot1[i],simu_details1);
        for (int i=0;i<(int)vec_simrot2.size();i++)
            insertsimu(vec_simtilts2[i],vec_simrot2[i],simu_details2);
    }
    else
    {
        my_mexPrintf("Error: Wrong structure information for simulations \n");
        my_mexPrintf("       Explicitely state t_1,...,t_n and r_1,...,r_n for each image \n");
        exit(-1);
    }

}


void load_optimal_simulations2do(float t1, float phi1, float t2, float phi2)
{
    insertsimu(1,0,simu_details1);
    insertsimu(1,0,simu_details2);
    totsimu1 = 1;
    totsimu2 = 1;

    if ( (t1>1)&&(phi1>0) )
    {
        float phi = 0;
        while(phi<M_PI)
        {
            totsimu1++;
            totsimu2++;
            insertsimu(t1,phi,simu_details1);
            insertsimu(t1,phi,simu_details2);
            phi = phi1 + phi;

        }
    }

    if ( (t2>1)&&(phi2>0) )
    {
        float phi = 0;
        while(phi<M_PI)
        {
            totsimu1++;
            totsimu2++;
            insertsimu(t2,phi,simu_details1);
            insertsimu(t2,phi,simu_details2);
            phi = phi2 + phi;
        }
    }

}

void loadsimulations2do(float radius)
{
    int r = floor(radius*100);
    switch (r)
    {
    case 140: // Not really optimal, but almost
    {
        my_mexPrintf("Selecting a log%.1f-covering for tilts up to %.0f  \n",1.4f,5.0f);
        my_mexPrintf("Area ratio = %.2f  \n \n",14.82);
        totsimu1 = 43;
        totsimu2 = 43;

        simtilts = new float[43]{1,1.702223206,1.702223206,1.702223206,1.702223206,1.702223206,1.702223206,2.656935438,2.656935438,2.656935438,2.656935438,2.656935438,2.656935438,2.656935438,2.656935438,2.656935438,2.656935438,2.656935438,2.656935438,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378,4.15178378};
        simrot = new float[43]{0,0,0.5237914306,1.047582861,1.571374292,2.095165723,2.618957153,0,0.2618957153,0.5237914306,0.7856871459,1.047582861,1.309478577,1.571374292,1.833270007,2.095165723,2.357061438,2.618957153,2.880852868,0,0.1309478577,0.2618957153,0.392843573,0.5237914306,0.6547392883,0.7856871459,0.9166350036,1.047582861,1.178530719,1.309478577,1.440426434,1.571374292,1.70232215,1.833270007,1.964217865,2.095165723,2.22611358,2.357061438,2.488009295,2.618957153,2.749905011,2.880852868,3.011800726};

        for (int i=0;i<totsimu1;i++)
        {
            insertsimu(simtilts[i],simrot[i],simu_details1);
            insertsimu(simtilts[i],simrot[i],simu_details2);
        }
        break;

    }
    case 100:
    {
        my_mexPrintf("Selecting just one tilt: [Id]  \n",2.0f,6.0f);
        my_mexPrintf("Area ratio = %.2f  \n \n",1.0f);
        load_optimal_simulations2do(0.0f, 0.0f, 0.0f, 0.0f);
        break;
    }
    case 200:
    {
        my_mexPrintf("Selecting optimal log%.0f-covering for tilts up to %.0f  \n",2.0f,6.0f);
        my_mexPrintf("Area ratio = %.2f  \n \n",5.35264f);
        load_optimal_simulations2do(2.85821f, 0.525828f, 5.76899f, 0.243276f);
        break;
    }
    case 190:
    {
        my_mexPrintf("Selecting optimal log%.1f-covering for tilts up to %.0f  \n",1.9f,6.0f);
        my_mexPrintf("Area ratio = %.2f  \n \n",5.63792);
        load_optimal_simulations2do(3.06787f, 0.452026f, 5.94174f, 0.224402f);
        break;
    }
    case 180:
    {
        my_mexPrintf("Selecting optimal log%.1f-covering for tilts up to %.0f  \n",1.8f,6.0f);
        my_mexPrintf("Area ratio = %.2f  \n \n",6.37189);
        load_optimal_simulations2do(2.88447f, 0.398463f, 6.15761f, 0.197257f);
        break;
    }
    case 170:
    {
        my_mexPrintf("Selecting optimal log%.1f-covering for tilts up to %.0f  \n",1.7f,6.0f);
        my_mexPrintf("Area ratio = %.2f  \n \n",7.34464);
        load_optimal_simulations2do(2.64329f, 0.373327f, 5.78273f, 0.185948f);
        break;
    }
    case 155:
    {
        my_mexPrintf("Selecting optimal log%.2f-covering for tilts up to %.2f  \n",1.55f,5.65f);
        my_mexPrintf("Area ratio = %.2f  \n \n",9.69025);
        load_optimal_simulations2do( 2.28479f, 0.318792f, 4.63662f,0.16015f);
        break;
    }
    case 160:
    {
        my_mexPrintf("Selecting optimal log%.1f-covering for tilts up to %.0f  \n",1.6f,6.0f);
        my_mexPrintf("Area ratio = %.2f  \n \n",8.90716);
        load_optimal_simulations2do( 2.40499f, 0.332277f, 5.06783f, 0.165827f);
        break;
    }
    case -180: // Not at all optimal
    {
        my_mexPrintf("Selecting the ASIFT first log%.1f-covering for tilts up to %.0f  \n",1.8f,5.65f);
        my_mexPrintf("Area ratio = %.2f  \n \n",13.77);
        totsimu1 = 41;
        totsimu2 = 41;
        simtilts = new float[41]{1,1.414213562,1.414213562,1.414213562,1.414213562,2,2,2,2,2,2.828427125,2.828427125,2.828427125,2.828427125,2.828427125,2.828427125,2.828427125,4,4,4,4,4,4,4,4,4,4,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249,5.656854249};
        simrot= new float[41]{0,0,0.7853981634,1.570796327,2.35619449,0,0.6283185307,1.256637061,1.884955592,2.513274123,0,0.4487989505,0.897597901,1.346396852,1.795195802,2.243994753,2.692793703,0,0.3141592654,0.6283185307,0.9424777961,1.256637061,1.570796327,1.884955592,2.199114858,2.513274123,2.827433388,0,0.2243994753,0.4487989505,0.6731984258,0.897597901,1.121997376,1.346396852,1.570796327,1.795195802,2.019595277,2.243994753,2.468394228,2.692793703,2.917193178};

        for (int i=0;i<totsimu1;i++)
        {
            insertsimu(simtilts[i],simrot[i],simu_details1);
            insertsimu(simtilts[i],simrot[i],simu_details2);
        }
        break;
    }
    default:
    {
        my_mexPrintf("WARNING: The optimal log%.2f-covering hasn't been computed yet !  \n",radius);
        loadsimulations2do(1.7f);
        break;
    }

    }
}
