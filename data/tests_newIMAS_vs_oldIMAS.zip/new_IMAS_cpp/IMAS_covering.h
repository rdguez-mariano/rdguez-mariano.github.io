/**
  * @file IMAS_covering.h
  * @author Mariano Rodríguez
  * @date 2017
  * @brief handles IMAS coverings: either coverings proposed in the literature or optimal coverings as in Mariano Rodríguez, Julie Delon and Jean-Michel Morel.
  */
#ifndef IMAS_COVERING_H
#define IMAS_COVERING_H

#include <vector>
#include "mex_and_omp.h"


/**
 * @brief It stores all rotations to be simulated for an certain tilt
 */
struct tilt_simu {
    float	t;
    std::vector<float> rots;
};

/**
 * @brief Global variable that stores tilts and rotations to be performed on image1
 * @code
// Loop on tilts
for (tt = 1; tt <= simu_details.size(); tt++)
{
    // Loop on rotations.
    for ( int rr = 1; rr <= simu_details[tt-1].rots.size(); rr++ )
        {
            ... Do something here with it
        }
}
*@endcode
 */
extern std::vector<tilt_simu> simu_details1;

/**
 * @brief Global variable that stores tilts and rotations to be performed on image2
 * @code
// Loop on tilts
for (tt = 1; tt <= simu_details.size(); tt++)
{
    // Loop on rotations.
    for ( int rr = 1; rr <= simu_details[tt-1].rots.size(); rr++ )
        {
            ... Do something here with it
        }
}
*@endcode
 */
extern std::vector<tilt_simu> simu_details2;

/**
 * @brief Global variable that stores the total amount of simulations to be performed on image1
 */
extern int totsimu1;

/**
 * @brief Global variable that stores the total amount of simulations to be performed on image2
 */
extern int totsimu2;



/**
 * @brief Sets up tilt simulations to perform from file "2simu.csv"
 */
void loadsimulations2do();

/**
 * @brief Sets up tilt simulations to perform from vectors. Both vectors for image1/image2 must be equal in length.
 * @param vec_simtilts1 Tilts for image1
 * @param vec_simrot1 Rotations for image1
 * @param vec_simtilts2 Tilts for image2
 * @param vec_simrot2 Rotations for image2
 */
void loadsimulations2do(std::vector<float>& vec_simtilts1, std::vector<float>& vec_simrot1,std::vector<float>& vec_simtilts2, std::vector<float>& vec_simrot2);

/**
 * @brief Sets up default tilt simulations for an specific radius.
 * @param radius If positive the function will give back the default optimal covering assigned to that radius. If negative the function will give back the default covering proposed in the literature.
 */
void loadsimulations2do(float radius);

#endif // IMAS_COVERING_H
