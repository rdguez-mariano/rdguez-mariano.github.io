/**
  * @file main_standalone.cpp
  * @authors Mariano Rodríguez
  * @date 2017
  * @brief Computing keypoints from optical tilts.
  * @warning This file is linked to the patent Jean-Michel Morel and Guoshen Yu, Method and device for the invariant affine recognition recognition of shapes (WO/2009/150361), patent pending.
  */

#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include "mex_and_omp.h"
#include "perform_IMAS.h"
#include "io_png/io_png.h"
#include "libNumerics/numerics.h"

# define IM_X 800
# define IM_Y 600


#include "frot.h"
#include "fproj.h"
static float InitSigma_aa = 1.6;
#define round(x) ((x)>=0?(long)((x)+0.5):(long)((x)-0.5))
const float GaussTruncate1 = 4.0;
void perform_tilt_and_rotation( vector<float>& image, int width, int height, vector<float>& image_to_return, int& width_t, int& height_t, float theta, float t)
{

    int flag_dir = 1;
    int fproj_o;
    float fproj_p, fproj_bg;
    char fproj_i;
    float *fproj_x4, *fproj_y4;
    //  float frot_b=0;
    float frot_b=128;
    char *frot_k;

    frot_k = 0; // order of interpolation


    fproj_o = 3;
    fproj_p = 0;
    fproj_i = 0;
    fproj_bg = 0;
    fproj_x4 = 0;
    fproj_y4 = 0;




    //theta = theta * 180 / PI;
    float t1 = 1;
    float t2 = 1/t;

    vector<float> image_t;
    int width_r, height_r;

    // simulate a rotation: rotate the image with an angle theta. (the outside of the rotated image are padded with the value frot_b)
    frot(image, image_t, width, height, &width_r, &height_r, &theta, &frot_b , frot_k);

    /* Tilt */
    width_t = (int) (width_r * t1);
    height_t = (int) (height_r * t2);

    int fproj_sx = width_t;
    int fproj_sy = height_t;

    float fproj_x1 = 0;
    float fproj_y1 = 0;
    float fproj_x2 = width_t;
    float fproj_y2 = 0;
    float fproj_x3 = 0;
    float fproj_y3 = height_t;

    if (t==1.0f)
    {
        image_to_return = image_t;
    }
    else
    {
        /* Anti-aliasing filtering along vertical direction */
        float sigma_aa = (InitSigma_aa/2) * sqrt(std::pow(t,2) -1);
        GaussianBlur1D(image_t,width_r,height_r,sigma_aa,flag_dir);


        // simulate a tilt: subsample the image along the vertical axis by a factor of t.
        vector<float> image_tmp(width_t*height_t);
        fproj (image_t, image_tmp, width_r, height_r, &fproj_sx, &fproj_sy, &fproj_bg, &fproj_o, &fproj_p, &fproj_i , fproj_x1 , fproj_y1 , fproj_x2 , fproj_y2 , fproj_x3 , fproj_y3, fproj_x4, fproj_y4);
        image_to_return = image_tmp;
    }


}

void invert_contrast(std::vector<float>& image,int w, int h)
{    for (int i=0;i<h;i++)
        for (int j=0;j<w;j++)
        {
            image[j*h+i] = (float)(255 - image[j*h+i]);
        }
}



// Grow rectangle of corners (x0,y0) and (x1,y1) to include (x,y)
void growTo(float& x0, float& y0, float& x1, float& y1, float x, float y)
{
    if(x<x0) x0=x;
    if(x>x1) x1=x;
    if(y<y0) y0=y;
    if(y>y1) y1=y;
}


// Panorama construction
void panorama(std::vector<float>& I1,int w1, int h1,std::vector<float>& I2, int w2, int h2, libNumerics::matrix<float> H)
{
    std::vector<float> I;
    int h, w;
    libNumerics::matrix<float> v(3,1);
    float x0=0, y0=0, x1=(float)w2, y1=(float)h2;

    v(0,0)=0; v(1,0)=0; v(2,0)=1;
    v=H*v; v/=v(2,0);
    growTo(x0, y0, x1, y1, v(0,0), v(1,0));

    v(0,0)=(float)w1; v(1,0)=0; v(2,0)=1;
    v=H*v; v/=v(2,0);
    growTo(x0, y0, x1, y1, v(0,0), v(1,0));

    v(0,0)=(float)w1; v(1,0)=(float)h1; v(2,0)=1;
    v=H*v; v/=v(2,0);
    growTo(x0, y0, x1, y1, v(0,0), v(1,0));

    v(0,0)=0; v(1,0)=(float)h1; v(2,0)=1;
    v=H*v; v/=v(2,0);
    growTo(x0, y0, x1, y1, v(0,0), v(1,0));

    w = int(x1-x0);
    h = int(y1-y0);
    I.resize(h*w);

    for (int i =0; i<w*h;i++)
      I[i] = 255;

    H = H.inv(); // Pull from image I1
    for(int i=0; i<h; i++)
        for(int j=0; j<w; j++) {
            v(0,0) = j+x0; v(1,0) = i+y0; v(2,0) = 1;
            bool in=(0<=v(0,0) && v(0,0)<w2 && 0<=v(1,0) && v(1,0)<h2);
            if(in)
                I[i*w + j] = I2[ (int)round(v(0,0)) + (int)round(v(1,0))*w2 ];
            v = H*v;
            v /= v(2,0);
            if(0<=v(0,0) && v(0,0)<w1 && 0<=v(1,0) && v(1,0)<h1) {
                if(in) {
                    float vtemp = I1[ (int)round(v(0,0)) + (int)round(v(1,0))*w1 ];
                    I[i*w + j] = ( I[i*w + j] + vtemp )/2;
                } else
                {
                    I[i*w + j] = I1[ (int)round(v(0,0)) + (int)round(v(1,0))*w1 ];
                }
            }
        }

    float * rgb = new float[w*h];
        for(int i = 0; i < (int) h*w; i++)
                rgb[i] = I[i];

    write_png_f32("panorama.png", rgb, w, h, 1);
}


void write_images_matches(std::vector<float>& ipixels1,int w1, int h1,std::vector<float>& ipixels2, int w2, int h2,matchingslist& matchings, float zoom1, float zoom2)
{

    int sq = 2;
    ///////////////// Output image containing line matches (the two images are concatenated one above the other)
    int band_w = 20; // insert a black band of width band_w between the two images for better visibility

    int wo =  MAX(w1,w2);
    int ho = h1+h2+band_w;

    std::vector<float *> opixelsIMAS, opixelsIMAS_rich;
    for(int c=0;c<3;c++)
    {
        opixelsIMAS.push_back(new float[wo*ho]);
        opixelsIMAS_rich.push_back(new float[wo*ho]);
    }

    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) ho; j++)
            for(int i = 0; i < (int) wo; i++)
            {
                opixelsIMAS[c][j*wo+i] = 255;
                opixelsIMAS_rich[c][j*wo+i] = 255;
            }

    /////////////////////////////////////////////////////////////////// Copy both images to output
    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) h1; j++)
            for(int i = 0; i < (int) w1; i++)
            {
                opixelsIMAS[c][j*wo+i] = ipixels1[j*w1+i];
                opixelsIMAS_rich[c][j*wo+i] = ipixels1[j*w1+i];
            }

    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) h2; j++)
            for(int i = 0; i < (int) (int)w2; i++)
            {
                opixelsIMAS[c][(h1 + band_w + j)*wo + i] = ipixels2[j*w2 + i];
                opixelsIMAS_rich[c][(h1 + band_w + j)*wo + i] = ipixels2[j*w2 + i];
            }

    //////////////////////////////////////////////////////////////////// Draw matches
    float* colorlines = new float[3], *colordesc = new float[3];
    colorlines[0] = 250.0f;colorlines[1] = 1.0f; colorlines[2] = 1.0f;
    colordesc[0] = 1.0f;colordesc[1] = 250.0f; colordesc[2] = 1.0f;
    float value;
    for(int i=0; i < (int) matchings.size(); i++)
        for(int c=0;c<3;c++)
        {
                /* DRAWING SQUARES */
                value =  (float)(rand() % 150 + 50);
                draw_line(opixelsIMAS[c],  round(zoom1*matchings[i].first.x), round(zoom1*matchings[i].first.y),
                          round(zoom2*matchings[i].second.x), round(zoom2*matchings[i].second.y) + h1 + band_w, value, wo, ho);

                draw_square(opixelsIMAS[c],  round(zoom1*matchings[i].first.x)-sq, round(zoom1*matchings[i].first.y)-sq, 2*sq, 2*sq, value, wo, ho);
                draw_square(opixelsIMAS[c],  round(zoom2*matchings[i].second.x)-sq, round(zoom2*matchings[i].second.y) + h1 + band_w-sq, 2*sq, 2*sq, value, wo, ho);

                /* DRAWING RICH KEYPOINTS */
                //draw_line(opixelsIMAS_rich[c],  round(zoom1*matchings[i].first.x), round(zoom1*matchings[i].first.y), round(zoom2*matchings[i].second.x), round(zoom2*matchings[i].second.y) + h1 + band_w, colorlines[c], wo, ho);
                draw_circle_affine(opixelsIMAS_rich[c],wo,ho, zoom1*matchings[i].first.x, zoom1*matchings[i].first.y, matchings[i].first.angle, matchings[i].first.scale, matchings[i].first.t, 1.0f, matchings[i].first.theta*M_PI/180, colordesc[c]);
                draw_circle_affine(opixelsIMAS_rich[c],wo,ho, zoom2*matchings[i].second.x, zoom2*matchings[i].second.y + h1 + band_w, matchings[i].second.angle, matchings[i].second.scale, matchings[i].second.t, 1.0f, matchings[i].second.theta*M_PI/180, colordesc[c]);
        }

    float * rgb = new float[wo*ho*3];
    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) ho; j++)
            for(int i = 0; i < (int) wo; i++)
                rgb[j*wo+i+c*(wo*ho)] = opixelsIMAS[c][j*wo+i];
    write_png_f32("output_vert.png", rgb, wo, ho, 3);
    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) ho; j++)
            for(int i = 0; i < (int) wo; i++)
                rgb[j*wo+i+c*(wo*ho)] = opixelsIMAS_rich[c][j*wo+i];
    write_png_f32("output_vert_rich.png", rgb, wo, ho, 3);

    for(int c=0;c<3;c++)
    {
        delete[] opixelsIMAS[c]; /*memcheck*/
        delete[] opixelsIMAS_rich[c]; /*memcheck*/
    }



    /////////// Output image containing line matches (the two images are concatenated one aside the other)
    int woH =  w1+w2+band_w;
    int hoH = MAX(h1,h2);

    std::vector<float *> opixelsIMAS_H, opixelsIMAS_H_rich;
    for(int c=0;c<3;c++)
    {
        opixelsIMAS_H.push_back(new float[woH*hoH]);
        opixelsIMAS_H_rich.push_back(new float[woH*hoH]);
    }

    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) hoH; j++)
            for(int i = 0; i < (int) woH; i++)
            {
                opixelsIMAS_H[c][j*woH+i] = 255;
                opixelsIMAS_H_rich[c][j*woH+i] = 255;
            }

    /////////////////////////////////////////////////////////////////// Copy both images to output
    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) h1; j++)
            for(int i = 0; i < (int) w1; i++)
            {
                opixelsIMAS_H[c][j*woH+i] = ipixels1[j*w1+i];
                opixelsIMAS_H_rich[c][j*woH+i] = ipixels1[j*w1+i];
            }

    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) h2; j++)
            for(int i = 0; i < (int) w2; i++)
            {
                opixelsIMAS_H[c][j*woH + w1 + band_w + i] = ipixels2[j*w2 + i];
                opixelsIMAS_H_rich[c][j*woH + w1 + band_w + i] = ipixels2[j*w2 + i];
            }

    //////////////////////////////////////////////////////////////////// Draw matches

    for(int i=0; i < (int) matchings.size(); i++)
        for(int c=0;c<3;c++)
        {
            /* DRAWING SQUARES */
            value =  (float)(rand() % 150 + 50);

            draw_line(opixelsIMAS_H[c],  round(zoom1*matchings[i].first.x), round(zoom1*matchings[i].first.y),
                      round(zoom2*matchings[i].second.x) + w1 + band_w, round(zoom2*matchings[i].second.y), value, woH, hoH);

            draw_square(opixelsIMAS_H[c],  round(zoom1*matchings[i].first.x)-sq, round(zoom1*matchings[i].first.y)-sq, 2*sq, 2*sq, value, woH, hoH);
            draw_square(opixelsIMAS_H[c],  round(zoom2*matchings[i].second.x) + w1 + band_w-sq, round(zoom2*matchings[i].second.y)-sq, 2*sq, 2*sq, value, woH, hoH);

            /* DRAWING RICH KEYPOINTS */
            //draw_line(opixelsIMAS_H_rich[c],  round(zoom1*matchings[i].first.x), round(zoom1*matchings[i].first.y),round(zoom2*matchings[i].second.x) + w1 + band_w, round(zoom2*matchings[i].second.y), colorlines[c], woH, hoH);
            draw_circle_affine(opixelsIMAS_H_rich[c],woH,hoH, zoom1*matchings[i].first.x, zoom1*matchings[i].first.y, matchings[i].first.angle, matchings[i].first.scale, matchings[i].first.t, 1.0f, matchings[i].first.theta*M_PI/180, colordesc[c]);
            draw_circle_affine(opixelsIMAS_H_rich[c],woH,hoH, zoom2*matchings[i].second.x + w1 + band_w, zoom2*matchings[i].second.y, matchings[i].second.angle, matchings[i].second.scale,matchings[i].second.t, 1.0f, matchings[i].second.theta*M_PI/180, colordesc[c]);
        }

    delete[] rgb;
    rgb = new float[woH*hoH*3];
    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) hoH; j++)
            for(int i = 0; i < (int) woH; i++)
                rgb[j*woH+i+c*(woH*hoH)] = opixelsIMAS_H[c][j*woH+i];

    write_png_f32("output_hori.png", rgb, woH, hoH, 3);

    for(int c=0;c<3;c++)
        for(int j = 0; j < (int) hoH; j++)
            for(int i = 0; i < (int) woH; i++)
                rgb[j*woH+i+c*(woH*hoH)] = opixelsIMAS_H_rich[c][j*woH+i];

    write_png_f32("output_hori_rich.png", rgb, woH, hoH, 3);


    delete[] rgb;
    for(int c=0;c<3;c++)
    {
        delete[] opixelsIMAS_H[c]; /*memcheck*/
        delete[] opixelsIMAS_H_rich[c]; /*memcheck*/
    }
}

#include <map>
#include <string>
#include <iostream>
enum StringValue { _wrongvalue,_im1, _im2,_im3,_max_keys_im3,_im3_only, _orsa_type, _applyfilter, _IMAS_INDEX, _radius,_match_ratio, _orsa_precision, _eigen_threshold, _tensor_eigen_threshold };
static std::map<std::string, int> strmap;
void buildmap()
{
    strmap["wrongvalue"] = _wrongvalue;
    strmap["-im1"] = _im1;
    strmap["-im2"] = _im2;
    strmap["-im3"] = _im3;
    strmap["-max_keys_im3"] = _max_keys_im3;
    strmap["-im3_only"] = _im3_only;
    strmap["-orsa_type"] = _orsa_type;
    strmap["-applyfilter"] = _applyfilter;
    strmap["-desc"] = _IMAS_INDEX;
    strmap["-radius"] = _radius;
    strmap["-match_ratio"] = _match_ratio;
    strmap["-orsa_precision"] = _orsa_precision;
    strmap["-eigen_threshold"] = _eigen_threshold;
    strmap["-tensor_eigen_threshold"] = _tensor_eigen_threshold;


}


void get_arguments(int argc, char **argv, std::vector<float>& im1,size_t& w1,size_t& h1, std::vector<float>& im2,size_t& w2, size_t& h2,std::vector<float>& im3,size_t& w3, size_t& h3, int& applyfilter, int& IMAS_INDEX, float& radius,float& matchratio, float& edge_thres, float& tensor_thres)
{
    int count = 1;
    buildmap();
    while (count<argc)
    {
        string s(argv[count++]);
        //cout<<s<<" = "<<argv[count]<< endl;
        switch (strmap[s])
        {
        case _wrongvalue:
        {
            cout<<"unidentified: "<<s<<" = "<<argv[count]<<endl;
            break;
        }
        case _im3:
        {
            float * iarr1;
            if (NULL == (iarr1 = read_png_f32_gray(argv[count], &w3, &h3)))
            {
                std::cout << "**** a-contrario image not found **** " << std::endl;
            }
            else
            {
                im3 = *new vector<float>(iarr1, iarr1 + w3 * h3);
                free(iarr1); /*memcheck*/
                AUX_KEYPOINTS = true;
            }
            break;
        }
        case _im1:
        {
            float * iarr1;
            if (NULL == (iarr1 = read_png_f32_gray(argv[count], &w1, &h1))) {
                std::cerr << "Unable to load image file " << argv[count] << std::endl;
            }
            im1 = *new vector<float>(iarr1, iarr1 + w1 * h1);
            free(iarr1); /*memcheck*/
            break;
        }
        case _im2:
        {
            // Read image2
            float * iarr2;
            if (NULL == (iarr2 = read_png_f32_gray(argv[count], &w2, &h2))) {
                std::cerr << "Unable to load image file " << argv[count] << std::endl;
            }
            std::vector<float> ipixels2(iarr2, iarr2 + w2 * h2);
            free(iarr2); /*memcheck*/
            im2 = ipixels2;
            break;
        }
        case _orsa_type:
        {
            if (atoi(argv[count])==1)
            {
                Tmin = 8;
                ORSA_Fundamental = true;
                ORSA_precision=3;
            }
            else
            {
                Tmin = 5;
                ORSA_Fundamental = false;
                ORSA_precision=24;
            }
            break;

        }
        case _orsa_precision:
        {
            ORSA_precision = atof(argv[count]);
            break;
        }
        case _applyfilter:
        {
            applyfilter = atoi(argv[count]);
            break;
        }
        case _IMAS_INDEX:
        {
            IMAS_INDEX = atoi(argv[count]);
            break;
        }
        case _radius:
        {
             radius = atof(argv[count]);
             break;
        }
        case _match_ratio:
        {
             matchratio = atof(argv[count]);
             break;
        }
        case _eigen_threshold:
        {
             edge_thres = atof(argv[count]) / pow( 1 + atof(argv[count]) ,2);
             break;
        }
        case _tensor_eigen_threshold:
        {
             tensor_thres = atof(argv[count]) / pow( 1 + atof(argv[count]) ,2);
             break;
        }
        }
        count++;
    }
}

int main(int argc, char **argv)
{

    int IMAS_INDEX = 11, applyfilter = 7;
    float radius = -1.0f, matchratio = -1.0f, edge_thres = -1.0f, tensor_thres = -1.0f;
    std::vector<float> ipixels1,ipixels2,ipixels3;
    size_t w1,h1,w2,h2,w3,h3;
    get_arguments(argc,argv,ipixels1,w1,h1,ipixels2,w2,h2,ipixels3,w3,h3,applyfilter,IMAS_INDEX,radius,matchratio,edge_thres, tensor_thres);

    string algo_name = SetDetectorDescriptor(IMAS_INDEX);
    if (radius!=1.0f)
        algo_name ="Optimal-Affine-"+algo_name;


    if (radius!=-1.0f)
        default_radius = radius;
    loadsimulations2do(default_radius);

    if ((AUX_KEYPOINTS)&&(IMAS_INDEX!=IMAS_SURF))
        prepare_acontrario_matching(ipixels3,(int) w3,(int) h3);

    if (matchratio>0.0f)
        update_matchratio(matchratio);

    if (edge_thres>0.0f)
        update_edge_threshold(edge_thres);

    if (tensor_thres>0.0f)
        update_tensor_threshold(tensor_thres);


    // Number of threads to use
    int nthreads, maxthreads;
    /* Display info on OpenMP*/
#pragma omp parallel
    {
#pragma omp master
        {
            nthreads = my_omp_get_num_threads();
            maxthreads = my_omp_get_max_threads();
        }
    }
    my_mexPrintf("--> Using %d threads out of %d for executing %s <--\n\n",nthreads,maxthreads,algo_name.c_str());




    // Performing IMAS
    matchingslist matchings;
    vector< float > data;


    //        invert_contrast(ipixels2, w2, h2);
            //int wt1,ht1;
           // perform_tilt_and_rotation(ipixels1,w1,h1,ipixels1,wt1,ht1,45.0f,3.0f); w1 = wt1;h1=ht1;
    perform_IMAS(ipixels1, (int)w1, (int)h1, ipixels2, (int)w2, (int)h2, data, matchings, 0, applyfilter);
    // perform_IMAS(ipixels2, (int)w2, (int)h2, ipixels1, (int)w1, (int)h1, data, matchings, Minfoall, flag_resize, applyfilter);

    write_images_matches(ipixels1,(int) w1, (int) h1, ipixels2, (int) w2, (int) h2, matchings, 1.0f, 1.0f);


    //write panorama if orsa homography is selected
    if ((!ORSA_Fundamental)&&(IdentifiedMaps.size()!=0))
    {
        libNumerics::matrix<double> H1 = IdentifiedMaps[0];
        libNumerics::matrix<float> H(3,3);
        for(int i=0; i<3; i++)
            for(int j=0; j<3; j++)
                H(i,j) = (float) H1(i,j);

        panorama(ipixels1,(int) w1, (int) h1, ipixels2, (int) w2, (int) h2, H);
    }

    //Output file "data_matches.csv"

    int wo = 14;
    ofstream myfile;
    myfile.open ("data_matches.csv", std::ofstream::out | std::ofstream::trunc);
    myfile<<"x1, y1, sigma1, angle1, t1_x, t1_y, theta1, x2, y2, sigma2, angle2, t2_x, t2_y, theta2"<<endl;

    if (matchings.size()>0)
    {
        int cont =1;
        myfile << ((double) data[0]) << ",";

        for ( int i = 1; i < (int) (wo*matchings.size()); i++ )
        {
            if (cont ==(wo-1))
            {
                myfile << ((double) data[i]) << endl;
                cont = 0;
            }
            else
            {
                myfile << ((double) data[i]) << ",";
                cont = cont +1;
            }

        }
    }
    myfile.close();



    //Showing Results


    // Clear memory
    data.clear();
    matchings.clear();
    simu_details1.clear();
    simu_details2.clear();

    return 0;
}
