#include <string>
#include <vector>

#include "local_descriptor.h"
#include "mex_and_omp.h"
#include "perform_IMAS.h"
#include "frot.h"
#include "fproj.h"

using namespace std;

static float InitSigma_aa = 1.6;
#define round(x) ((x)>=0?(long)((x)+0.5):(long)((x)-0.5))
const float GaussTruncate1 = 4.0;
const char delimiter = ',';

void perform_tilt_and_rotation( vector<float>& image, int width, int height, vector<float>& image_to_return, int& width_t, int& height_t, float theta, float t)
{

    int flag_dir = 1;
    int fproj_o;
    float fproj_p, fproj_bg;
    char fproj_i;
    float *fproj_x4, *fproj_y4;
    //  float frot_b=0;
    float frot_b=128;
    char *frot_k;

    frot_k = 0; // order of interpolation


    fproj_o = 3;
    fproj_p = 0;
    fproj_i = 0;
    fproj_bg = 0;
    fproj_x4 = 0;
    fproj_y4 = 0;




    //theta = theta * 180 / PI;
    float t1 = 1;
    float t2 = 1/t;

    vector<float> image_t;
    int width_r, height_r;

    // simulate a rotation: rotate the image with an angle theta. (the outside of the rotated image are padded with the value frot_b)
    frot(image, image_t, width, height, &width_r, &height_r, &theta, &frot_b , frot_k);

    /* Tilt */
    width_t = (int) (width_r * t1);
    height_t = (int) (height_r * t2);

    int fproj_sx = width_t;
    int fproj_sy = height_t;

    float fproj_x1 = 0;
    float fproj_y1 = 0;
    float fproj_x2 = width_t;
    float fproj_y2 = 0;
    float fproj_x3 = 0;
    float fproj_y3 = height_t;

    if (t==1)
    {
        image_to_return = image_t;
    }
    else
    {
        /* Anti-aliasing filtering along vertical direction */
        float sigma_aa = (InitSigma_aa/2) * sqrt(std::pow(t,2) -1);
        GaussianBlur1D(image_t,width_r,height_r,sigma_aa,flag_dir);


        // simulate a tilt: subsample the image along the vertical axis by a factor of t.
        vector<float> image_tmp(width_t*height_t);
        fproj (image_t, image_tmp, width_r, height_r, &fproj_sx, &fproj_sy, &fproj_bg, &fproj_o, &fproj_p, &fproj_i , fproj_x1 , fproj_y1 , fproj_x2 , fproj_y2 , fproj_x3 , fproj_y3, fproj_x4, fproj_y4);
        image_to_return = image_tmp;
    }


}

std::vector<float> string2vector(string s)
{
    std::vector<float> vec;
    string acc = "";
    for(int i = 0; i < (int)(s.size()); i++)
    {
        if((s)[i] == delimiter)
        {
            vec.push_back( std::atof(acc.c_str()) );
            acc = "";
        }
        else
            acc += s[i];
    }
    if (acc!="")
        vec.push_back( std::atof(acc.c_str()) );
    return vec;
}

void invert_contrast(cv::Mat& image)
{
    int w,h;
    h=image.rows;
    w=image.cols;
    for (int i=0;i<h;i++)
        for (int j=0;j<w;j++)
        {
            image.data[j*h+i] = (uchar)(255 - image.data[j*h+i]);
            //            if (max < ((int)image.data[j*h+i]))
            //                max = ((int)image.data[j*h+i]);
            //            if (min > ((int)image.data[j*h+i]))
            //                min = ((int)image.data[j*h+i]);
        }

}

void MatrixNumerics2cvMat(std::vector<TypeMap>& input, std::vector<cv::Mat>& output)
{
    for (int i=0; i<input.size();i++)
    {
        TypeMap thismap = (input[i]);
        cv::Mat thismat;
        thismat.create(thismap.nrow(),thismap.ncol(),CV_32F);
        for (int i=0;i<thismap.ncol();i++)
        {
            for (int j=0;j<thismap.nrow();j++)
            {
                thismat.col(i).row(j) = (float) thismap(j,i);
            }
        }
        output.push_back(thismat);
    }
}


#include <iostream>
#include <sys/types.h>
#include <dirent.h>
#include "../libNumerics/matrix.h"

libNumerics::matrix<double> stringvec2matrix(std::vector<string> svec)
{
    libNumerics::matrix<double> F(3,3);
    for (int m=0;m<svec.size();m++)
    {
        string s = svec[m];
        int n = 0;
        string acc = "";
        for(int i = 0; i < (int)(s.size()); i++)
        {
            if((s)[i] == delimiter)
            {
                F(m,n) = std::atof(acc.c_str());
                acc = "";
                n++;
            }
            else
                acc += s[i];
        }
        if (acc!="")
            F(m,n) = std::atof(acc.c_str());
    }
    return F;
}


void IMAS_fun( cv::Mat& queryImg, cv::Mat& targetImg)
{
    // Setting variables
    int flag_resize = 0;
    int applyfilter = 7;//3;
    int IMAS_INDEX = 1;
    bool visualize = true;

    Tmin = 5;
    ORSA_Fundamental = false;

    string algo_name = SetDetectorDescriptor(IMAS_INDEX); //not working NOW: LUCID, AGAST
    default_radius =1.0f;
    loadsimulations2do(default_radius);

    if (keys3.KeyList.size()==0)
    {
        cout<< "Third image in for a contrario model"<< endl;
        cv::Ptr<cv::FeatureDetector> detector;
        cv::Ptr<cv::DescriptorExtractor> extractor;
        detector_and_descriptor(detector, extractor);

        detector->detect(targetImg, keys3.KeyList);
        extractor->compute(targetImg, keys3.KeyList, keys3.DescList);

    }


        int w1, h1, w2, h2;
        vector<float> ipixels1,ipixels2; //output image
        opencvimage2vectorimage(queryImg,ipixels1, w1, h1);
        opencvimage2vectorimage(targetImg,ipixels2, w2, h2);

         //invert_contrast(targetImg);
        // opencvimage2vectorimage(targetImg,ipixels2,w2,h2);

        if (visualize)
        {
            // Show Images


            cv::imshow( algo_name, queryImg );
            cv::waitKey(0);
            cv::imshow( algo_name, targetImg );
            cv::waitKey(0);
        }

        // Number of threads to use
        int nthreads, maxthreads;
        /* Display info on OpenMP*/
#pragma omp parallel
        {
#pragma omp master
            {
                nthreads = my_omp_get_num_threads();
                maxthreads = my_omp_get_max_threads();
            }
        }
        my_mexPrintf("--> Using %d threads out of %d for executing %s <--\n\n",nthreads,maxthreads,algo_name.c_str());




        // Performing IMAS
        vector< vector <float> > Minfoall;
        matchingslist matchings;
        vector< float > data;



        perform_IMAS(ipixels1, w1, h1, ipixels2, w2, h2, data, matchings, Minfoall, flag_resize, applyfilter);




        //Showing Results
        cv::Mat all_matches;
        std::vector<cv::DMatch> goodmatches;
        opencv_keypointslist queryKeypoints, targetKeypoints;
        matching* thismatching;

        for (int i=0;i<(int)matchings.size();i++)
        {
            thismatching=&(matchings[i]);
            queryKeypoints.push_back( cv::KeyPoint(thismatching->first.x, thismatching->first.y, thismatching->first.scale));
            targetKeypoints.push_back( cv::KeyPoint(thismatching->second.x, thismatching->second.y, thismatching->second.scale));
            goodmatches.push_back(cv::DMatch(i, i, 0));
        }

        cv::drawMatches( queryImg, queryKeypoints, targetImg, targetKeypoints,
                         goodmatches, all_matches,
                         cv::Scalar::all(-1), cv::Scalar::all(-1),
                         vector<char>(), cv::DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS );

        cv::imwrite("result.png",all_matches);


        cv::Mat QueryOnTarget;
        std::vector<cv::Mat> MMap;
        MatrixNumerics2cvMat(IdentifiedMaps,MMap);
        if ((!ORSA_Fundamental)&&(!MMap.empty()))
        {

            cv::warpPerspective(queryImg,QueryOnTarget,MMap[0],cv::Size(targetImg.cols,targetImg.rows));
            QueryOnTarget = 2*QueryOnTarget/4+ 2*targetImg/4;
            cv::imwrite("QueryOnTarget.png",QueryOnTarget);
        }

        if (visualize)
        {
            cv::imshow(algo_name, all_matches );

            if ((!QueryOnTarget.empty()))
            {
                cv::imshow( "Query image Transformed on Target Image", QueryOnTarget );
                cv::moveWindow("Query image Transformed on Target Image", 20,all_matches.rows);
            }

            cv::waitKey(0);
        }



        // Clear memory
        data.clear();
        matchings.clear();
        Minfoall.clear();
        simu_details1.clear();
        simu_details2.clear();

}


int main(int argc, char **argv)
{
    string path = "/home/rdguez-mariano/Dropbox(Old)/Thales";
    DIR *dir = opendir(path.c_str());
    string prefix = "CMLA_image";
    string orthofile = "CMLA_ortho_23_mars_2017.png";
    cv::Mat orthoimage, QueryOnTarget_globalimage;
    std::vector<cv::Mat> QueryOnTarget_global,masks;
    orthoimage = cv::imread((path+"/"+orthofile).c_str(), CV_LOAD_IMAGE_GRAYSCALE );
    QueryOnTarget_globalimage = cv::Mat::zeros(orthoimage.rows, orthoimage.cols, orthoimage.type() );
    //orthoimage.copyTo(QueryOnTarget_globalimage);


    cv::imshow( "Main", orthoimage );
    cv::waitKey(0);
    cv::Mat mask = cv::Mat::zeros(orthoimage.rows, orthoimage.cols, orthoimage.type() );
    string sufix = ".png";
    if(dir)
    {
        struct dirent *ent;
        while((ent = readdir(dir)) != NULL)
        {
            bool filterout = false;
            std::string filepath(ent->d_name);

            for (int i = 0; i<prefix.size(); i++)
                if (prefix[i]!=filepath[i])
                    filterout = true;

            for (int i = 0; i<sufix.size(); i++)
                if (sufix[i]!=filepath[filepath.size()-sufix.size()+i])
                    filterout = true;

            if (!filterout)
            {
                cout << filepath<< endl;
                std::ifstream filein;
                filein.open((path+"/"+filepath.substr(0,filepath.size()-4)+"_PT_opt2ref.txt").c_str());
                if (filein.good())
                {

                    std::vector<string> stringvec;
                    std::vector<std::string>::iterator it;
                    while( !(filein.eof()) )
                    {
                        string s;
                        std::getline(filein, s);
                        stringvec.push_back(s);
                    }
                    libNumerics::matrix<double> F(3,3);
                    F = stringvec2matrix( stringvec );
                    cout<< F << endl;

                    std::vector<cv::Mat> MMap;
                    std::vector<TypeMap> Fvec;
                    Fvec.push_back(F);
                    MatrixNumerics2cvMat(Fvec,MMap);

                    cv::Mat QueryImg,QueryOnTarget;

                    QueryImg = cv::imread((path+"/"+filepath).c_str(), CV_LOAD_IMAGE_GRAYSCALE );
                    //invert_contrast(QueryImg);

                    int nmax,nmin,mmax,mmin; nmax = 0; nmin = orthoimage.rows; mmax = 0; mmin = orthoimage.cols;
                    cv::Mat mask_local = cv::Mat::zeros(orthoimage.rows, orthoimage.cols, orthoimage.type() );
                    cv::warpPerspective(150*cv::Mat::ones(QueryImg.rows, QueryImg.cols, orthoimage.type() ),QueryOnTarget,MMap[0],cv::Size(orthoimage.cols,orthoimage.rows));
                    for (int m=0;m<QueryOnTarget.cols;m++)
                        for (int n=0;n<QueryOnTarget.rows;n++)
                            if (*(QueryOnTarget.row(n).col(m).data)!=0)
                            {
                                if (nmax<n)
                                    nmax = n;
                                if (nmin>n)
                                    nmin = n;
                                if (mmax<m)
                                    mmax = m;
                                if (mmin>m)
                                    mmin = m;

                                mask.row(n).col(m) = mask.row(n).col(m) + 1;
                                mask_local.row(n).col(m) = 150;
                            }
                    masks.push_back(mask_local);


                    cv::warpPerspective(QueryImg,QueryOnTarget,MMap[0],cv::Size(orthoimage.cols,orthoimage.rows));
                    QueryOnTarget_global.push_back(QueryOnTarget);

                    int border = 100;
                    cv::Mat subMat1 = QueryOnTarget(cv::Rect(mmin,nmin,mmax-mmin,nmax-nmin));
                    cv::Mat subMat2 = orthoimage(cv::Rect(std::max(mmin-border,0), std::max(nmin-border,0), std::min(mmax-mmin+border,orthoimage.cols), std::min(nmax-nmin+border,orthoimage.rows) ));

                    //cv::rectangle(QueryOnTarget,cv::Point(mmin,nmin),cv::Point(mmax,nmax),255);
//                    cv::imshow("Main",subMat);
//                    cv::waitKey(0);
                    //cv::Mat sMat1,sMat2;
                    int zoom = 2;
                    cv::resize(subMat1, subMat1, cv::Size(subMat1.cols*zoom, subMat1.rows*zoom), CV_INTER_CUBIC);
                    cv::resize(subMat2, subMat2, cv::Size(subMat2.cols*zoom, subMat2.rows*zoom), CV_INTER_CUBIC);
                    cout<< (path+"/more/A_"+filepath).c_str()<<endl;
                    cv::imwrite((path+"/more/A_"+filepath).c_str(),subMat1);
                    cv::imwrite((path+"/more/B_"+filepath).c_str(),subMat2);
                    IMAS_fun(subMat1, subMat2);
                    filein.close();
                }
            }

        }

        float* temp = new float[orthoimage.rows * orthoimage.cols];
        for (int m=0;m<orthoimage.cols;m++)
            for (int n=0;n<orthoimage.rows;n++)
                temp[n+m*orthoimage.rows] =0;
        for (int i=0;i<QueryOnTarget_global.size();i++)
            for (int m=0;m<orthoimage.cols;m++)
                for (int n=0;n<orthoimage.rows;n++)
                    temp[n+m*orthoimage.rows] += QueryOnTarget_global[i].data[n+m*orthoimage.rows];
        for (int m=0;m<orthoimage.cols;m++)
            for (int n=0;n<orthoimage.rows;n++)
                if (mask.data[n+m*orthoimage.rows]!=0)
                    QueryOnTarget_globalimage.data[n+m*orthoimage.rows] = (uchar)(temp[n+m*orthoimage.rows]/mask.data[n+m*orthoimage.rows]);

        cv::imshow("Main",QueryOnTarget_globalimage);
        cv::waitKey(0);

        invert_contrast(orthoimage);
        QueryOnTarget_globalimage = QueryOnTarget_globalimage/2+ orthoimage/2;
        cv::imshow("Main",QueryOnTarget_globalimage);
        cv::waitKey(0);
    }
    else
    {
        cout << "Error opening directory" << endl;
    }
    return 0;
}



