/* ASIFT_MATLAB - Algorithm by Guoshen Yu & Jean-Michel Morel
 * Version modified by Mariano Rodr�guez Guerra 
 *
 */

#include "math.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <vector>
using namespace std;

#ifdef _OPENMP
#include <omp.h>
#endif

#include "local_descriptor.h"
#include "io_png/io_png.h"

#include "library.h"
#include "frot.h"
#include "fproj.h"
#include "compute_IMAS_keypoints.h"
#include "compute_IMAS_matches.h"
#include "mex_and_omp.h"
#include "perform_IMAS.h"
#include "IMAS_covering.h"
#include "mex.h"

# define IM_X 800
# define IM_Y 600



// Fonction principale (g�re la liaison avec Matlab)
void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
const mxArray *prhs[])
{
  /* V�rification du nombre d'arguments */
    if ( !(nrhs >= 4) ) {
        my_mexErrMsgTxt("Wrong number of input arguments!");
    } else if ( nlhs != 1) {
        my_mexErrMsgTxt("Wrong number of output arguments!");
    }

    
  /* matrices d'entr�e*/    
    long w1,h1,w2,h2,w3,h3;  // W = number of rows, H = number of columns
    w1 = mxGetM(prhs[0]);
    h1 = mxGetN(prhs[0]);
    w2 = mxGetM(prhs[1]);
    h2 = mxGetN(prhs[1]);
    vector<float> ipixels1(mxGetPr(prhs[0]), mxGetPr(prhs[0]) + w1*h1);
    vector<float> ipixels2(mxGetPr(prhs[1]), mxGetPr(prhs[1]) + w2*h2);

    int flag_resize = 0;
    int applyfilter = (int) mxGetScalar(prhs[2]); //variants of applying the filter
	int orsa_type = (int) mxGetScalar(prhs[3]);
    int IMAS_INDEX = (int) mxGetScalar(prhs[4]);

string algo_name = "Affine-"+SetDetectorDescriptor(IMAS_INDEX);//not working NOW: FREAK, LUCID, AGAST
 
// Number of threads to use
    int nthreads, maxthreads;
       /* Display info on OpenMP*/
               #pragma omp parallel
           {
               #pragma omp master
               {
                   nthreads = my_omp_get_num_threads();
                   maxthreads = my_omp_get_max_threads();
               }
           }
 my_mexPrintf("--> Using %d threads out of %d for executing %s <--\n\n",nthreads,maxthreads,algo_name.c_str());




 // Performing IMAS
    vector< vector <float> > Minfoall;
    matchingslist matchings;
    vector< float > data;
    loadsimulations2do();
    
if (orsa_type==1)
    {
        Tmin = 8;
        ORSA_Fundamental = true;
    }
    else
    {
        Tmin = 5;
        ORSA_Fundamental = false;
    }

    perform_IMAS(ipixels1, w1, h1, ipixels2, w2, h2, data, matchings, Minfoall, flag_resize, applyfilter);



    int wo = 14;
    plhs[0] = mxCreateDoubleMatrix(wo, matchings.size(), mxREAL);
    double *datamatrix = mxGetPr(plhs[0]);
    for ( int i = 0; i < (int) wo*matchings.size(); i++ )
        datamatrix[i] = (double) data[i];

    data.clear();
    matchings.clear();
    Minfoall.clear();
    //keys3_short.clear();
    simu_details1.clear();
    simu_details2.clear();

}
