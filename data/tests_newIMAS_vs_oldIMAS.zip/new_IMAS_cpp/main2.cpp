#include <string>
#include <vector>

#include "local_descriptor.h"
#include "mex_and_omp.h"
#include "perform_IMAS.h"
#include "frot.h"
#include "fproj.h"

using namespace std;

static float InitSigma_aa = 1.6;
#define round(x) ((x)>=0?(long)((x)+0.5):(long)((x)-0.5))
const float GaussTruncate1 = 4.0;
const char delimiter = ',';

void perform_tilt_and_rotation( vector<float>& image, int width, int height, vector<float>& image_to_return, int& width_t, int& height_t, float theta, float t)
{

    int flag_dir = 1;
    int fproj_o;
    float fproj_p, fproj_bg;
    char fproj_i;
    float *fproj_x4, *fproj_y4;
    //  float frot_b=0;
    float frot_b=128;
    char *frot_k;

    frot_k = 0; // order of interpolation


    fproj_o = 3;
    fproj_p = 0;
    fproj_i = 0;
    fproj_bg = 0;
    fproj_x4 = 0;
    fproj_y4 = 0;




    //theta = theta * 180 / PI;
    float t1 = 1;
    float t2 = 1/t;

    vector<float> image_t;
    int width_r, height_r;

    // simulate a rotation: rotate the image with an angle theta. (the outside of the rotated image are padded with the value frot_b)
    frot(image, image_t, width, height, &width_r, &height_r, &theta, &frot_b , frot_k);

    /* Tilt */
    width_t = (int) (width_r * t1);
    height_t = (int) (height_r * t2);

    int fproj_sx = width_t;
    int fproj_sy = height_t;

    float fproj_x1 = 0;
    float fproj_y1 = 0;
    float fproj_x2 = width_t;
    float fproj_y2 = 0;
    float fproj_x3 = 0;
    float fproj_y3 = height_t;

    if (t==1)
    {
        image_to_return = image_t;
    }
    else
    {
    /* Anti-aliasing filtering along vertical direction */
    float sigma_aa = (InitSigma_aa/2) * sqrt(std::pow(t,2) -1);
    GaussianBlur1D(image_t,width_r,height_r,sigma_aa,flag_dir);


    // simulate a tilt: subsample the image along the vertical axis by a factor of t.
    vector<float> image_tmp(width_t*height_t);
    fproj (image_t, image_tmp, width_r, height_r, &fproj_sx, &fproj_sy, &fproj_bg, &fproj_o, &fproj_p, &fproj_i , fproj_x1 , fproj_y1 , fproj_x2 , fproj_y2 , fproj_x3 , fproj_y3, fproj_x4, fproj_y4);
    image_to_return = image_tmp;
}


}

std::vector<float> string2vector(string s)
{
    std::vector<float> vec;
    string acc = "";
    for(int i = 0; i < (int)(s.size()); i++)
    {
        if((s)[i] == delimiter)
        {
            vec.push_back( std::atof(acc.c_str()) );
            acc = "";
        }
        else
            acc += s[i];
    }
    if (acc!="")
        vec.push_back( std::atof(acc.c_str()) );
    return vec;
}

void invert_contrast(cv::Mat& image)
{
    int w,h;
    h=image.rows;
    w=image.cols;
    for (int i=0;i<h;i++)
        for (int j=0;j<w;j++)
        {
            image.data[j*h+i] = (uchar)(255 - image.data[j*h+i]);
//            if (max < ((int)image.data[j*h+i]))
//                max = ((int)image.data[j*h+i]);
//            if (min > ((int)image.data[j*h+i]))
//                min = ((int)image.data[j*h+i]);
        }

}

void MatrixNumerics2cvMat(std::vector<TypeMap>& input, std::vector<cv::Mat>& output)
{
    for (int i=0; i<input.size();i++)
    {
        TypeMap thismap = (input[i]);
        cv::Mat thismat;
        thismat.create(thismap.nrow(),thismap.ncol(),CV_32F);
        for (int i=0;i<thismap.ncol();i++)
        {
            for (int j=0;j<thismap.nrow();j++)
            {
                thismat.col(i).row(j) = (float) thismap(j,i);
            }
        }
        output.push_back(thismat);
    }
}

/**
 * @brief main
 * @param image1 Path to image1 (png)
 * @param image2 Path to image1 (png)
 * @param applyfilter Tells which filters should be applied in the function compute_IMAS_matches(). This parameter is in fact pass on to the function perform_IMAS().
 * @param ORSA_type Tells which version of ORSA should be applied (if it is to be applied in applyfilter):
 * - Homography - <a href="http://www.ipol.im/pub/art/2012/mmm-oh/">Lionel Moisan, Pierre Moulon, and Pascal Monasse, Automatic Homographic Registration of a Pair of Images, with A Contrario Elimination of Outliers, Image Processing On Line, 2 (2012), pp. 56–73</a>.
 * - Fundamental - <a href="http://www.ipol.im/pub/art/2016/147/">Lionel Moisan, Pierre Moulon, and Pascal Monasse, Fundamental Matrix of a Stereo Pair, with A Contrario Elimination of Outliers, Image Processing On Line, 6 (2016), pp. 89–113</a>.
 * @param IMAS_INDEX Tells which descriptor+extractor to use from local_descriptor.h
 * @param visualize (Optional) Tells if results should also be displayed on the screen.
 * @param radius (Optional) Forces to use a predefined log(radius)-covering instead of the default one.
 *
 *
 * @code
 * // Execute Affine-RootSIFT and apply ORSA Homography & Misc
 * ./main "image1.png" "image2.png" 7 0 11
 *
 * // Execute Affine-SURF and apply ORSA Homography & Misc
 * ./main "image1.png" "image2.png" 7 0 2
 *
 * // Execute Affine-SIFT silently (no screen, but results are written on disc)
 * ./main "image1.png" "image2.png" 7 0 1 0
 *
 * // Execute Affine-SIFT on the screen and use the optimal log(1.7)-covering
 * ./main "image1.png" "image2.png" 7 0 1 1 1.7
 * @endcode
 */
int main(int argc, char **argv)
{



    //////////////////////////////////////////////// Input
    // Read image1
    int w, h;
    cv::Mat image;
    image = cv::imread(argv[1], CV_LOAD_IMAGE_GRAYSCALE );
    std::vector<float> ipixels;
    opencvimage2vectorimage(image,ipixels,w,h);


// Setting variables
    int flag_resize = 0;
    int applyfilter = atoi(argv[3]);
    int orsa_type = atoi(argv[4]);
    int IMAS_INDEX = atoi(argv[5]);
    bool visualize = true;

   string algo_name = SetDetectorDescriptor(IMAS_INDEX); //not working NOW: LUCID, AGAST
   if (default_radius!=1)
   {
       algo_name= "Affine-"+algo_name;
   if ((IMAS_INDEX==IMAS_SIFT)||(IMAS_INDEX==IMAS_SURF))
       algo_name ="Optimal-"+algo_name;
   }


   string line;
   ifstream myfile ("2do.txt");
   vector<float> tilts1,tilts2, rots1,rots2, results;
   if (myfile.is_open())
    {
      getline (myfile,line);
      tilts1 = string2vector(line);
      getline (myfile,line);
      rots1 = string2vector(line);
      getline (myfile,line);
      tilts2 = string2vector(line);
      getline (myfile,line);
      rots2 = string2vector(line);
      myfile.close();
    }

if ((rots1.size()!=tilts1.size())||(rots1.size()==0))
    exit(-1);
if ((rots2.size()!=tilts2.size())||(rots2.size()==0))
    exit(-1);
if ((rots1.size()!=rots2.size()))
    exit(-1);


for (int ii=0; ii<tilts1.size(); ii++)
{
    cv::Mat queryImg,targetImg;
   double t1 = (double) tilts1[ii];
   double theta1 = (double) rots1[ii];
   double t2 = (double) tilts2[ii];
   double theta2 = (double) rots2[ii];
   int w1, h1, w2, h2;
   vector<float> ipixels1,ipixels1temp,ipixels2,ipixels2temp; //output image
   // im1 = perform_image_tilt(im,t,0);
   // im1 = perform_image_tilt(im1,1,psi1);
   perform_tilt_and_rotation(ipixels, w, h, ipixels1temp, w1, h1, 0, t1);
   perform_tilt_and_rotation(ipixels1temp, w1, h1, ipixels1, w1, h1, theta1, 1);
   vectorimage2opencvimage(ipixels1, queryImg, w1, h1);

   //im2 = perform_image_tilt(im,fixed_tilt,90);
   //im2 = perform_image_tilt(im2,1,psi2);
   perform_tilt_and_rotation(ipixels, w, h, ipixels2temp, w2, h2, 90, t2);
   perform_tilt_and_rotation(ipixels2temp, w2, h2, ipixels2, w2, h2, theta2, 1);
   vectorimage2opencvimage(ipixels2, targetImg, w2, h2);

  // invert_contrast(targetImg);
  // opencvimage2vectorimage(targetImg,ipixels2,w2,h2);


   my_mexPrintf("\n Simulated images: \n im1 = R_{%i} T_{%.1f} R_{0}  Im   ;   im2 = R_{%i} T_{%.1f} R_{90} Im \n\n",t1,(int)theta1,t2,(int)theta2);
if (visualize)
{
// Show Images


    cv::imshow( algo_name, queryImg );
    cv::waitKey(0);
    cv::imshow( algo_name, targetImg );
    cv::waitKey(0);
}


// Number of threads to use
    int nthreads, maxthreads;
       /* Display info on OpenMP*/
               #pragma omp parallel
           {
               #pragma omp master
               {
                   nthreads = my_omp_get_num_threads();
                   maxthreads = my_omp_get_max_threads();
               }
           }
 my_mexPrintf("--> Using %d threads out of %d for executing %s <--\n\n",nthreads,maxthreads,algo_name.c_str());




 // Performing IMAS
    vector< vector <float> > Minfoall;
    matchingslist matchings;
    vector< float > data;

    if (argc>=8)
        default_radius = atof(argv[7]);

    loadsimulations2do();
    if (orsa_type==1)
    {
        Tmin = 8;
        ORSA_Fundamental = true;
    }
    else
    {
        Tmin = 5;
        ORSA_Fundamental = false;
    }

    perform_IMAS(ipixels1, w1, h1, ipixels2, w2, h2, data, matchings, Minfoall, flag_resize, applyfilter);
    results.push_back(matchings.size());




     //Showing Results
     cv::Mat all_matches;
     std::vector<cv::DMatch> goodmatches;
     opencv_keypointslist queryKeypoints, targetKeypoints;
     matching* thismatching;

     for (int i=0;i<(int)matchings.size();i++)
     {
         thismatching=&(matchings[i]);
         queryKeypoints.push_back( cv::KeyPoint(thismatching->first.x, thismatching->first.y, thismatching->first.scale));
         targetKeypoints.push_back( cv::KeyPoint(thismatching->second.x, thismatching->second.y, thismatching->second.scale));
         goodmatches.push_back(cv::DMatch(i, i, 0));
     }

     cv::drawMatches( queryImg, queryKeypoints, targetImg, targetKeypoints,
                          goodmatches, all_matches,
                      cv::Scalar::all(-1), cv::Scalar::all(-1),
                      vector<char>(), cv::DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS );

    cv::imwrite("result.png",all_matches);


    cv::Mat QueryOnTarget;
    std::vector<cv::Mat> MMap;
    MatrixNumerics2cvMat(IdentifiedMaps,MMap);
    if ((!ORSA_Fundamental)&&(!MMap.empty()))
    {

        cv::warpPerspective(queryImg,QueryOnTarget,MMap[0],cv::Size(targetImg.cols,targetImg.rows));
        QueryOnTarget = 2*QueryOnTarget/4+ 2*targetImg/4;
        cv::imwrite("QueryOnTarget.png",QueryOnTarget);
    }

     if (visualize)
     {
         cv::imshow(algo_name, all_matches );

         if ((!QueryOnTarget.empty()))
         {
             cv::imshow( "Query image Transformed on Target Image", QueryOnTarget );
             cv::moveWindow("Query image Transformed on Target Image", 20,all_matches.rows);
         }

         cv::waitKey(0);
     }



// Clear memory
     data.clear();
     matchings.clear();
     Minfoall.clear();
     simu_details1.clear();
     simu_details2.clear();

}


 ofstream myfile2;
 myfile2.open ("data_simu.csv", std::ofstream::out | std::ofstream::trunc);

 for ( int i = 0; i < (int) (results.size()-1); i++ )
    myfile2 << ((double) tilts1[i]) << ",";
 myfile2 << ((double) tilts1[results.size()-1]) << endl;

 for ( int i = 0; i < (int) (results.size()-1); i++ )
    myfile2 << ((double) rots1[i]) << ",";
 myfile2 << ((double) rots1[results.size()-1]) << endl;

 for ( int i = 0; i < (int) (results.size()-1); i++ )
    myfile2 << ((double) tilts2[i]) << ",";
 myfile2 << ((double) tilts2[results.size()-1]) << endl;

 for ( int i = 0; i < (int) (results.size()-1); i++ )
    myfile2 << ((double) rots2[i]) << ",";
 myfile2 << ((double) rots2[results.size()-1]) << endl;

 for ( int i = 0; i < (int) (results.size()-1); i++ )
    myfile2 << ((double) results[i]) << ",";
 myfile2 << ((double) results[results.size()-1]) << endl;

  myfile2.close();
    return 0;
}
