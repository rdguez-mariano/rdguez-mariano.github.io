#include "frot.h"
#include "fproj.h"
#include <math.h>
#include "compute_IMAS_keypoints.h"
#include "libNumerics/numerics.h"


using namespace std;

#define ABS(x)    (((x) > 0) ? (x) : (-(x)))
#define round(x) ((x)>=0?(long)((x)+0.5):(long)((x)-0.5))


/** @brief Gives the amount of smoothing applied to the image at the
first level of each octave.  In effect, this determines the sampling
needed in the image domain relative to amount of smoothing.  Good
values determined experimentally are in the range 1.2 to 1.8.
*/
const float InitSigma_aa = 1.6;


/** @brief Gaussian convolution kernels are truncated at this sigma from
the center.  While it is more efficient to keep this value small,
experiments show that for consistent scale-space analysis it needs
a value of about 3.0, at which point the Gaussian has fallen to
only 1% of its central value.  A value of 2.0 greatly reduces
keypoint consistency, and a value of 4.0 is better than 3.0.
*/
const float GaussTruncate1 = 4.0;


/* --------------------------- Blur image --------------------------- */
/** @brief Same as ConvBuffer, but implemented with loop unrolling for increased
speed.  This is the most time intensive routine in keypoint detection,
so deserves careful attention to efficiency.  Loop unrolling simply
sums 5 multiplications at a time to allow the compiler to schedule
operations better and avoid loop overhead.  This almost triples
speed of previous version on a Pentium with gcc.
*/
void ConvBufferFast(float *buffer, float *kernel, int rsize, int ksize)
{
    int i;
    float *bp, *kp, *endkp;
    float sum;

    for (i = 0; i < rsize; i++) {
        sum = 0.0;
        bp = &buffer[i];
        kp = &kernel[0];
        endkp = &kernel[ksize];

        while (kp < endkp) {
            sum += *bp++ * *kp++;
        }

        buffer[i] = sum;
    }
}

/** @brief Convolve image with the 1-D kernel vector along image rows.  This
is designed to be as efficient as possible.  Pixels outside the
image are set to the value of the closest image pixel.
*/
void ConvHorizontal(vector<float>& image, int width, int height, float *kernel, int ksize)
{
    int rows, cols, r, c, i, halfsize;
    rows = height;
    cols = width;

    //float buffer[4000];
    float buffer[cols + ksize]; // Mariano Rodríguez - Allow big images
    vector<float> pixels(width*height);

    halfsize = ksize / 2;
    pixels = image;
    //assert(cols + ksize < 4000);

    for (r = 0; r < rows; r++) {
        /* Copy the row into buffer with pixels at ends replicated for
    half the mask size.  This avoids need to check for ends
    within inner loop. */
        for (i = 0; i < halfsize; i++)
            buffer[i] = pixels[r*cols];
        for (i = 0; i < cols; i++)
            buffer[halfsize + i] = pixels[r*cols+i];
        for (i = 0; i < halfsize; i++)
            buffer[halfsize + cols + i] = pixels[r*cols+cols-1];

        ConvBufferFast(buffer, kernel, cols, ksize);
        for (c = 0; c < cols; c++)
            pixels[r*cols+c] = buffer[c];
    }
    image = pixels;
}


/** @brief Same as ConvHorizontal, but apply to vertical columns of image.
*/
void ConvVertical(vector<float>& image, int width, int height, float *kernel, int ksize)
{
    int rows, cols, r, c, i, halfsize;
    rows = height;
    cols = width;

    //float buffer[4000];
    float buffer[rows + ksize];  // Mariano Rodríguez - Allow big images
    vector<float> pixels(width*height);

    halfsize = ksize / 2;
    pixels = image;
    //assert(rows + ksize < 4000);

    for (c = 0; c < cols; c++) {
        for (i = 0; i < halfsize; i++)
            buffer[i] = pixels[c];
        for (i = 0; i < rows; i++)
            buffer[halfsize + i] = pixels[i*cols+c];
        for (i = 0; i < halfsize; i++)
            buffer[halfsize + rows + i] = pixels[(rows - 1)*cols+c];

        ConvBufferFast(buffer, kernel, rows, ksize);
        for (r = 0; r < rows; r++)
            pixels[r*cols+c] = buffer[r];
    }

    image = pixels;
}



/** @brief 1D Convolve image with a Gaussian of width sigma and store result back
in image.   This routine creates the Gaussian kernel, and then applies
it in horizontal (flag_dir=0) OR vertical directions (flag_dir!=0).
*/
void GaussianBlur1D(vector<float>& image, int width, int height, float sigma, int flag_dir)
{
    float x, kernel[100], sum = 0.0;
    int ksize, i;

    /* The Gaussian kernel is truncated at GaussTruncate sigmas from
  center.  The kernel size should be odd.
  */
    ksize = (int)(2.0 * GaussTruncate1 * sigma + 1.0);
    ksize = MAX(3, ksize);    /* Kernel must be at least 3. */
    if (ksize % 2 == 0)       /* Make kernel size odd. */
        ksize++;
    //assert(ksize < 100);

    /* Fill in kernel values. */
    for (i = 0; i <= ksize; i++) {
        x = i - ksize / 2;
        kernel[i] = exp(- x * x / (2.0 * sigma * sigma));
        sum += kernel[i];
    }
    /* Normalize kernel values to sum to 1.0. */
    for (i = 0; i < ksize; i++)
        kernel[i] /= sum;

    if (flag_dir == 0)
    {
        ConvHorizontal(image, width, height, kernel, ksize);
    }
    else
    {
        ConvVertical(image, width, height, kernel, ksize);
    }
}



/* Inverse for the digital T_tR_\theta which is in fact T_t \tau_1 R_\theta
 * where \tau_1 is a translation which keeps the image in the first quadrant */
/**
 * @brief Gets tilted coordinates \f$ (x^\prime,y^\prime) \in [1,m_x]\times[1,m_y]\f$ from image coordinates \f$(x,y) \in [1,n_x]\times[1,n_y]\f$ where
 * \f$ T_tR_\phi (x,y) = (x^\prime,y^\prime) \f$. This takes into account the fact that a digital \f$R_\phi\f$ applies a translation to reframe the image.
 * @param (x,y) Enters image coordiantes and returns tilted coordinates
 * @param w Width from the original image (\f$ n_x \f$)
 * @param h Width from the original image (\f$ n_y \f$)
 * @param t Tilt applied in the y direction
 * @param theta Direction of the tilt
 * @author Mariano Rodríguez
 */
void imagecoor2tiltedcoor(float& x, float& y, const int& w, const int& h, const float& t, const float& theta)
{
    // Apply R_\theta

    // Prepare rotation matrix
    libNumerics::matrix<float> Rot(2,2), vec(2,1), corners(2,4);
    // Rot = [cos(Rtheta) -sin(Rtheta);sin(Rtheta) cos(Rtheta)];
    Rot(0,0) = cos(theta); Rot(0,1) = sin(theta);
    Rot(1,0) = -sin(theta); Rot(1,1) = cos(theta);


    vec(0,0) = x-1;
    vec(1,0) = y-1;

    // rotation -> [x1;y1] = Rot*[x1;y1]
    vec = (Rot*vec);
    x = vec(0,0);
    y = vec(1,0);


    // Translate so that image borders are in the first quadrant?
    float  x_ori, y_ori;
    // A = Rot*[ [0;h1] [w1;0] [w1;h1] [0;0] ];
    corners(0,0) = 0;   corners(0,1) = w-1;   corners(0,2) = w-1;   corners(0,3) = 0;
    corners(1,0) = 0;  corners(1,1) = 0;    corners(1,2) = h-1;   corners(1,3) = h-1;

    corners = Rot*corners;

    //x_ori = min(corners(1,:));
    //y_ori = min(corners(2,:));
    x_ori = corners(0,0); y_ori = corners(1,0);
    for(int i=1; i<4; i++)
    {
        if (x_ori>corners(0,i))
            x_ori = corners(0,i);

        if (y_ori>corners(1,i))
            y_ori = corners(1,i);
    }

    // translation and Tilt T_t
    x = x - x_ori + 1;
    y = (y - y_ori)/t + 1;
}


/**
 * @brief Gets image coordinates \f$(x,y) \in [1,n_x]\times[1,n_y]\f$ from tilted coordinates \f$T_tR_\phi(x,y) \in [1,m_x]\times[1,m_y]\f$
 * @param (x,y) Enters image coordiantes and returns tilted coordinates
 * @param w Width from the original image (\f$ n_x \f$)
 * @param h Width from the original image (\f$ n_y \f$)
 * @param t Tilt that was applied in the y direction
 * @param theta Direction of the tilt that was applied
 * @return True if the computed image-coordinates fall inside the true image boundaries.
 * @author Mariano Rodríguez
 */
bool tiltedcoor2imagecoor(float& x, float& y, const int& w, const int& h, const float& threshold , const float& t, const float& theta)
{

    // Get initial translation \tau_{x_ori,y_ori}

    // Prepare rotation matrix
    libNumerics::matrix<float> Rot(2,2), vec(2,1), corners(2,4);
    // Rot = [cos(Rtheta) -sin(Rtheta);sin(Rtheta) cos(Rtheta)];
    Rot(0,0) = cos(theta); Rot(0,1) = sin(theta);
    Rot(1,0) = -sin(theta); Rot(1,1) = cos(theta);

    // Translate so that image borders are in the first quadrant?
    float  x_ori, y_ori;
    // A = Rot*[ [0;h-1] [w-1;0] [w-1;h-1] [0;0] ];
    corners(0,0) = 0;   corners(0,1) = w-1;   corners(0,2) = w-1;   corners(0,3) = 0;
    corners(1,0) = 0;  corners(1,1) = 0;    corners(1,2) = h-1;   corners(1,3) = h-1;
    corners = Rot*corners;

    //x_ori = min(corners(1,:));
    //y_ori = min(corners(2,:));
    x_ori = corners(0,0); y_ori = corners(1,0);
    for(int i=1; i<4; i++)
    {
        if (x_ori>corners(0,i))
            x_ori = corners(0,i);

        if (y_ori>corners(1,i))
            y_ori = corners(1,i);
    }

    // Distance from the point to the true image borders
    // if less than threshold stop computations and return false
    float xvec[5], yvec[5], d;
    for(int i=0; i<4; i++)
    {// translation and Tilt T_t
        xvec[i] = corners(0,i) - x_ori + 1;
        yvec[i] = (corners(1,i) - y_ori)/t + 1;
        //cout<<"xvec="<<xvec[i]<< " yvec="<<yvec[i]<<endl;
    }
    xvec[4] = xvec[0];
    yvec[4] = yvec[0];
    //cout<<"xvec="<<xvec[4]<< " yvec="<<yvec[4]<<endl;

    for(int i=0; i<4; i++)
    {
        d = ABS( (yvec[i+1]-yvec[i])*x - (xvec[i+1]-xvec[i])*y + xvec[i+1]*yvec[i] - yvec[i+1]*xvec[i] ) / sqrt( pow(xvec[i+1]-xvec[i],2) + pow(yvec[i+1]-yvec[i],2) );
        //cout<<"d="<<d<<endl;
        if (d <= threshold)
            return(false);
    }


    // Inverse of Tilt T_t and translation
    x = (x-1)   + x_ori;
    y = (y-1)*t + y_ori;

    vec(0,0) = x;
    vec(1,0) = y;

    // rotation -> [x1;y1] = Rot^{-1}*[x1;y1]
    Rot(1,0) = -Rot(1,0); Rot(0,1) = -Rot(0,1);
    vec = (Rot*vec);
    x = vec(0,0) + 1;
    y = vec(1,0) + 1;

    if ( (x>w)||(y>h)||(x<1)||(y<1) )
        return(false);
    else
        return(true);
}


void Add_IMAS_KP(IMAS_keypointlist& keys, std::vector<IMAS::IMAS_KeyPoint*>& mapKP, int width, int height)
{
    float x,y,t,theta;
    int xr,yr;
    bool only_center;
    for(int i=0; i<keys.KeyList.size();i++)
    {

        x = keys.KeyList[i].pt.x;
        xr = (int) round(x);

        y = keys.KeyList[i].pt.y;
        yr = (int) round(y);

        t = keys.KeyList[i].t;
        theta = keys.KeyList[i].theta;

        int ind =  yr*width + xr, newind;
        newind = ind;
        if ( mapKP[ind]==0 )
        {
            // create new imas element
            mapKP[ind] = new IMAS::IMAS_KeyPoint();
            mapKP[ind]->x = x;
            mapKP[ind]->y = y;
            mapKP[ind]->sum_x = x;
            mapKP[ind]->sum_y = y;
            mapKP[ind]->KPvec.push_back(keys.KeyList[i]);
        }
        else
        {
            mapKP[ind]->KPvec.push_back(keys.KeyList[i]);
            mapKP[ind]->sum_x += x;
            mapKP[ind]->sum_y += y;
            mapKP[ind]->x = mapKP[ind]->sum_x / mapKP[ind]->KPvec.size();
            mapKP[ind]->y = mapKP[ind]->sum_y / mapKP[ind]->KPvec.size();


            //update newind
//            x = mapKP[ind]->x;
//            xr = (int) round(x);
//            y = mapKP[ind]->y;
//            yr = (int) round(y);
//            newind = yr*width + xr;

        }

        only_center = false;
        int r = 6;
        while(!only_center)
        {
            only_center = true;
            for (int xi = xr-r; xi<=xr+r; xi++)
                for (int yi = yr-r; yi<=yr+r; yi++)
                {
                    if (( sqrt(pow(xi-xr,2) + pow(yi-yr,2))<=r )&&(xi>0)&&(xi<width)&&(yi>0)&&(yi<height))
                    {
                        int indi = yi*width + xi;
                        if ( (mapKP[indi]!=0)&&(indi!=ind) )
                        {
                            //merge indi to ind
                            only_center = false;
                            mapKP[ind]->sum_x += mapKP[indi]->sum_x;
                            mapKP[ind]->sum_y += mapKP[indi]->sum_y;

                            for (int k=0;k<(int)mapKP[indi]->KPvec.size();k++)
                            {
                                mapKP[ind]->KPvec.push_back(mapKP[indi]->KPvec[k]);
                            }
                            mapKP[indi] = 0;

                            mapKP[ind]->x = mapKP[ind]->sum_x / mapKP[ind]->KPvec.size();
                            mapKP[ind]->y = mapKP[ind]->sum_y / mapKP[ind]->KPvec.size();

                            //update newind
                            x = mapKP[ind]->x;
                            xr = (int) round(x);
                            y = mapKP[ind]->y;
                            yr = (int) round(y);
                            newind = yr*width + xr;

                            if (newind!=ind)
                            {
                                if (mapKP[newind]==0)
                                {// newind empty
                                    mapKP[newind] = mapKP[ind];
                                    mapKP[ind] = 0;
                                    ind = newind;
                                }
                                else
                                { // newind not empty
                                    mapKP[newind]->sum_x += mapKP[ind]->sum_x;
                                    mapKP[newind]->sum_y += mapKP[ind]->sum_y;

                                    for (int k=0;k<(int)mapKP[ind]->KPvec.size();k++)
                                    {
                                        mapKP[newind]->KPvec.push_back(mapKP[ind]->KPvec[k]);
                                    }

                                    mapKP[newind]->x = mapKP[newind]->sum_x / mapKP[newind]->KPvec.size();
                                    mapKP[newind]->y = mapKP[newind]->sum_y / mapKP[newind]->KPvec.size();
                                    mapKP[ind] = 0;
                                    ind = newind;
                                }
                            }
                        }
                    }

                }
        }

    }

}





/* -------------- MAIN FUNCTION ---------------------- */
/**
 * @brief Computes all keypoints comming from a set of optical tilts.
 * @param image Input image.
 * @param width Width of the input image.
 * @param height Height of the input image.
 * @param keys_all Returns all keypoints indexed by tilt and rotation.
 * @param simu_details Specifies the optical tilts that are to be performed.
 * @return The total number of keypoints that have been found.
 */
int compute_IMAS_keypoints(vector<float>& image, int width, int height,std::vector<IMAS::IMAS_KeyPoint*>& imasKP, std::vector<tilt_simu>& simu_details,std::vector<float>& stats)
{

    std::vector<IMAS::IMAS_KeyPoint*> mapKP;
    mapKP.resize(width*height);

    for(int i=0;i<width*height;i++)
        mapKP[0]= 0;

    int num_tilt, tt;
    int fproj_o;
    float fproj_p, fproj_bg;
    char fproj_i;
    float *fproj_x4, *fproj_y4;
    //  float frot_b=0;
    float frot_b=128;
    char *frot_k;
    int flag_dir = 1;
    //float BorderFact=6*sqrt(2.);

    int num_keys_total=0;


    fproj_o = 3;
    fproj_p = 0;
    fproj_i = 0;
    fproj_bg = 0;
    fproj_x4 = 0;
    fproj_y4 = 0;

    frot_k = 0;


    /* Affine simulation (rotation+tilt simulation) */
    // Loop on tilts.
    num_tilt = simu_details.size();
#pragma omp parallel
#pragma omp master
    {
        for (tt = 1; tt <= num_tilt; tt++)
        {
            float t = simu_details[tt-1].t;

            float t1 = 1;
            float t2 = 1/t;

            if ( t == 1 )  // it will ignore rotations for tilts=1 !!!
            {
                // copy the image from vector to array as compute_keypoints uses only array.
#pragma omp task firstprivate(tt) shared(image, mapKP)
                {
                    IMAS_keypointlist keys;
                    IMAS::IMAS_Matrix queryImg;
#pragma omp critical
                    vectorimage2opencvimage(image, queryImg, width, height);

                    compute_local_descriptor_keypoints(queryImg,keys,t,0.0f);

#pragma omp critical
                    Add_IMAS_KP(keys, mapKP, width,height);
                }

            }
            else
            {
                // The number of rotations to simulate under the current tilt.
                int num_rot1 = simu_details[tt-1].rots.size();

                // Loop on rotations.
                for ( int rr = 1; rr <= num_rot1; rr++ )
                {
#pragma omp task firstprivate(tt,rr) shared(image, mapKP)
                    {

                        float theta = simu_details[tt-1].rots[rr-1];
                        theta = theta * 180 / M_PI;

                        vector<float> image_t;
                        int width_r, height_r;

                        // simulate a rotation: rotate the image with an angle theta. (the outside of the rotated image are padded with the value frot_b)
#pragma omp critical
                        frot(image, image_t, width, height, &width_r, &height_r, &theta, &frot_b , frot_k);

                        /* Tilt */
                        int width_t = (int) (width_r * t1);
                        int height_t = (int) (height_r * t2);

                        int fproj_sx = width_t;
                        int fproj_sy = height_t;

                        float fproj_x1 = 0;
                        float fproj_y1 = 0;
                        float fproj_x2 = width_t;
                        float fproj_y2 = 0;
                        float fproj_x3 = 0;
                        float fproj_y3 = height_t;

                        /* Anti-aliasing filtering along vertical direction */

                        // Guoshen Yu proposals
                        /* sigma_aa = InitSigma_aa * log2(t);*/
                        /*float sigma_aa = InitSigma_aa * t / 2; */

                        // Mariano Rodríguez ( 07/02/2017 )
                        float sigma_aa = (InitSigma_aa/2) * sqrt( pow(t,2) - 1.0f ); /* As the optical tilt */

                        GaussianBlur1D(image_t,width_r,height_r,sigma_aa,flag_dir);


                        // simulate a tilt: subsample the image along the vertical axis by a factor of t.
                        vector<float> image_tmp(width_t*height_t);
                        fproj (image_t, image_tmp, width_r, height_r, &fproj_sx, &fproj_sy, &fproj_bg, &fproj_o, &fproj_p, &fproj_i , fproj_x1 , fproj_y1 , fproj_x2 , fproj_y2 , fproj_x3 , fproj_y3, fproj_x4, fproj_y4);

                        IMAS::IMAS_Matrix queryImg;
                        vectorimage2opencvimage(image_tmp, queryImg, width_t, height_t);

                        // compute SIFT keypoints on simulated image.
                        IMAS_keypointlist keypoints, keys;
                        opencv_keypointslist* keypoints_filtered = &(keys.KeyList);
                        keys.KeyList.clear();
                        vector<int> index_filtered;


                        compute_local_descriptor_keypoints(queryImg,(keypoints),t,theta);


                        /* check if the keypoint is located on the boundary of the parallelogram (i.e., the boundary of the distorted input image). If so, remove it to avoid boundary artifacts. */
                        if ( keypoints.KeyList.size() != 0 )
                        {
                            for ( int cc = 0; cc < (int) keypoints.KeyList.size(); cc++ )
                            {

                                float x0, y0, BorderTh;

                                x0 = keypoints.KeyList[cc].pt.x;
                                y0 = keypoints.KeyList[cc].pt.y;

                                //Keep the descriptor off the border... BorderTh = diagonal length of the descriptor
                                BorderTh = keypoints.KeyList[cc].size;

                                if (tiltedcoor2imagecoor(x0, y0, width, height,BorderTh, 1/t2, theta* M_PI / 180))
                                {
                                    // Normalize the coordinates of the matched points by compensate the simulate affine transformations
                                    keypoints.KeyList[cc].pt.x = x0;
                                    keypoints.KeyList[cc].pt.y = y0;

#ifdef _NO_OPENCV
                                    if (sift_desc)
                                    {
                                        (static_cast<keypoint*>(keypoints.KeyList[cc].pt.kp_ptr))->x = x0;
                                        (static_cast<keypoint*>(keypoints.KeyList[cc].pt.kp_ptr))->y = y0;
                                    }
                                    else
                                    {
                                        (static_cast<descriptor*>(keypoints.KeyList[cc].pt.kp_ptr))->kP->x = x0;
                                        (static_cast<descriptor*>(keypoints.KeyList[cc].pt.kp_ptr))->kP->y = y0;
                                    }
#endif
                                    keypoints_filtered->push_back(keypoints.KeyList[cc]);
                                    index_filtered.push_back(cc);

                                }

                            }
#pragma omp critical
                            Add_IMAS_KP(keys, mapKP, width,height);
#ifndef _NO_OPENCV
                            // Now let's copy the descriptors of those keypoints that have been filtered
                            filter_DescList(keypoints.DescList, index_filtered, keys_all[tt-1][rr-1].DescList);
#endif
                        }


                    }
                }// end of for loop on rotation
            }
        } // end of foor loop on tilts
    }

    // save in imasKP and do stats
    int num_max = 0, num_min = 500000, total = 0;
    float num_mean = 0;
    for (int i = 0; i < (int) mapKP.size(); i++)
        if (mapKP[i]!=0)
        {
            imasKP.push_back(mapKP[i]);
            total +=mapKP[i]->KPvec.size();
            num_keys_total += 1;//(int) mapKP[i]->KPvec.size();
            if (num_max<mapKP[i]->KPvec.size())
                num_max = mapKP[i]->KPvec.size();
            if (num_min>mapKP[i]->KPvec.size())
                num_min = mapKP[i]->KPvec.size();
            num_mean +=mapKP[i]->KPvec.size();
        }
    num_mean = num_mean/num_keys_total;
    stats.push_back((float)total);
    stats.push_back((float)num_min);
    stats.push_back(num_mean);
    stats.push_back((float)num_max);



//    vector<float> misdatos;
//    misdatos.resize(width*height);

//    for (int i=0;i<width*height;i++)
//    {
//        if (mapKP[i]!=0)
//        {
//            misdatos[i] = mapKP[i]->KPvec.size();
////            cout<<"x = "<<mapKP[i]->x<< "; y = "<<mapKP[i]->y<<endl;
////            for (int k=0;k<mapKP[i]->KPvec.size();k++)
////                cout<<"    xi = "<<mapKP[i]->KPvec[k].pt.x<< "; yi = "<<mapKP[i]->KPvec[k].pt.y<<endl;
////            cout<<"**********************"<<endl;
//        }
//        else
//            misdatos[i] = 0;
//    }
//    IMAS::IMAS_Matrix output_image(misdatos,width,height);

//    stringstream s;
//    s<<"output_image"<<num_keys_total<<".png";
//    string str = s.str();
//    write_png_f32(str.c_str(), output_image.data, width, height,1);




    return num_keys_total;
}
