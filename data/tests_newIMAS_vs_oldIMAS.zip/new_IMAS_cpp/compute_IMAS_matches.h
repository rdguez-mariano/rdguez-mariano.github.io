/**
  * @file compute_IMAS_matches.h
  * @authors <small>(Original code)</small> Guoshen Yu, Mariano Rodríguez
  * @date 2017
  * @brief Computing matches from all combinations of simulated optical tilts.
  * @warning This file is linked to the patent Jean-Michel Morel and Guoshen Yu, Method and device for the invariant affine recognition recognition of shapes (WO/2009/150361), patent pending.
  */
#ifndef COMPUTE_IMAS_MATCHES_H
#define COMPUTE_IMAS_MATCHES_H

#include <vector>
#include "IMAS_covering.h"
#include "mex_and_omp.h"
#ifdef _NO_OPENCV
#include "local_descriptors_standalone.h"
#else
#include "local_descriptor.h"
#endif


/**
 * @brief Minimum number of matches for a filter (like ORSA Homography) to be applied
 */
extern int Tmin;
/**
 * @brief Tells if ORSA Fundamental should be applied. If its value is false, then ORSA Homography is applied.
 */
extern bool ORSA_Fundamental;
extern double ORSA_precision;
extern float mratio;

#include "libNumerics/numerics.h"
typedef libNumerics::matrix<double> TypeMap;

/**
 * @brief After compute_IMAS_matches is runned, you will find here the associated matrices to the maps that have been identified by ORSA.
 */
extern std::vector<TypeMap> IdentifiedMaps;


// applyfilter equal to the sum of the desired filters to apply
# define APPLY_UNIQUE 1
# define APPLY_MULTI 2
# define APPLY_ORSA 4

/**
 * @brief Computes matches from keypoints and descriptors comming from all possible combinations of simulated optical tilts.
 * @param w1 Width of image1
 * @param h1 Height of image1
 * @param w2 Width of image2
 * @param h2 Height of image2
 * @param keys1 Keypoints and descriptors found in all simulated optical tilts of image1
 * @param keys2 Keypoints and descriptors found in all simulated optical tilts of image2
 * @param matchings Returns a vector of filtered matches
 * @param Minfoall Returns more information on filtered matches
 * @param applyfilter Tells the method which filters should be applied. applyfilter = "the sum of desired filters to be applied". Example, applyfilter = APPLY_MULTI + APPLY_UNIQUE + APPLY_ORSA.
 * @return Total number of matches
 */
int compute_IMAS_matches(int w1, int h1, int w2, int h2, std::vector<IMAS::IMAS_KeyPoint *> &keys1, std::vector<IMAS::IMAS_KeyPoint *> &keys2, matchingslist &matchings, int applyfilter);

#endif // COMPUTE_IMAS_MATCHES_H
