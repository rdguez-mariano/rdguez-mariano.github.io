echo "Optimal coverings vs non optimal coverings"


tensor=8
tensor2=8
matchratio=0.6
matchratio_new=0.85
orsaprecision=18

mkdir -p data


# Unique + one2mult + Homography filters
echo "data/non_optimal_ASIFT.txt <- Old IMAS with Unique + one2mult + Homography filters"
./old_IMAS_cpp/build/main -im1 $1 -im2 $2 -orsa_type 2 -desc 11 -tensor_eigen_threshold ${tensor} -match_ratio ${matchratio} -orsa_precision ${orsaprecision} -applyfilter 7 -eigen_threshold ${tensor2} -radius -1.8 > data/non_optimal_ASIFT.txt

cp output_hori.png data/output_hori_non_optimal_ASIFT.png

echo "data/optimal_ASIFT.txt <- Old IMAS with Unique + one2mult + Homography filters"
./old_IMAS_cpp/build/main -im1 $1 -im2 $2 -orsa_type 2 -desc 11 -tensor_eigen_threshold ${tensor} -match_ratio ${matchratio} -orsa_precision ${orsaprecision} -applyfilter 7 -eigen_threshold ${tensor2} -radius 1.7 > data/optimal_ASIFT.txt

cp output_hori.png data/output_hori_optimal_ASIFT.png


rm data_matches.csv
rm output_hori.png
rm output_hori_rich.png
rm output_vert.png
rm output_vert_rich.png
rm panorama.png

echo "Done."