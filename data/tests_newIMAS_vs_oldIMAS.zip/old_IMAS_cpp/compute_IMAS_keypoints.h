/**
  * @file compute_IMAS_keypoints.h
  * @authors <small>(Original code)</small> Guoshen Yu, Mariano Rodríguez
  * @date 2017
  * @brief Computing keypoints from optical tilts.
  * @warning This file is linked to the patent Jean-Michel Morel and Guoshen Yu, Method and device for the invariant affine recognition recognition of shapes (WO/2009/150361), patent pending.
  */

#ifndef COMPUTE_IMAS_KEYPOINTS_H
#define COMPUTE_IMAS_KEYPOINTS_H

#include "IMAS_covering.h"
#include "mex_and_omp.h"
#include <vector>

#ifdef _NO_OPENCV
#include "local_descriptors_standalone.h"
#else
#include "local_descriptor.h"
#endif

/**
 * @brief Computes all keypoints comming from a set of optical tilts.
 * @param image Input image.
 * @param width Width of the input image.
 * @param height Height of the input image.
 * @param keys_all Returns all keypoints indexed by tilt and rotation.
 * @param simu_details Specifies the optical tilts that are to be performed.
 * @return The total number of keypoints that have been found.
 */
int compute_IMAS_keypoints(std::vector<float>& image, int width, int height, std::vector< std::vector< IMAS_keypointlist > >& keys_all,std::vector<tilt_simu>& simu_details);


/**
 * @brief Performs a 1D-convolution between the image and a Gaussian of width sigma and stores result back in image.
 * @param image Input image. Results are to be returned also in here.
 * @param width Width of the input image.
 * @param height Height of the input image.
 * @param sigma Scale of the Gaussian.
 * @param flag_dir Tells the direction of the 1D convolution. Horizontal (flag_dir=0) or Vertical (flag_dir!=0).
 */
void GaussianBlur1D(std::vector<float>& image, int width, int height, float sigma, int flag_dir);


/**
 * @brief Gets tilted coordinates \f$ (x^\prime,y^\prime) \in [1,m_x]\times[1,m_y]\f$ from image coordinates \f$(x,y) \in [1,n_x]\times[1,n_y]\f$ where
 * \f$ T_tR_\phi (x,y) = (x^\prime,y^\prime) \f$. This takes into account the fact that a digital \f$R_\phi\f$ applies a translation to reframe the image.
 * @param (x,y) Enters image coordiantes and returns tilted coordinates
 * @param w Width from the original image (\f$ n_x \f$)
 * @param h Width from the original image (\f$ n_y \f$)
 * @param t Tilt applied in the y direction
 * @param theta Direction of the tilt
 * @author Mariano Rodríguez
 */
void imagecoor2tiltedcoor(float& x, float& y, const int& w, const int& h, const float& t, const float& theta);

/**
 * @brief Gets image coordinates \f$(x,y) \in [1,n_x]\times[1,n_y]\f$ from tilted coordinates \f$T_tR_\phi(x,y) \in [1,m_x]\times[1,m_y]\f$
 * @param (x,y) Enters image coordiantes and returns tilted coordinates
 * @param w Width from the original image (\f$ n_x \f$)
 * @param h Width from the original image (\f$ n_y \f$)
 * @param t Tilt that was applied in the y direction
 * @param theta Direction of the tilt that was applied
 * @return True if the computed image-coordinates fall inside the true image boundaries.
 * @author Mariano Rodríguez
 */
bool tiltedcoor2imagecoor(float& x, float& y, const int& w, const int& h, const float& threshold , const float& t, const float& theta);

#endif // COMPUTE_IMAS_KEYPOINTS_H
