#include "local_descriptor.h"
#include "mex_and_omp.h"


#define BIG_NUMBER 1000000000000.0f


//these are global variables
std::string desc_name="SIFT"; // descriptor being used
float default_radius = 1.8f; // the default radius for the covering


int desc_type=1;   // index for the descriptor being used
float nndrRatio = 0.8f; // Find correspondences by NNDR (Nearest Neighbor Distance Ratio)
int normType = -1; // Use default norm proposed by our program
bool binary_desc = false; // kind of descriptor is being used : binary or float


IMAS_keypointlist keys3;

IMAS_time IMAS::IMAS_getTickCount()
{
    return(cv::getTickCount());
}

double IMAS::IMAS_getTickFrequency()
{
    return(cv::getTickFrequency());
}

void update_matchratio(float matchratio)
{
    nndrRatio = matchratio;
}


std::string SetDetectorDescriptor(int DDIndex)
{
    switch (DDIndex)
    {
    case IMAS_SIFT:
    {
        desc_name="SIFT";
        normType = cv::NORM_L1;
        nndrRatio = 0.73f;
        desc_type = IMAS_SIFT;
        binary_desc = false;
        default_radius = 1.8f;
        break;
    }
    case IMAS_SIFT2:
    {
        desc_name="SIFT";
        normType = cv::NORM_L1;
        nndrRatio = 0.73f;
        desc_type = IMAS_SIFT;
        binary_desc = false;
        default_radius = -1.8f;
        break;
    }
    case IMAS_HALFSIFT:
    {
        desc_name="HALFSIFT";
        normType = cv::NORM_L1;
        nndrRatio = 0.73f;
        desc_type = IMAS_HALFSIFT;
        binary_desc = false;
        default_radius = 1.7f;
        break;
    }
    case IMAS_ROOTSIFT:
    {
        desc_name="RootSIFT";
        normType = cv::NORM_L2;
        nndrRatio = 0.7f;
        desc_type = IMAS_ROOTSIFT;
        binary_desc = false;
        default_radius = 1.7f;
        break;
    }
    case IMAS_SURF:
    {
        desc_name="SURF";
        normType = cv::NORM_L1;
        nndrRatio = 0.73f;
        desc_type = IMAS_SURF;
        binary_desc = false;
        default_radius = 1.4f;
        break;
    }
    case IMAS_BRISK:
    {
        desc_name="BRISK";
        nndrRatio = 0.8f;
        desc_type = IMAS_BRISK;
        binary_desc = true;
        default_radius = 1.7f;
        break;
    }
    case IMAS_FREAK:
    {
        desc_name="FREAK";
        nndrRatio = 0.68f;
        desc_type = IMAS_FREAK;
        binary_desc = true;
        default_radius = 1.6f;
        break;
    }
    case IMAS_ORB:
    {
        desc_name="ORB";
        nndrRatio = 0.8f;
        desc_type = IMAS_ORB;
        binary_desc = true;
        default_radius = 1.4f;
        break;
    }
    case IMAS_BRIEF:
    {
        desc_name="BRIEF";
        nndrRatio = 0.8f;
        desc_type = IMAS_BRIEF;
        binary_desc = true;
        default_radius = 1.4f;
        break;
    }
    case IMAS_AGAST:
    {
        desc_name="AGAST";
        nndrRatio = 0.8f;
        desc_type = IMAS_AGAST;
        binary_desc = true;
        break;
    }
    case IMAS_LATCH:
    {
        desc_name="LATCH";
        nndrRatio = 0.8f;
        desc_type = IMAS_LATCH;
        binary_desc = true;
        default_radius = 1.55f;
        break;
    }
    case IMAS_LUCID:
    {
        desc_name="LUCID";
        nndrRatio = 0.8f;
        desc_type = IMAS_LUCID;
        binary_desc = true;
        break;
    }
    case IMAS_DAISY:
    {
        desc_name="DAISY";
        nndrRatio = 0.8f;
        desc_type = IMAS_DAISY;
        binary_desc = false;
        default_radius = 1.55f;
        break;
    }
    case IMAS_AKAZE:
    {
        desc_name="AKAZE";
        nndrRatio = 0.8f;
        desc_type = IMAS_AKAZE;
        binary_desc = true;
        default_radius = 1.7f;
        break;
    }


    }
    return(desc_name);
}


void detector_and_descriptor(cv::Ptr<cv::FeatureDetector> &detector, cv::Ptr<cv::DescriptorExtractor> &extractor)
{
    switch (desc_type)
    {
    case IMAS_SIFT:
    {
        detector = cv::xfeatures2d::SIFT::create();
        extractor = cv::xfeatures2d::SIFT::create();
        break;
    }
    case IMAS_SIFT2:
    {
        detector = cv::xfeatures2d::SIFT::create();
        extractor = cv::xfeatures2d::SIFT::create();
        break;
    }
    case IMAS_HALFSIFT:
    {
        detector = cv::xfeatures2d::SIFT::create();
        extractor = cv::xfeatures2d::SIFT::create();
        break;
    }
    case IMAS_ROOTSIFT:
    {
        detector = cv::xfeatures2d::SIFT::create();
        extractor = cv::xfeatures2d::SIFT::create();
        break;
    }
    case IMAS_SURF:
    {
        detector = cv::xfeatures2d::SURF::create();
        extractor = cv::xfeatures2d::SURF::create();
        break;
    }
    case IMAS_BRISK:
    {
        detector = cv::BRISK::create();
        extractor = cv::BRISK::create();
        break;
    }
    case IMAS_FREAK:
    {
        detector = cv::xfeatures2d::SURF::create();
        extractor = cv::xfeatures2d::FREAK::create();
        break;
    }
    case IMAS_ORB:
    {
        detector = cv::ORB::create(1500);
        extractor = cv::ORB::create();
        break;
    }
    case IMAS_BRIEF:
    {
        detector = cv::xfeatures2d::StarDetector::create();
        extractor = cv::xfeatures2d::BriefDescriptorExtractor::create();
        break;
    }
    case IMAS_AGAST:
    {
        detector = cv::ORB::create();
        extractor = cv::AgastFeatureDetector::create();
        break;
    }
    case IMAS_LATCH:
    {
        detector = cv::ORB::create(1500);
        extractor = cv::xfeatures2d::LATCH::create();
        break;
    }
    case IMAS_LUCID:
    {
        detector = cv::ORB::create();
        extractor = cv::xfeatures2d::LUCID::create(); // Needs 3-channels image
        break;
    }
    case IMAS_DAISY:
    {
        detector = cv::ORB::create(1500);
        extractor = cv::xfeatures2d::DAISY::create();
        break;
    }
    case IMAS_AKAZE:
    {
        detector = cv::AKAZE::create();
        extractor = cv::AKAZE::create();
        break;
    }

    }
}


void filter_DescList(opencv_descriptorslist& input_list, std::vector<int>& index_filtered, opencv_descriptorslist& descriptors_filtered)
{
    int cols,rows;
    cols = input_list.cols;
    rows = index_filtered.size();

    descriptors_filtered.create(rows, cols, input_list.type());

    for (int ii=0;ii<rows;ii++)
    {
        input_list.row(index_filtered[ii]).copyTo(descriptors_filtered.row(ii));
    }

}


void vectorimage2opencvimage(std::vector<float>& input_image,cv::Mat& output_image,int width, int height)
{
    output_image.create(height, width, CV_8UC1);//cv::imread(argv[2]);

     for (int i = 0;  i < output_image.rows; i++)
     {
       for (int j = 0; j < output_image.cols; j++)
       {
               output_image.data[((output_image.cols)*i)+j] = (uchar) floor(input_image[((output_image.cols)*i)+j]);
        }
      }
}

void opencvimage2vectorimage(cv::Mat& input_image,std::vector<float>& output_image,int& width, int& height)
{
    output_image.clear();
    width = input_image.cols;
    height = input_image.rows;

     for (int i = 0;  i < input_image.rows; i++)
     {
       for (int j = 0; j < input_image.cols; j++)
       {
           output_image.push_back( (float) input_image.data[((input_image.cols)*i)+j] );
        }
      }
}


void floatarray2opencvimage(float *input_image,cv::Mat& output_image,int width, int height)
{
    output_image.create(height, width, CV_8UC1);//cv::imread(argv[2]);

     for (int i = 0;  i < output_image.rows; i++)
     {
       for (int j = 0; j < output_image.cols; j++)
       {
               output_image.data[((output_image.cols)*i)+j] = (uchar) floor(input_image[((output_image.cols)*i)+j]);
        }
      }
}


void compute_local_descriptor_keypoints(cv::Mat& queryImg,  IMAS_keypointlist& KPs)
{

    if(!queryImg.empty())
    {

        ////////////////////////////
        // EXTRACT KEYPOINTS and FEATURES
        ////////////////////////////
        cv::Ptr<cv::FeatureDetector> detector;
        cv::Ptr<cv::DescriptorExtractor> extractor;
        detector_and_descriptor(detector, extractor);

        detector->detect(queryImg, KPs.KeyList);
        extractor->compute(queryImg, KPs.KeyList, KPs.DescList);


        if (desc_type==IMAS_ROOTSIFT)
        {
            int rows;
            rows = KPs.DescList.rows;

            for (int ii=0;ii<rows;ii++)
            {
                cv::Mat temp,temp2;
                cv::normalize( KPs.DescList.row(ii), temp, 1, cv::NORM_L1);
                cv::sqrt(temp, temp2);
                temp2.row(0).copyTo(KPs.DescList.row(ii));
            }

        }
        if (desc_type==IMAS_HALFSIFT)
        {
            int rows;
            cv::Mat temp;
            rows = KPs.DescList.rows;

            for (int ii=0;ii<rows;ii++)
                for (int jhist=0;jhist<16;jhist++)
                    for(int jori=0;jori<4;jori++)
                    {
                        temp = ( KPs.DescList.row(ii).col(jhist*8+jori) + KPs.DescList.row(ii).col(jhist*8+jori+4) );
                        temp.copyTo(KPs.DescList.row(ii).col(jhist*8+jori));
                        temp.copyTo(KPs.DescList.row(ii).col(jhist*8+jori+4));

                    }
        }
    }
}

void compute_local_descriptor_matches( IMAS_keypointlist& keys1, IMAS_keypointlist& keys2, matchingslist& matchings)
{

    ////////////////////////////
    // NEAREST NEIGHBOR MATCHING
    ////////////////////////////

    cv::Mat results;
    cv::Mat dists;
    std::vector<std::vector<cv::DMatch> > matches, matches2, matches3;

    if ( !((keys1.KeyList.size()==0)||(keys2.KeyList.size()==0)) )
    {
        if(binary_desc) //Binary descriptors (ORB, Brief, BRISK, FREAK)
        {
            if(useBFMatcher)
            {
                if (normType>0)
                {
                    cv::BFMatcher matcher(normType);
                    matcher.knnMatch( keys1.DescList, keys2.DescList, matches, k);
                }
                else
                {
                    cv::BFMatcher matcher(cv::NORM_HAMMING); // use cv::NORM_HAMMING2 for ORB descriptor with WTA_K == 3 or 4 (see ORB constructor)
                    matcher.knnMatch( keys1.DescList, keys2.DescList, matches, k);
                }
            }
            else
            {
                // Create Flann LSH index
                cv::flann::Index flannIndex( keys1.DescList, cv::flann::LshIndexParams(12, 20, 2), cvflann::FLANN_DIST_HAMMING);

                // search (nearest neighbor)
                flannIndex.knnSearch( keys2.DescList, results, dists, k, cv::flann::SearchParams() );
            }
        }
        else
        {
            // assume it is CV_32F
            // Float descriptors detected...
            if(useBFMatcher)
            {
                if (normType<0) //set to default
                    normType = cv::NORM_L2;

                if(keys3.KeyList.size()!=0)
                {
                    cv::BFMatcher matcher(normType);
                    matcher.knnMatch( keys1.DescList, keys3.DescList, matches3, 1);
                    matcher.knnMatch( keys1.DescList, keys2.DescList, matches2, 1);
                    //std::cout<<keys1.DescList.size()<<" "<< matches2.size()<<" "<<matches3.size()<<std::endl;

                }
                else
                {
                    cv::BFMatcher matcher(normType);
                    matcher.knnMatch( keys1.DescList, keys2.DescList, matches, k);
                }

            }
            else
            {
                // Create Flann KDTree index
                cv::flann::Index flannIndex( keys1.DescList, cv::flann::KDTreeIndexParams(), cvflann::FLANN_DIST_EUCLIDEAN);

                // search (nearest neighbor)
                flannIndex.knnSearch( keys2.DescList, results, dists, k, cv::flann::SearchParams() );
            }
        }

        // Conversion to CV_32F if needed
        if(dists.type() == CV_32S)
        {
            cv::Mat temp;
            dists.convertTo(temp, CV_32F);
            dists = temp;
        }


        ////////////////////////////
        // PROCESS NEAREST NEIGHBOR RESULTS
        ////////////////////////////
        std::vector<cv::Point2f> mpts_1, mpts_2; // Used for homography
        std::vector<int> indexes_1, indexes_2; // Used for homography

        // Check if this descriptor matches with those of the objects
        if(!useBFMatcher)
        {
            for(int i=0; i<keys1.DescList.rows; ++i)
            {
                // Apply NNDR
                if(results.at<int>(i,0) >= 0 && results.at<int>(i,1) >= 0 &&
                        dists.at<float>(i,0) <= nndrRatio * dists.at<float>(i,1))
                {

                    mpts_1.push_back(keys1.KeyList.at(i).pt);
                    indexes_1.push_back(i);

                    mpts_2.push_back(keys2.KeyList.at(results.at<int>(i,0)).pt);
                    indexes_2.push_back(results.at<int>(i,0));
                }
            }
        }
        else
        {
            if(keys3.KeyList.size()!=0)
            {
                for(unsigned int i=0; i<matches2.size(); ++i)
                {
                    // Apply NNDR
                    if(matches2.at(i).size() == 1 && matches3.at(i).size() == 1 &&
                            matches2.at(i).at(0).distance <= nndrRatio * matches3.at(i).at(0).distance)
                    {
                        //std::cout<< nndrRatio<< " " << matches2.at(i).at(0).distance <<" " << matches3.at(i).at(0).distance<<std::endl;
                        keypoint_simple k1,k2;

                        k1.x = keys1.KeyList[matches2.at(i).at(0).queryIdx].pt.x;
                        k1.y = keys1.KeyList[matches2.at(i).at(0).queryIdx].pt.y;
                        k1.angle = keys1.KeyList[matches2.at(i).at(0).queryIdx].angle;
                        k1.scale = keys1.KeyList[matches2.at(i).at(0).queryIdx].size;


                        k2.x = keys2.KeyList[matches2.at(i).at(0).trainIdx].pt.x;
                        k2.y = keys2.KeyList[matches2.at(i).at(0).trainIdx].pt.y;
                        k2.angle = keys2.KeyList[matches2.at(i).at(0).trainIdx].angle;
                        k2.scale = keys2.KeyList[matches2.at(i).at(0).trainIdx].size;

                        matchings.push_back(matching(k1,k2));
                    }
                }

            }
            else
                for(unsigned int i=0; i<matches.size(); ++i)
                {
                    // Apply NNDR
                    if(matches.at(i).size() == 2 &&
                            matches.at(i).at(0).distance <= nndrRatio * matches.at(i).at(1).distance)
                    {
                        keypoint_simple k1,k2;

                        k1.x = keys1.KeyList[matches.at(i).at(0).queryIdx].pt.x;
                        k1.y = keys1.KeyList[matches.at(i).at(0).queryIdx].pt.y;
                        k1.angle = keys1.KeyList[matches.at(i).at(0).queryIdx].angle;
                        k1.scale = keys1.KeyList[matches.at(i).at(0).queryIdx].size;


                        k2.x = keys2.KeyList[matches.at(i).at(0).trainIdx].pt.x;
                        k2.y = keys2.KeyList[matches.at(i).at(0).trainIdx].pt.y;
                        k2.angle = keys2.KeyList[matches.at(i).at(0).trainIdx].angle;
                        k2.scale = keys2.KeyList[matches.at(i).at(0).trainIdx].size;

                        matchings.push_back(matching(k1,k2));
                    }
                }
        }
    }
}


