cd old_IMAS_cpp && mkdir -p build && cd build && cmake .. && make -j7
cd ../..
cd new_IMAS_cpp && mkdir -p build && cd build && cmake .. && make -j7
cd ../..
